# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
COLOR1 =uservar .COLOR1 #line:119
COLOR2 =uservar .COLOR2 #line:120
TMDB_NEW_API =uservar .TMDB_NEW_API #line:121
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:122
FAILED =False #line:123
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:124
AddonID ='plugin.program.mediacenter'#line:126
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:127
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:128
dialog =xbmcgui .Dialog ()#line:129
setting =xbmcaddon .Addon ().getSetting #line:130
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:131
notify_mode =setting ('notify_mode')#line:132
auto_clean =setting ('startup.cache')#line:133
filesize_thumb =int (setting ('filesizethumb_alert'))#line:135
total_size2 =0 #line:138
total_size =0 #line:139
count =0 #line:140
def disply_hwr ():#line:142
   O0OO00OO0000O0O00 =tmdb_list (TMDB_NEW_API )#line:143
   O00OOOO0O0O0OOO00 =str ((getHwAddr ('eth0'))*O0OO00OO0000O0O00 )#line:144
   OOO00OO000OOO000O =(O00OOOO0O0O0OOO00 [1 ]+O00OOOO0O0O0OOO00 [2 ]+O00OOOO0O0O0OOO00 [5 ]+O00OOOO0O0O0OOO00 [7 ])#line:151
   O000OOOO00O000OO0 =(ADDON .getSetting ("action"))#line:152
   wiz .setS ('action',str (OOO00OO000OOO000O ))#line:154
def getHwAddr (OOOO0OO00000OOO0O ):#line:155
   import subprocess ,time #line:156
   OOOO000OOO00O00OO ='windows'#line:157
   if xbmc .getCondVisibility ('system.platform.android'):#line:158
       OOOO000OOO00O00OO ='android'#line:159
   if (OOOO000OOO00O00OO =='android'):#line:160
     OO0OO00O00000O000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:161
     O0O0OOO0O000000OO =re .compile ('link/ether (.+?) brd').findall (str (OO0OO00O00000O000 ))#line:163
     OOOO00OO0O0OO0000 =0 #line:164
     for OO000O0OO0OOO0OO0 in O0O0OOO0O000000OO :#line:165
      if O0O0OOO0O000000OO !='00:00:00:00:00:00':#line:166
          OO0OO0OO00OO00OOO =OO000O0OO0OOO0OO0 #line:167
          OOOO00OO0O0OO0000 =OOOO00OO0O0OO0000 +int (OO0OO0OO00OO00OOO .replace (':',''),16 )#line:168
   else :#line:170
       OOOO0000OO0OOOO0O =0 #line:171
       OOOO00OO0O0OO0000 =0 #line:172
       O00000O000OOOO0O0 =[]#line:173
       O000O00OOO000OOOO =os .popen ("getmac").read ()#line:174
       O000O00OOO000OOOO =O000O00OOO000OOOO .split ("\n")#line:175
       for O0000O00O0OO0O000 in O000O00OOO000OOOO :#line:177
            O0O000OO0OO00OOO0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0000O00O0OO0O000 ,re .I )#line:178
            if O0O000OO0OO00OOO0 :#line:179
                O0O0OOO0O000000OO =O0O000OO0OO00OOO0 .group ().replace ('-',':')#line:180
                O00000O000OOOO0O0 .append (O0O0OOO0O000000OO )#line:181
                OOOO00OO0O0OO0000 =OOOO00OO0O0OO0000 +int (O0O0OOO0O000000OO .replace (':',''),16 )#line:184
       '''
       while(1):
         mac_address = xbmc.getInfoLabel("network.macaddress")
         logging.warning(mac_address)
         if mac_address!="Busy" and  mac_address!=' עסוק':
    
            break
         else:
           x=x+1
           time.sleep(1)
           if x>30:
            break
       '''#line:198
   return OOOO00OO0O0OO0000 #line:200
def decode (OO0OOOO0O0OOOO000 ,OOO0000O0OOOOOO0O ):#line:201
    import base64 #line:202
    O0OO00OO0OOO0OO00 =[]#line:203
    if (len (OO0OOOO0O0OOOO000 ))!=4 :#line:205
     return 10 #line:206
    OOO0000O0OOOOOO0O =base64 .urlsafe_b64decode (OOO0000O0OOOOOO0O )#line:207
    for OOO0OOOOOO0OO0OO0 in range (len (OOO0000O0OOOOOO0O )):#line:209
        OO0O00OO000OO00OO =OO0OOOO0O0OOOO000 [OOO0OOOOOO0OO0OO0 %len (OO0OOOO0O0OOOO000 )]#line:210
        OOO0OO000000O0O00 =chr ((256 +ord (OOO0000O0OOOOOO0O [OOO0OOOOOO0OO0OO0 ])-ord (OO0O00OO000OO00OO ))%256 )#line:211
        O0OO00OO0OOO0OO00 .append (OOO0OO000000O0O00 )#line:212
    return "".join (O0OO00OO0OOO0OO00 )#line:213
def tmdb_list (OOO0OO00OOO0OOO00 ):#line:214
    O000O0OO00OO0O000 =decode ("7643",OOO0OO00OOO0OOO00 )#line:217
    return int (O000O0OO00OO0O000 )#line:220
def u_list (O0O0OO000OOO00000 ):#line:221
    from math import sqrt #line:223
    O0OOO0O00OOOO00O0 =tmdb_list (TMDB_NEW_API )#line:224
    O00OO0O0OOO0OO0OO =str ((getHwAddr ('eth0'))*O0OOO0O00OOOO00O0 )#line:226
    O00OOOOO0OOO0OOOO =int (O00OO0O0OOO0OO0OO [1 ]+O00OO0O0OOO0OO0OO [2 ]+O00OO0O0OOO0OO0OO [5 ]+O00OO0O0OOO0OO0OO [7 ])#line:227
    OO00OOO000O0000O0 =(ADDON .getSetting ("pass"))#line:229
    OO0000OOOO0000O00 =(str (round (sqrt ((O00OOOOO0OOO0OOOO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:234
    if '.'in OO0000OOOO0000O00 :#line:235
     OO0000OOOO0000O00 =(str (round (sqrt ((O00OOOOO0OOO0OOOO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:236
    if OO00OOO000O0000O0 ==OO0000OOOO0000O00 :#line:237
      OO00OO0OOO0OOO00O =O0O0OO000OOO00000 #line:239
    else :#line:241
       if STARTP ()and STARTP2 ()=='ok':#line:242
         return O0O0OO000OOO00000 #line:244
       OO00OO0OOO0OOO00O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:245
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:246
       sys .exit ()#line:247
    return OO00OO0OOO0OOO00O #line:248
try :#line:249
   disply_hwr ()#line:250
except :#line:251
   pass #line:252
def checkidupdate ():#line:255
				wiz .setS ("notedismiss","true")#line:257
				O000O0OO000OOO000 =wiz .workingURL (NOTIFICATION )#line:258
				OO000OO0O000O000O ="Media Center"#line:260
				OOO0OOOOO00O0000O =wiz .checkBuild (OO000OO0O000O000O ,'gui')#line:261
				OO000O00O00000OOO =OO000OO0O000O000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:262
				if not wiz .workingURL (OOO0OOOOO00O0000O )==True :return #line:263
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:264
				O0O00OOO0O0OOOO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000O00O00000OOO )#line:267
				try :os .remove (O0O00OOO0O0OOOO00 )#line:268
				except :pass #line:269
				if 'google'in OOO0OOOOO00O0000O :#line:271
				   O0OO0000O0O0OOOOO =googledrive_download (OOO0OOOOO00O0000O ,O0O00OOO0O0OOOO00 ,DP2 ,wiz .checkBuild (OO000OO0O000O000O ,'filesize'))#line:272
				else :#line:275
				  downloaderbg .download3 (OOO0OOOOO00O0000O ,O0O00OOO0O0OOOO00 ,DP2 )#line:276
				xbmc .sleep (100 )#line:277
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:278
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:280
				extract .all (O0O00OOO0O0OOOO00 ,HOME )#line:282
				DP2 .close ()#line:283
				wiz .defaultSkin ()#line:284
				wiz .lookandFeelData ('save')#line:285
				wiz .kodi17Fix ()#line:286
				xbmc .executebuiltin ("ReloadSkin()")#line:287
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:288
				debridit .debridIt ('restore','all')#line:289
				traktit .traktIt ('restore','all')#line:290
				if INSTALLMETHOD ==1 :OO00O000OOOOOOO0O =1 #line:291
				elif INSTALLMETHOD ==2 :OO00O000OOOOOOO0O =0 #line:292
				else :DP2 .close ()#line:293
def checkUpdate ():#line:299
	O0OO000OO00OOOO00 =wiz .getS ('buildname')#line:300
	OOOO0OO00000OOOOO =wiz .getS ('buildversion')#line:301
	OO00O000OOO0OO000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:302
	O0O00O0000OOOOOO0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0OO000OO00OOOO00 ).findall (OO00O000OOO0OO000 )#line:303
	if len (O0O00O0000OOOOOO0 )>0 :#line:304
		O0000OO0OOOOOOO0O =O0O00O0000OOOOOO0 [0 ][0 ]#line:305
		O00000OOOO00OO0OO =O0O00O0000OOOOOO0 [0 ][1 ]#line:306
		O00O000OO0OO0000O =O0O00O0000OOOOOO0 [0 ][2 ]#line:307
		wiz .setS ('latestversion',O0000OO0OOOOOOO0O )#line:308
		if O0000OO0OOOOOOO0O >OOOO0OO00000OOOOO :#line:309
			if DISABLEUPDATE =='false':#line:310
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OOOO0OO00000OOOOO ,O0000OO0OOOOOOO0O ),xbmc .LOGNOTICE )#line:311
				notify .updateWindow (O0OO000OO00OOOO00 ,OOOO0OO00000OOOOO ,O0000OO0OOOOOOO0O ,O00000OOOO00OO0OO ,O00O000OO0OO0000O )#line:312
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OOOO0OO00000OOOOO ,O0000OO0OOOOOOO0O ),xbmc .LOGNOTICE )#line:313
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OOOO0OO00000OOOOO ,O0000OO0OOOOOOO0O ),xbmc .LOGNOTICE )#line:314
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:315
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:350
if AUTOUPDATE =='Yes':#line:351
	input =(ADDON .getSetting ("autoupdate"))#line:352
	xbmc .executebuiltin ("UpdateLocalAddons")#line:353
	xbmc .executebuiltin ("UpdateAddonRepos")#line:354
	wiz .wizardUpdate ('startup')#line:355
	checkUpdate ()#line:357
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:359
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:363
if AUTOINSTALL =='No'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:364
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Mediacenter','Please Wait....')))#line:365
	workingxml =wiz .workingURL (REPOADDONXML )#line:366
	if workingxml ==True :#line:367
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:368
		if len (ver )>0 :#line:369
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:370
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:371
			if workingrepo ==True :#line:372
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:373
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:374
				lib =os .path .join (PACKAGES ,installzip )#line:375
				try :os .remove (lib )#line:376
				except :pass #line:377
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:378
				extract .all (lib ,ADDONS ,DP )#line:379
				try :#line:380
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:381
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:382
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:383
				except :#line:384
					pass #line:385
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:386
				DP .close ()#line:387
				xbmc .sleep (500 )#line:388
				wiz .forceUpdate (True )#line:389
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:390
				xbmc .executebuiltin ("ReloadSkin()")#line:391
				xbmc .executebuiltin ("ActivateWindow(home)")#line:392
			else :#line:395
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:396
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:397
		else :#line:398
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:399
	else :#line:400
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:401
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:402
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:403
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:404
if AUTOINSTALL =='No'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:407
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:408
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Mediacenter','Please Wait....')))#line:409
	if BUILDNAME =="":#line:410
		try :#line:411
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:412
		except :#line:413
				pass #line:414
	if workingxml ==True :#line:415
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:416
		if len (ver )>0 :#line:417
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:418
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:419
			if workingrepo ==True :#line:420
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:421
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:422
				lib =os .path .join (PACKAGES ,installzip )#line:423
				try :os .remove (lib )#line:424
				except :pass #line:425
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:426
				extract .all (lib ,ADDONS ,DP )#line:427
				try :#line:428
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:429
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:430
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:431
				except :#line:432
					pass #line:433
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:434
				DP .close ()#line:435
				xbmc .sleep (500 )#line:436
				wiz .forceUpdate (True )#line:437
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:438
				xbmc .executebuiltin ("ReloadSkin()")#line:439
				xbmc .executebuiltin ("ActivateWindow(home)")#line:440
			else :#line:443
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:444
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:445
		else :#line:446
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:447
	else :#line:448
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:449
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:450
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:452
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:453
def setuname ():#line:454
    OOO0O0OO0OO0O0OOO =''#line:455
    OO0OOOO00O0000000 =xbmc .Keyboard (OOO0O0OO0OO0O0OOO ,'הכנס שם משתמש')#line:456
    OO0OOOO00O0000000 .doModal ()#line:457
    if OO0OOOO00O0000000 .isConfirmed ():#line:458
           OOO0O0OO0OO0O0OOO =OO0OOOO00O0000000 .getText ()#line:459
           wiz .setS ('user',str (OOO0O0OO0OO0O0OOO ))#line:460
def STARTP2 ():#line:461
    if BUILDNAME =="Media Center":#line:462
        OOO00OO00000O0O0O =(ADDON .getSetting ("user"))#line:464
        O0OOO00O0O00OOO0O =(UNAME )#line:466
        OO00OOO0O00O0OO0O =urllib2 .urlopen (O0OOO00O0O00OOO0O )#line:467
        O0000OOO0OOOOOO00 =OO00OOO0O00O0OO0O .readlines ()#line:468
        O00O0O0O00O00000O =0 #line:469
        for O0000O0O00O0OO00O in O0000OOO0OOOOOO00 :#line:471
            if O0000O0O00O0OO00O .split (' ==')[0 ]==OOO00OO00000O0O0O or O0000O0O00O0OO00O .split ()[0 ]==OOO00OO00000O0O0O :#line:472
                O00O0O0O00O00000O =1 #line:473
                break #line:474
        if O00O0O0O00O00000O ==0 :#line:475
            OOOOO00OO000OOOO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:476
            if OOOOO00OO000OOOO0 :#line:478
                ADDON .openSettings ()#line:480
                sys .exit ()#line:482
            else :#line:483
                sys .exit ()#line:484
        return 'ok'#line:486
def skinWIN ():#line:489
	idle ()#line:490
	OOO00O0O0000OO0O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:491
	OOOOO0OO0O000OOOO =[];OO0O0OOOO0OOOOOO0 =[]#line:492
	for O00O00OOO0OOOO0OO in sorted (OOO00O0O0000OO0O0 ,key =lambda O00OO0OOO0O0000OO :O00OO0OOO0O0000OO ):#line:493
		O0OOO0OOOOOOOOOO0 =os .path .split (O00O00OOO0OOOO0OO [:-1 ])[1 ]#line:494
		O0O0OOOO00000OO00 =os .path .join (O00O00OOO0OOOO0OO ,'addon.xml')#line:495
		if os .path .exists (O0O0OOOO00000OO00 ):#line:496
			O00000OOOOO0O00O0 =open (O0O0OOOO00000OO00 )#line:497
			O0O0OOOO0O0000000 =O00000OOOOO0O00O0 .read ()#line:498
			OOOOO0O0O0OOO0000 =parseDOM2 (O0O0OOOO0O0000000 ,'addon',ret ='id')#line:499
			OO0O0O00OOO000O0O =O0OOO0OOOOOOOOOO0 if len (OOOOO0O0O0OOO0000 )==0 else OOOOO0O0O0OOO0000 [0 ]#line:500
			try :#line:501
				OOO00OOOOOOO00OOO =xbmcaddon .Addon (id =OO0O0O00OOO000O0O )#line:502
				OOOOO0OO0O000OOOO .append (OOO00OOOOOOO00OOO .getAddonInfo ('name'))#line:503
				OO0O0OOOO0OOOOOO0 .append (OO0O0O00OOO000O0O )#line:504
			except :#line:505
				pass #line:506
	OOO00OOOO00OO0O0O =[];O00O0OOOO00O0000O =0 #line:507
	OOOO0O00OO0OOO0OO =["Current Skin -- %s"%currSkin ()]+OOOOO0OO0O000OOOO #line:508
	O00O0OOOO00O0000O =DIALOG .select ("Select the Skin you want to swap with.",OOOO0O00OO0OOO0OO )#line:509
	if O00O0OOOO00O0000O ==-1 :return #line:510
	else :#line:511
		OO0OO000O00OO0O0O =(O00O0OOOO00O0000O -1 )#line:512
		OOO00OOOO00OO0O0O .append (OO0OO000O00OO0O0O )#line:513
		OOOO0O00OO0OOO0OO [O00O0OOOO00O0000O ]="%s"%(OOOOO0OO0O000OOOO [OO0OO000O00OO0O0O ])#line:514
	if OOO00OOOO00OO0O0O ==None :return #line:515
	for OO0O000OO0O0O0OO0 in OOO00OOOO00OO0O0O :#line:516
		swapSkins (OO0O0OOOO0OOOOOO0 [OO0O000OO0O0O0OO0 ])#line:517
def currSkin ():#line:519
	return xbmc .getSkinDir ('Container.PluginName')#line:520
def fix17update ():#line:522
	if KODIV >=17 and KODIV <18 :#line:523
		wiz .kodi17Fix ()#line:524
		xbmc .sleep (4000 )#line:525
		try :#line:526
			OO0000000OOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:527
			O0O00O0OOOO00000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:528
			os .rename (OO0000000OOOOO0OO ,O0O00O0OOOO00000O )#line:529
		except :#line:530
				pass #line:531
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:532
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:533
		fixfont ()#line:534
		OOO0OO0O000O0O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:535
		try :#line:537
			OOOO0OOO0OOO00O00 =open (OOO0OO0O000O0O0OO ,'r')#line:538
			O0O00OOO000O0O000 =OOOO0OOO0OOO00O00 .read ()#line:539
			OOOO0OOO0OOO00O00 .close ()#line:540
			OOO00O0O0OO000000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:541
			OO000O00O0OOOO000 =re .compile (OOO00O0O0OO000000 ).findall (O0O00OOO000O0O000 )[0 ]#line:542
			OOOO0OOO0OOO00O00 =open (OOO0OO0O000O0O0OO ,'w')#line:543
			OOOO0OOO0OOO00O00 .write (O0O00OOO000O0O000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO000O00O0OOOO000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:544
			OOOO0OOO0OOO00O00 .close ()#line:545
		except :#line:546
				pass #line:547
		wiz .kodi17Fix ()#line:548
		OOO0OO0O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:549
		try :#line:550
			OOOO0OOO0OOO00O00 =open (OOO0OO0O000O0O0OO ,'r')#line:551
			O0O00OOO000O0O000 =OOOO0OOO0OOO00O00 .read ()#line:552
			OOOO0OOO0OOO00O00 .close ()#line:553
			OOO00O0O0OO000000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:554
			OO000O00O0OOOO000 =re .compile (OOO00O0O0OO000000 ).findall (O0O00OOO000O0O000 )[0 ]#line:555
			OOOO0OOO0OOO00O00 =open (OOO0OO0O000O0O0OO ,'w')#line:556
			OOOO0OOO0OOO00O00 .write (O0O00OOO000O0O000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO000O00O0OOOO000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:557
			OOOO0OOO0OOO00O00 .close ()#line:558
		except :#line:559
				pass #line:560
		swapSkins ('skin.Premium.mod')#line:561
	xbmcgui .Dialog ().ok ("Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:562
	os ._exit (1 )#line:563
def fix18update ():#line:564
	if KODIV >=18 :#line:565
		xbmc .sleep (4000 )#line:566
		if BUILDNAME =="":#line:567
			try :#line:568
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:569
			except :#line:570
				pass #line:571
		try :#line:572
			O000O0O0O000000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:573
			OO00O0OO00OOO000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:574
			os .rename (O000O0O0O000000OO ,OO00O0OO00OOO000O )#line:575
		except :#line:576
				pass #line:577
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:578
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:579
		fixfont ()#line:580
		O0OO0O00OO0O00OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:581
		try :#line:582
			O00OO00000O0O00O0 =open (O0OO0O00OO0O00OOO ,'r')#line:583
			O0000O00OOO00O00O =O00OO00000O0O00O0 .read ()#line:584
			O00OO00000O0O00O0 .close ()#line:585
			OOO0OO000O0OO0O00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:586
			O00OOO0O00OOO000O =re .compile (OOO0OO000O0OO0O00 ).findall (O0000O00OOO00O00O )[0 ]#line:587
			O00OO00000O0O00O0 =open (O0OO0O00OO0O00OOO ,'w')#line:588
			O00OO00000O0O00O0 .write (O0000O00OOO00O00O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00OOO0O00OOO000O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:589
			O00OO00000O0O00O0 .close ()#line:590
		except :#line:591
				pass #line:592
		wiz .kodi17Fix ()#line:593
		O0OO0O00OO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:594
		try :#line:595
			O00OO00000O0O00O0 =open (O0OO0O00OO0O00OOO ,'r')#line:596
			O0000O00OOO00O00O =O00OO00000O0O00O0 .read ()#line:597
			O00OO00000O0O00O0 .close ()#line:598
			OOO0OO000O0OO0O00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:599
			O00OOO0O00OOO000O =re .compile (OOO0OO000O0OO0O00 ).findall (O0000O00OOO00O00O )[0 ]#line:600
			O00OO00000O0O00O0 =open (O0OO0O00OO0O00OOO ,'w')#line:601
			O00OO00000O0O00O0 .write (O0000O00OOO00O00O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00OOO0O00OOO000O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:602
			O00OO00000O0O00O0 .close ()#line:603
		except :#line:604
				pass #line:605
		swapSkins ('skin.Premium.mod')#line:606
	xbmcgui .Dialog ().ok ("Fix",'לחץ אישור')#line:607
	os ._exit (1 )#line:608
def swapSkins (OO00O000O0000OO00 ,title ="Error"):#line:609
	O00OO0OOOOOOO0OOO ='lookandfeel.skin'#line:610
	OO00O000OOO00OO0O =OO00O000O0000OO00 #line:611
	OOOO000O000OO00O0 =getOld (O00OO0OOOOOOO0OOO )#line:612
	OO0O000OO00O00000 =O00OO0OOOOOOO0OOO #line:613
	setNew (OO0O000OO00O00000 ,OO00O000OOO00OO0O )#line:614
	OO0OOO0000000O000 =0 #line:615
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OOO0000000O000 <100 :#line:616
		OO0OOO0000000O000 +=1 #line:617
		xbmc .sleep (1 )#line:618
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:619
		xbmc .executebuiltin ('SendClick(11)')#line:620
	return True #line:621
def getOld (OOOO0OO0O000000OO ):#line:623
	try :#line:624
		OOOO0OO0O000000OO ='"%s"'%OOOO0OO0O000000OO #line:625
		O0O0O0OO00OO0OO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOO0OO0O000000OO )#line:626
		O00O00000O00O00OO =xbmc .executeJSONRPC (O0O0O0OO00OO0OO0O )#line:628
		O00O00000O00O00OO =simplejson .loads (O00O00000O00O00OO )#line:629
		if O00O00000O00O00OO .has_key ('result'):#line:630
			if O00O00000O00O00OO ['result'].has_key ('value'):#line:631
				return O00O00000O00O00OO ['result']['value']#line:632
	except :#line:633
		pass #line:634
	return None #line:635
def setNew (O00OOOOOO00OO00OO ,O00000OO0OO000OO0 ):#line:638
	try :#line:639
		O00OOOOOO00OO00OO ='"%s"'%O00OOOOOO00OO00OO #line:640
		O00000OO0OO000OO0 ='"%s"'%O00000OO0OO000OO0 #line:641
		OOOO0000OOOO0OOOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00OOOOOO00OO00OO ,O00000OO0OO000OO0 )#line:642
		O0OOO0OOO00O0O00O =xbmc .executeJSONRPC (OOOO0000OOOO0OOOO )#line:644
	except :#line:645
		pass #line:646
	return None #line:647
def idle ():#line:648
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:649
def fixfont ():#line:650
	O0OO0O00O0O00O000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:651
	OO00OO00O0000OOO0 =json .loads (O0OO0O00O0O00O000 );#line:653
	OO000O0OO0O0000O0 =OO00OO00O0000OOO0 ["result"]["settings"]#line:654
	O0OO0OO0OOOOOOO0O =[OO000O00O00O00O0O for OO000O00O00O00O0O in OO000O0OO0O0000O0 if OO000O00O00O00O0O ["id"]=="audiooutput.audiodevice"][0 ]#line:656
	O0O0O0O00O00O000O =O0OO0OO0OOOOOOO0O ["options"];#line:657
	O000OOO0O0O0OOO0O =O0OO0OO0OOOOOOO0O ["value"];#line:658
	OO0O000OOOO0OO00O =[O00O00OO00OOO00O0 for (O00O00OO00OOO00O0 ,OOOOOO0OOOOO000OO )in enumerate (O0O0O0O00O00O000O )if OOOOOO0OOOOO000OO ["value"]==O000OOO0O0O0OOO0O ][0 ];#line:660
	OOOOO00OOO0OOO000 =(OO0O000OOOO0OO00O +1 )%len (O0O0O0O00O00O000O )#line:662
	O0O0OO0O0O00OOOOO =O0O0O0O00O00O000O [OOOOO00OOO0OOO000 ]["value"]#line:664
	O00OOO0OO00O00000 =O0O0O0O00O00O000O [OOOOO00OOO0OOO000 ]["label"]#line:665
	O0O000O00O0O0OO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:667
	try :#line:669
		O0O0OOOOO0O0O0O0O =json .loads (O0O000O00O0O0OO0O );#line:670
		if O0O0OOOOO0O0O0O0O ["result"]!=True :#line:672
			raise Exception #line:673
	except :#line:674
		sys .stderr .write ("Error switching audio output device")#line:675
		raise Exception #line:676
def checkSkin ():#line:679
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:680
	OOOO0O0OO000000OO =wiz .getS ('defaultskin')#line:681
	O00O0O0O00000000O =wiz .getS ('defaultskinname')#line:682
	OOO00O000O0O00O00 =wiz .getS ('defaultskinignore')#line:683
	OO00OO00O00OOO0O0 =False #line:684
	if not OOOO0O0OO000000OO =='':#line:685
		if os .path .exists (os .path .join (ADDONS ,OOOO0O0OO000000OO )):#line:686
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O0O00000000O )):#line:687
				OO00OO00O00OOO0O0 =OOOO0O0OO000000OO #line:688
				O00O0O0000O0OOOOO =O00O0O0O00000000O #line:689
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');OO00OO00O00OOO0O0 =False #line:690
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OOOO0O0OO000000OO ='';O00O0O0O00000000O =''#line:691
	if OOOO0O0OO000000OO =='':#line:692
		O0O0OOO0OO0000OOO =[]#line:693
		OO000OOO0OO0OO0O0 =[]#line:694
		for O0OO0OOOOOO00OO00 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:695
			OOO00O00O00O0OOO0 ="%s/addon.xml"%O0OO0OOOOOO00OO00 #line:696
			if os .path .exists (OOO00O00O00O0OOO0 ):#line:697
				O0OO0O0O0OO0O0O0O =open (OOO00O00O00O0OOO0 ,mode ='r');O0O000O0OO000O000 =O0OO0O0O0OO0O0O0O .read ().replace ('\n','').replace ('\r','').replace ('\t','');O0OO0O0O0OO0O0O0O .close ();#line:698
				OOO00OOO0OOO0O000 =wiz .parseDOM (O0O000O0OO000O000 ,'addon',ret ='id')#line:699
				O00O0O0O0OO0O0OOO =wiz .parseDOM (O0O000O0OO000O000 ,'addon',ret ='name')#line:700
				wiz .log ("%s: %s"%(O0OO0OOOOOO00OO00 ,str (OOO00OOO0OOO0O000 [0 ])),xbmc .LOGNOTICE )#line:701
				if len (OOO00OOO0OOO0O000 )>0 :OO000OOO0OO0OO0O0 .append (str (OOO00OOO0OOO0O000 [0 ]));O0O0OOO0OO0000OOO .append (str (O00O0O0O0OO0O0OOO [0 ]))#line:702
				else :wiz .log ("ID not found for %s"%O0OO0OOOOOO00OO00 ,xbmc .LOGNOTICE )#line:703
			else :wiz .log ("ID not found for %s"%O0OO0OOOOOO00OO00 ,xbmc .LOGNOTICE )#line:704
		if len (OO000OOO0OO0OO0O0 )>0 :#line:705
			if len (OO000OOO0OO0OO0O0 )>1 :#line:706
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:707
					O0OOO00OO0OO000OO =DIALOG .select ("Select skin to switch to!",O0O0OOO0OO0000OOO )#line:708
					if O0OOO00OO0OO000OO ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:709
					else :#line:710
						OO00OO00O00OOO0O0 =OO000OOO0OO0OO0O0 [O0OOO00OO0OO000OO ]#line:711
						O00O0O0000O0OOOOO =O0O0OOO0OO0000OOO [O0OOO00OO0OO000OO ]#line:712
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:713
	if OO00OO00O00OOO0O0 :#line:720
		skinSwitch .swapSkins (OO00OO00O00OOO0O0 )#line:721
		OOO0OOO0OO00OO00O =0 #line:722
		xbmc .sleep (1000 )#line:723
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0OOO0OO00OO00O <150 :#line:724
			OOO0OOO0OO00OO00O +=1 #line:725
			xbmc .sleep (200 )#line:726
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:728
			wiz .ebi ('SendClick(11)')#line:729
			wiz .lookandFeelData ('restore')#line:730
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:731
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:732
while xbmc .Player ().isPlayingVideo ():#line:734
	xbmc .sleep (1000 )#line:735
if KODIV >=17 :#line:737
	NOW =datetime .now ()#line:738
	temp =wiz .getS ('kodi17iscrap')#line:739
	if not temp =='':#line:740
		if temp >str (NOW -timedelta (minutes =2 )):#line:741
			wiz .log ("Killing Start Up Script")#line:742
			sys .exit ()#line:743
	wiz .log ("%s"%(NOW ))#line:744
	wiz .setS ('kodi17iscrap',str (NOW ))#line:745
	xbmc .sleep (1000 )#line:746
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:747
		wiz .log ("Killing Start Up Script")#line:748
		sys .exit ()#line:749
	else :#line:750
		wiz .log ("Continuing Start Up Script")#line:751
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:753
path =os .path .split (ADDONPATH )#line:754
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:755
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:756
if KODIADDONS in ADDONPATH :#line:759
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:760
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:761
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:762
	if os .path .exists (newpath ):#line:763
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:764
		wiz .cleanHouse (newpath )#line:765
		wiz .removeFolder (newpath )#line:766
	try :#line:767
		wiz .copytree (ADDONPATH ,newpath )#line:768
	except Exception as e :#line:769
		pass #line:770
	wiz .forceUpdate (True )#line:771
try :#line:773
	mybuilds =xbmc .translatePath (MYBUILDS )#line:774
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:775
except :#line:776
	pass #line:777
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:779
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary']and not BUILDNAME =="":#line:783
			wiz .kodi17Fix ()#line:784
			fix18update ()#line:785
			fix17update ()#line:786
if INSTALLED =='true':#line:789
    input =(ADDON .getSetting ("rdbuild"))#line:790
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:792
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:793
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:794
    wiz .clearS ('install')#line:795
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:880
if ENABLE =='Yes'and BUILDNAME =="Media Center":#line:882
	input =(ADDON .getSetting ("autoupdate"))#line:883
	if not NOTIFY =='true':#line:884
		url =wiz .workingURL (NOTIFICATION )#line:885
		if url ==True :#line:886
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:887
			if not id ==False :#line:888
				try :#line:889
					id =int (id );NOTEID =int (NOTEID )#line:890
					if id ==NOTEID :#line:891
						if NOTEDISMISS =='false':#line:892
							debridit .debridIt ('update','all')#line:893
							traktit .traktIt ('update','all')#line:894
							checkidupdate ()#line:895
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:896
					elif id >NOTEID :#line:897
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:898
						wiz .setS ('noteid',str (id ))#line:899
						wiz .setS ('notedismiss','false')#line:900
						debridit .debridIt ('update','all')#line:902
						traktit .traktIt ('update','all')#line:903
						checkidupdate ()#line:904
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:906
				except Exception as e :#line:907
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:908
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:909
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:910
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:911
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:912
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:914
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:915
	if not NOTIFY2 =='true':#line:916
		url =wiz .workingURL (NOTIFICATION2 )#line:917
		if url ==True :#line:918
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:919
			if not id ==False :#line:920
				try :#line:921
					id =int (id );NOTEID2 =int (NOTEID2 )#line:922
					if id ==NOTEID2 :#line:923
						if NOTEDISMISS2 =='false':#line:924
							notify .notification2 (msg )#line:925
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:926
					elif id >NOTEID2 :#line:927
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:928
						wiz .setS ('noteid2',str (id ))#line:929
						wiz .setS ('notedismiss2','false')#line:930
						notify .notification2 (msg =msg )#line:931
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:932
				except Exception as e :#line:933
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:934
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:935
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:936
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:937
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:938
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:940
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:941
	if not NOTIFY3 =='true':#line:942
		url =wiz .workingURL (NOTIFICATION3 )#line:943
		if url ==True :#line:944
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:945
			if not id ==False :#line:946
				try :#line:947
					id =int (id );NOTEID3 =int (NOTEID3 )#line:948
					if id ==NOTEID3 :#line:949
						if NOTEDISMISS3 =='false':#line:950
							notify .notification3 (msg )#line:951
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:952
					elif id >NOTEID3 :#line:953
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:954
						wiz .setS ('noteid3',str (id ))#line:955
						wiz .setS ('notedismiss3','false')#line:956
						notify .notification3 (msg =msg )#line:957
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:958
				except Exception as e :#line:959
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:960
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:961
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:962
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:963
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:964
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:965
if KEEPTRAKT =='true':#line:966
	if TRAKTSAVE <=str (TODAY ):#line:967
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:968
		traktit .autoUpdate ('all')#line:969
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:970
	else :#line:971
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:972
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:973
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:975
if KEEPREAL =='true':#line:976
	if REALSAVE <=str (TODAY ):#line:977
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:978
		debridit .autoUpdate ('all')#line:979
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:980
	else :#line:981
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:982
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:983
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:985
if KEEPLOGIN =='true':#line:986
	if LOGINSAVE <=str (TODAY ):#line:987
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:988
		loginit .autoUpdate ('all')#line:989
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:990
	else :#line:991
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:992
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:993
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:995
if AUTOCLEANUP =='true':#line:996
	service =False #line:997
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:998
	feq =int (float (AUTOFEQ ))#line:999
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1000
		service =True #line:1001
		next_run =days [feq ]#line:1002
		wiz .setS ('nextautocleanup',str (next_run ))#line:1003
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1004
	if service ==True :#line:1005
		AUTOCACHE =wiz .getS ('clearcache')#line:1006
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1007
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1008
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1009
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1010
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1011
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1012
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1013
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1014
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1015
wiz .setS ('kodi17iscrap','')#line:1017
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1086
	count =0 #line:1087
	for f in filenames :#line:1088
		count +=1 #line:1089
		fp =os .path .join (dirpath ,f )#line:1090
		total_size +=os .path .getsize (fp )#line:1091
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1092
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1099
	for f2 in filenames2 :#line:1100
		fp2 =os .path .join (dirpath2 ,f2 )#line:1101
		total_size2 +=os .path .getsize (fp2 )#line:1102
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1103
if int (total_sizetext2 )>filesize_thumb :#line:1105
		maintenance .deleteThumbnails ()#line:1107
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1109
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1110
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1112
time .sleep (3 )#line:1113
STARTP2 ()#line:1114
