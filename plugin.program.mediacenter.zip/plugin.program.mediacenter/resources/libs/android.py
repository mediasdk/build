import android
droid = android.Android()
droid.launch('vip.kodi.anonymous')